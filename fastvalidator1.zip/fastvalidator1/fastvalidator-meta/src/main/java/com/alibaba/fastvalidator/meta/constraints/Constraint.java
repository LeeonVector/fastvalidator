package com.alibaba.fastvalidator.meta.constraints;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Constraint information
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public class Constraint implements Comparable {

    private String            name;

    private Type              type;

    private Map<String, Type> constraintPropertyTypes = new HashMap<>();

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Type> getConstraintPropertyTypes() {
        return constraintPropertyTypes;
    }

    public void setConstraintPropertyTypes(Map<String, Type> constraintPropertyTypes) {
        this.constraintPropertyTypes = constraintPropertyTypes;
    }

    @Override
    public int compareTo(Object o) {
        if (o == null || !(o instanceof Constraint)) {
            return -1;
        }

        return this.name == null ? -1 : this.name.compareTo(((Constraint) o).getName());
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Constraint{");
        sb.append("name='").append(name).append('\'');
        sb.append(", constraintPropertyTypes=").append(constraintPropertyTypes);
        sb.append('}');
        return sb.toString();
    }
}
