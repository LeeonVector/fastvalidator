package com.alibaba.fastvalidator.meta;

import java.util.ArrayList;
import java.util.List;

/**
 * Composed element(eg. POJO bean)
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public class ComposedValidationMeta extends ValidationMeta {

    private static final long    serialVersionUID = 4076091508873706056L;

    private List<ValidationMeta> validationMetas  = new ArrayList<>();

    public List<ValidationMeta> getValidationMetas() {
        return validationMetas;
    }

    public void setValidationMetas(List<ValidationMeta> validationMetas) {
        this.validationMetas = validationMetas;
    }

    public void addValidationMeta(ValidationMeta validationMeta) {
        validationMetas.add(validationMeta);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ComposedValidationMeta{");
        sb.append("name='").append(getName()).append('\'');
        sb.append(", type=").append(getType());
        sb.append(", constraints=").append(getConstraints());
        sb.append(", validationMetas=").append(validationMetas);
        sb.append('}');
        return sb.toString();
    }
}
