package com.alibaba.fastvalidator.meta.constraints;

import java.lang.annotation.Annotation;
import java.util.Set;

/**
 * Constrains registries
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public interface ConstraintRegistry {

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     * 
     * @return all constraint information in constraint registry through {@link Filter}.
     */
    Set<Constraint> getAllConstraints(Filter filter);

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this result set of this method.
     * </pre>
     *
     * @return all constraint elements in constraint registry.
     */
    Set<Constraint> getAllConstraints();

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     *
     * @param filter constraint filter
     * @return all constraints in constraint registry without 'message', 'payload' and 'groups' attributes.
     */
    Set<Constraint> getAllConstraintsWithoutDefaultAttribute(Filter filter);

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     *
     * @return all constraint in constraint registry without 'message', 'payload' and 'groups' attributes.
     */
    Set<Constraint> getAllConstraintsWithoutDefaultAttribute();

    /***
     * Put constraints and constraint's validator in constraint registry.
     *
     * @param annotationTypes constraint annotation
     */
    void putConstraints(Class<? extends Annotation>... annotationTypes);

    /***
     * Constraint filter
     */
    interface Filter {
        boolean isFilter(Constraint constraint);
    }

}
