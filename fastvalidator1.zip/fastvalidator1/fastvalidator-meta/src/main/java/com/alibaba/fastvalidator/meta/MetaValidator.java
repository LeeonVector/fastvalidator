package com.alibaba.fastvalidator.meta;

import java.util.Set;

import javax.validation.ConstraintViolation;

/**
 * Metadata validator
 *
 * @author: jasen.zhangj
 * @date: 2017/2/24.
 */
public interface MetaValidator {

    /***
     * Validate the object through the metadata.
     *
     * @param meta validation meta eg: {@link ValidationMeta} or {@link ComposedValidationMeta}
     * @param object to be validated object
     * @param groups the validate group, default is DEFAULT group.
     * @param <E> {@link ValidationMeta}
     * @param <O> to be validated object
     * @return validate result {@link ConstraintViolation}
     */
    <E extends ValidationMeta, O>  Set<ConstraintViolation<O>> validateByMeta(E meta, O object,
                                                                                            Class<?>... groups);

}
