package com.alibaba.fastvalidator.meta;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom defined constraints on a specify medium(eg. property or bean) from annotation, xml or db.
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public class ValidationMeta implements Serializable {

    private static final long    serialVersionUID = 1663204975571555351L;

    private String               name;

    private Class<?>             type;

    private List<ConstraintMeta> constraints      = new ArrayList<>();

    public ValidationMeta() {
        this(null, null);
    }

    public ValidationMeta(String name) {
        this(name, null);
    }

    public ValidationMeta(Class<?> type) {
        this(null, type);
    }

    public ValidationMeta(String name, Class<?> type) {
        this.name = name;
        this.type = type;
    }

    public List<ConstraintMeta> getConstraints() {
        return constraints;
    }

    public void setConstraints(List<ConstraintMeta> constraints) {
        this.constraints = constraints;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class type) {
        this.type = type;
    }

    public void addConstraintMeta(ConstraintMeta constraintMeta) {
        this.constraints.add(constraintMeta);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ValidationMeta{");
        sb.append("name='").append(name).append('\'');
        sb.append(", type=").append(type);
        sb.append(", constraints=").append(constraints);
        sb.append('}');
        return sb.toString();
    }
}
