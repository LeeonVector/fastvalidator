package com.alibaba.fastvalidator.meta;

import java.util.HashMap;
import java.util.Map;

/**
 * Constraint element
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public class ConstraintMeta extends ValidationMeta {

    private static final long   serialVersionUID     = -7086169580317811365L;

    private Map<String, Object> constraintProperties = new HashMap<>();

    public ConstraintMeta() {
        super();
    }

    public ConstraintMeta(Class<?> type) {
        super(type);
    }

    public Map<String, Object> getConstraintProperties() {
        return constraintProperties;
    }

    public void setConstraintProperties(Map<String, Object> constraintProperties) {
        this.constraintProperties = constraintProperties;
    }

    public void putAttributeValue(String name, Object value) {
        constraintProperties.put(name, value);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ConstraintMeta{");
        sb.append("name=\'").append(getName()).append("\'");
        sb.append(", type=").append(getType());
        sb.append(", constraintProperties=").append(constraintProperties);
        sb.append('}');

        return sb.toString();
    }
}
