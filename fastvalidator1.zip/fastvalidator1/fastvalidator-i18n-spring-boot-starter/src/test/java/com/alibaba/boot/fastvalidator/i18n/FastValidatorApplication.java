package com.alibaba.boot.fastvalidator.i18n;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017/3/10.
 */
@SpringBootApplication
public class FastValidatorApplication {

    public static void main(String[] args) {
        SpringApplication.run(FastValidatorApplication.class, args);
    }

}
