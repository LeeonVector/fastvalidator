package com.alibaba.boot.fastvalidator.i18n;

import junit.framework.TestCase;
import java.util.Locale;
import javax.validation.MessageInterpolator;
import javax.validation.metadata.ConstraintDescriptor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.alibaba.boot.fastvalidator.i18n.helper.FastValidatorLocaleContextHolder;
import com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext;

/**
 * Test for {@link FastValidatorMessageInterpolatorAutoConfiguration}
 *
 * @author: jasen.zhangj
 * @date: 2017/3/10.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(FastValidatorApplication.class)
public class FastValidatorMessageInterpolatorAutoConfigurationTest extends TestCase {

    @Autowired
    private MessageInterpolator messageInterpolator;

    @Test
    public void testI18n_english() {
        LocaleContextHolder.setLocale(Locale.ENGLISH);
        ValidationContext validationContext = new ValidationContext();
        String message = messageInterpolator.interpolate("fastvaldiator.message", validationContext);
        FastValidatorLocaleContextHolder.setLocale(null);

        assertTrue("fastvalidator hello world.".equals(message));
    }

    @Test
    public void testI18n_china() {
        FastValidatorLocaleContextHolder.setLocale(Locale.CHINA);
        ValidationContext validationContext = new ValidationContext();
        String message = messageInterpolator.interpolate("fastvaldiator.message",validationContext);
        FastValidatorLocaleContextHolder.setLocale(null);

        assertTrue("fastvalidator 你好".equals(message));
    }

    @Test
    public void testI18n_message_format() {
        ValidationContext validationContext = new ValidationContext();
        validationContext.setLocale(Locale.CHINA);
        validationContext.setArgs(new Object[]{"jasen.zhangj"});
        String message = messageInterpolator.interpolate("fastvaldiator.message.args",validationContext);

        assertTrue("fastvalidator 你好 jasen.zhangj".equals(message));
    }

    @Test
    public void testI18n_mcms() {
        ValidationContext validationContext = new ValidationContext();
        validationContext.setLocale(Locale.ENGLISH);
        validationContext.setArgs(new Object[]{"jasen.zhangj"});
        String message = messageInterpolator.interpolate("qualityPicksHandbags@home",validationContext);

        assertTrue("Shoes & Bags".equals(message));
    }



    static class ValidationContext implements FastValidatorBeanContext, MessageInterpolator.Context {

        private Object[] args;
        private Locale   locale;

        public ValidationContext() {

        }

        public void setArgs(Object[] args) {
            this.args = args;
        }

        @Override
        public void setLocale(Locale locale) {
            this.locale = locale;
        }

        @Override
        public boolean isFailFast() {
            return false;
        }

        @Override
        public String currentGroup() {
            return null;
        }

        @Override
        public boolean isDefaultGroup() {
            return false;
        }

        @Override
        public Locale getLocale() {
            return locale;
        }

        @Override
        public Object[] getMessageArgs() {
            return args;
        }

        @Override
        public void setMessageArgs(Object[] messageArgs) {
            args = messageArgs;
        }

        @Override
        public MessageInterpolator getMessageInterpolator() {
            return null;
        }

        @Override
        public void setBeanPropertyConstraintDescriptor(ConstraintDescriptor<?> constraintDescriptor) {

        }

        @Override
        public ConstraintDescriptor getBeanPropertyConstraintDescriptor() {
            return null;
        }

        @Override
        public ConstraintDescriptor<?> getConstraintDescriptor() {
            return null;
        }

        @Override
        public Object getValidatedValue() {
            return null;
        }

        @Override
        public <T> T unwrap(Class<T> type) {
            return (T)this;
        }
    }
}
