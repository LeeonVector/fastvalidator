package com.alibaba.boot.fastvalidator.i18n.interpolator;

import java.util.Locale;

import org.springframework.context.MessageSource;

import com.alibaba.boot.fastvalidator.i18n.helper.FastValidatorLocaleContextHolder;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.FastValidatorMessageInterpolator;

/**
 * Fast Validator message interpolator by MCMS.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-08
 */
public class FastValidatorI18nMessageInterpolator extends FastValidatorMessageInterpolator {

    private MessageSource messageSource;

    public FastValidatorI18nMessageInterpolator(MessageSource messageSource) {
        super();
        this.messageSource = messageSource;
    }

    @Override
    public String interpolate(String message, Context context) {
        return this.interpolate(message, context, FastValidatorLocaleContextHolder.getLocale());
    }

    @Override
    public String interpolate(String message, Context context, Locale locale) {
        Object[] messageArgs = null;
        if (context instanceof FastValidatorBeanContext) {
            FastValidatorBeanContext fastValidatorBeanContext = context.unwrap(FastValidatorBeanContext.class);
            Locale validateLocale = fastValidatorBeanContext.getLocale();
            if (validateLocale != null){
                locale = validateLocale;
            }
            messageArgs = fastValidatorBeanContext.getMessageArgs();
        }

        String resolvedMessage = messageSource.getMessage(message, messageArgs, locale);

        if (StringUtils.isBlank(resolvedMessage)) {
            return super.interpolate(message, context, locale);
        } else {
            return resolvedMessage;
        }
    }
}
