package com.alibaba.boot.fastvalidator.i18n.helper;

import java.util.Locale;
import java.util.TimeZone;

import org.springframework.context.i18n.LocaleContext;
import org.springframework.context.i18n.SimpleLocaleContext;
import org.springframework.context.i18n.SimpleTimeZoneAwareLocaleContext;
import org.springframework.context.i18n.TimeZoneAwareLocaleContext;
import org.springframework.core.NamedThreadLocal;

/**
 * Local context holder for Fast Validator.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-08
 */
public class FastValidatorLocaleContextHolder {

    private static final ThreadLocal<LocaleContext> localeContextHolder = new NamedThreadLocal<>("Locale context for fastvalidator");

    /**
     * Reset the LocaleContext for the current thread.
     */
    public static void resetLocaleContext() {
        localeContextHolder.remove();
    }

    /**
     * Associate the given LocaleContext with the current thread.
     * <p>
     * The given LocaleContext may be a {@link TimeZoneAwareLocaleContext}, containing a locale with associated time
     * zone information.
     * 
     * @param localeContext the current LocaleContext, or {@code null} to reset the thread-bound context for child
     * threads (using an {@link InheritableThreadLocal})
     * @see SimpleLocaleContext
     * @see SimpleTimeZoneAwareLocaleContext
     */
    public static void setLocaleContext(LocaleContext localeContext) {
        if (localeContext == null) {
            resetLocaleContext();
        } else {
            localeContextHolder.set(localeContext);
        }
    }

    /**
     * Return the LocaleContext associated with the current thread, if any.
     * 
     * @return the current LocaleContext, or {@code null} if none
     */
    public static LocaleContext getLocaleContext() {
        LocaleContext localeContext = localeContextHolder.get();
        return localeContext;
    }

    /**
     * Associate the given Locale with the current thread, preserving any TimeZone that may have been set already.
     * <p>
     * Will implicitly create a LocaleContext for the given Locale.
     * 
     * @param locale the current Locale, or {@code null} to reset the locale part of thread-bound context
     * @see #setTimeZone(TimeZone)
     * @see SimpleLocaleContext#SimpleLocaleContext(Locale)
     */
    public static void setLocale(Locale locale) {
        LocaleContext localeContext = getLocaleContext();
        TimeZone timeZone = (localeContext instanceof TimeZoneAwareLocaleContext ? ((TimeZoneAwareLocaleContext) localeContext).getTimeZone() : null);
        if (timeZone != null) {
            localeContext = new SimpleTimeZoneAwareLocaleContext(locale, timeZone);
        } else if (locale != null) {
            localeContext = new SimpleLocaleContext(locale);
        } else {
            localeContext = null;
        }
        setLocaleContext(localeContext);
    }

    /**
     * Return the Locale associated with the current thread, if any, or the system default Locale else. This is
     * effectively a replacement for {@link java.util.Locale#getDefault()}, able to optionally respect a user-level
     * Locale setting.
     * <p>
     * Note: This method has a fallback to the system default Locale. If you'd like to check for the raw LocaleContext
     * content (which may indicate no specific locale through {@code null}, use {@link #getLocaleContext()} and call
     * {@link LocaleContext#getLocale()}
     * 
     * @return the current Locale, or the system default Locale if no specific Locale has been associated with the
     * current thread
     * @see LocaleContext#getLocale()
     * @see java.util.Locale#getDefault()
     */
    public static Locale getLocale() {
        LocaleContext localeContext = getLocaleContext();
        if (localeContext != null) {
            Locale locale = localeContext.getLocale();
            if (locale != null) {
                return locale;
            }
        }

        return null;
    }

    /**
     * Associate the given TimeZone with the current thread, preserving any Locale that may have been set already.
     * <p>
     * Will implicitly create a LocaleContext for the given Locale.
     * 
     * @param timeZone the current TimeZone, or {@code null} to reset the time zone part of the thread-bound context
     * @see #setLocale(Locale)
     * @see SimpleTimeZoneAwareLocaleContext#SimpleTimeZoneAwareLocaleContext(Locale, TimeZone)
     */
    public static void setTimeZone(TimeZone timeZone) {
        LocaleContext localeContext = getLocaleContext();
        Locale locale = (localeContext != null ? localeContext.getLocale() : null);
        if (timeZone != null) {
            localeContext = new SimpleTimeZoneAwareLocaleContext(locale, timeZone);
        } else if (locale != null) {
            localeContext = new SimpleLocaleContext(locale);
        } else {
            localeContext = null;
        }
        setLocaleContext(localeContext);
    }

    /**
     * Return the TimeZone associated with the current thread, if any, or the system default TimeZone else. This is
     * effectively a replacement for {@link java.util.TimeZone#getDefault()}, able to optionally respect a user-level
     * TimeZone setting.
     * <p>
     * Note: This method has a fallback to the system default Locale. If you'd like to check for the raw LocaleContext
     * content (which may indicate no specific time zone through {@code null}, use {@link #getLocaleContext()} and call
     * {@link TimeZoneAwareLocaleContext#getTimeZone()} after downcasting to {@link TimeZoneAwareLocaleContext}.
     * 
     * @return the current TimeZone, or the system default TimeZone if no specific TimeZone has been associated with the
     * current thread
     * @see TimeZoneAwareLocaleContext#getTimeZone()
     * @see java.util.TimeZone#getDefault()
     */
    public static TimeZone getTimeZone() {
        LocaleContext localeContext = getLocaleContext();
        if (localeContext instanceof TimeZoneAwareLocaleContext) {
            TimeZone timeZone = ((TimeZoneAwareLocaleContext) localeContext).getTimeZone();
            if (timeZone != null) {
                return timeZone;
            }
        }
        return TimeZone.getDefault();
    }
}
