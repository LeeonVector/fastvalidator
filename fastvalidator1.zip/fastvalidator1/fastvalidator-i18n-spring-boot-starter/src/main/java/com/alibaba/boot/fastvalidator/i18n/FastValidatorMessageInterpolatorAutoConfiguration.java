package com.alibaba.boot.fastvalidator.i18n;

import javax.validation.MessageInterpolator;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.MessageSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import com.alibaba.boot.fastvalidator.i18n.interpolator.FastValidatorI18nMessageInterpolator;

/**
 * Fast Validator message interpolator of MCMS auto configuration.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-08
 */
@AutoConfigureAfter(MessageSourceAutoConfiguration.class)
@ConditionalOnBean(MessageSource.class)
public class FastValidatorMessageInterpolatorAutoConfiguration {

    @Bean
    public MessageInterpolator mcmsMessageInterpolator(MessageSource messageSource){
        return new FastValidatorI18nMessageInterpolator(messageSource);
    }

}
