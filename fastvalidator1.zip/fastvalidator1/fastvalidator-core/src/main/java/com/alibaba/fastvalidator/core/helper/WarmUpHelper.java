package com.alibaba.fastvalidator.core.helper;

import java.io.IOException;
import java.util.Set;

import javax.validation.Validator;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
import org.springframework.core.type.filter.TypeFilter;

import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.prompt.FastValidatorLogger;

/**
 * Helper class for warm up.
 *
 * @author: jasen.zhangj
 * @date: 2017/3/13.
 */
public class WarmUpHelper {


    /***
     * Warm up for specific package for a specific validator
     * 
     * @param validateBeanPackage the package of bean annotated with {@link ValidateBean}
     * @param validator {@link Validator}
     */
    public static void warmUpValidateBean(String validateBeanPackage, Validator validator) {
        if (StringUtils.isNotBlank(validateBeanPackage) && validator != null) {
            FastValidatorLogger.getFastValidatLog().info("", "fastvalidtor warmup package: " + validateBeanPackage);

            ClassPathScanningCandidateComponentProvider scanner = new ClassPathScanningCandidateComponentProvider(false);
            scanner.setMetadataReaderFactory(new SimpleMetadataReaderFactory());
            scanner.addIncludeFilter(new ValidateBeanTypeFilter());

            Set<BeanDefinition> set = scanner.findCandidateComponents(validateBeanPackage);

            if (set != null) {
                for (BeanDefinition beanDefinition : set) {
                    try {
                        validator.validate(Class.forName(beanDefinition.getBeanClassName()).newInstance());
                    } catch (Exception e) {
                        FastValidatorLogger.getFastValidatLog().error("WARMUP", "can't warmup class " + beanDefinition.getBeanClassName(), e);
                    }
                }
            }
        }
    }

    static class ValidateBeanTypeFilter implements TypeFilter {

        @Override
        public boolean match(MetadataReader metadataReader,
                             MetadataReaderFactory metadataReaderFactory) throws IOException {
            return metadataReader.getAnnotationMetadata().isAnnotated(ValidateBean.class.getName());
        }
    }
}
