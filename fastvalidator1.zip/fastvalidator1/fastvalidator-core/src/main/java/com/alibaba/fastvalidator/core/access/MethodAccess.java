package com.alibaba.fastvalidator.core.access;

import java.lang.reflect.Method;
import org.springframework.util.ReflectionUtils;

/**
 * Method access strategy
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public class MethodAccess implements AccessStrategy {

    private Method method;

    public MethodAccess(Method method){
        this.method = method;
    }

    @Override
    public void set(Object instance, Object args) {
        ReflectionUtils.invokeMethod(this.method, instance, args);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("MethodAccess{");
        sb.append("method=").append(method);
        sb.append('}');
        return sb.toString();
    }
}
