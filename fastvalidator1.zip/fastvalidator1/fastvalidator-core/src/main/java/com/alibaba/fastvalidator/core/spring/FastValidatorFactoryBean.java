package com.alibaba.fastvalidator.core.spring;

import javax.validation.MessageInterpolator;
import javax.validation.Validator;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import com.alibaba.fastvalidator.core.FastValidator;

import static com.alibaba.fastvalidator.core.helper.WarmUpHelper.warmUpValidateBean;

/**
 * fast validator factory bean, it will warming the java bean in special package.
 * 
 * @author: jasen.zhangj
 * @created: 2016-11-20
 */
public class FastValidatorFactoryBean implements FactoryBean<Validator>, InitializingBean {

    private String    validateBeanPackage;

    private Validator validator;

    private boolean failFast = true;
    private boolean logValidateDetail = false;
    private MessageInterpolator messageInterpolator;

    @Override
    public void afterPropertiesSet() {
        validator = FastValidator.builder().failFast(failFast).logValidateDetail(logValidateDetail).messageInterpolator(messageInterpolator).build();
        warmUpValidateBean(this.validateBeanPackage, validator);
    }

    @Override
    public Validator getObject() throws Exception {
        return validator;
    }

    @Override
    public Class<?> getObjectType() {
        return Validator.class;
    }

    @Override
    public boolean isSingleton() {
        return false;
    }

    public void setValidateBeanPackage(String validateBeanPackage) {
        this.validateBeanPackage = validateBeanPackage;
    }

    public void setFailFast(boolean failFast) {
        this.failFast = failFast;
    }

    public void setLogValidateDetail(boolean logValidateDetail) {
        this.logValidateDetail = logValidateDetail;
    }

    public void setMessageInterpolator(MessageInterpolator messageInterpolator) {
        this.messageInterpolator = messageInterpolator;
    }
}
