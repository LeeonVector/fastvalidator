package com.alibaba.fastvalidator.core;

import javax.validation.Configuration;
import javax.validation.MessageInterpolator;
import javax.validation.Validation;
import javax.validation.Validator;

import com.alibaba.fastvalidator.jsr.FastValidatorConfiguration;
import com.alibaba.fastvalidator.jsr.FastValidatorValidationProvider;

/**
 * Validator builder
 *
 * @author: jasen.zhangj
 * @date: 2017/3/1.
 */
public class FastValidator {

    private FastValidator() {

    }

    public static Builder builder() {
        return new Builder();
    }

    /***
     * @see {@link com.alibaba.fastvalidator.meta.MetaValidator} or {@link javax.validation.Validator}
     */
    public static final class Builder {

        boolean             failFast          = true;
        boolean             logValidateDetail = false;
        MessageInterpolator messageInterpolator;

        public Builder failFast(boolean failFast) {
            this.failFast = failFast;
            return this;
        }

        public Builder logValidateDetail(boolean logValidateDetail) {
            this.logValidateDetail = logValidateDetail;
            return this;
        }

        public Builder messageInterpolator(MessageInterpolator messageInterpolator) {
            this.messageInterpolator = messageInterpolator;
            return this;
        }

        public Validator build() {
            Configuration<FastValidatorConfiguration> configuration = Validation.byProvider(FastValidatorValidationProvider.class).configure().failFast(failFast).logValidateDetail(logValidateDetail).messageInterpolator(messageInterpolator);
            return configuration.buildValidatorFactory().getValidator();
        }
    }

}
