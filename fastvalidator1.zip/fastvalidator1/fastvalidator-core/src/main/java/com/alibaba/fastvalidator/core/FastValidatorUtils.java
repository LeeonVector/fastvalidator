package com.alibaba.fastvalidator.core;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.alibaba.fastvalidator.constraints.exception.FastValidatorException;
import com.alibaba.fastvalidator.core.helper.FastValidatorHelper;
import com.alibaba.fastvalidator.meta.MetaValidator;
import com.alibaba.fastvalidator.meta.ValidationMeta;

/**
 * Fast validator utils
 *
 * @author: jasen.zhangj
 * @date: 16/9/14.
 */
public class FastValidatorUtils {

    private static final Validator     VALIDATOR;
    private static final MetaValidator META_VALIDATOR;

    static {
        VALIDATOR = FastValidator.builder().failFast(true).build();
        META_VALIDATOR = VALIDATOR.unwrap(MetaValidator.class);
    }

    /***
     * @see {@link FastValidator}
     */
    public static Validator getValidator() {
        return VALIDATOR;
    }

    /***
     * @see {@link FastValidator}
     */
    public static MetaValidator getMetaValidator(){
        return META_VALIDATOR;
    }

    /***
     * validate (POJO)bean.
     *
     * @param bean to be validated (POJO)bean.
     * @param <T>
     * @return success if the result is empty; or else failed, {@link ConstraintViolation} describe the information for
     * constraint violation
     */
    public static <T> Set<ConstraintViolation<T>> validate(T bean) {
        return VALIDATOR.validate(bean);
    }

    /***
     * validate (POJO)bean with spefic groups.
     *
     * @param bean to be validated (POJO)bean.
     * @param <T>
     * @param groups groups
     * @return success if the result is empty; or else failed, {@link ConstraintViolation} describe the information for
     * constraint violation
     */
    public static <T> Set<ConstraintViolation<T>> validate(T bean, Class<?>... groups) {
        return VALIDATOR.validate(bean, groups);
    }

    /***
     * Validate the object through the metadata.
     *
     * @param meta validation meta eg: {@link ValidationMeta} or
     * {@link com.alibaba.fastvalidator.meta.ComposedValidationMeta}
     * @param object to be validated object
     * @param groups the validate group, default is DEFAULT group.
     * @param <E> {@link ValidationMeta}
     * @param <O> to be validated object
     * @return success if the result is empty; or else failed, {@link ConstraintViolation} describe the information for
     * constraint violation
     */
    <E extends ValidationMeta, O extends Object> Set<ConstraintViolation<O>> validateByMeta(E meta, O object,
                                                                                            Class<?>... groups) {
        return META_VALIDATOR.validateByMeta(meta, object, groups);
    }

    /***
     * validate (POJO)bean, throw exception if failed.
     * 
     * @param bean to be validated (POJO)bean.
     * @param <T>
     * @throws FastValidatorException {@link FastValidatorException}
     */
    public static <T> void validateUnQuite(T bean) throws FastValidatorException {
        Set<ConstraintViolation<T>> constraintViolations = VALIDATOR.validate(bean);
        if (constraintViolations != null && !constraintViolations.isEmpty()) {
            ConstraintViolation constraintViolation = constraintViolations.iterator().next();
            FastValidatorHelper.throwFastValidateException(constraintViolation);
        }
    }
}
