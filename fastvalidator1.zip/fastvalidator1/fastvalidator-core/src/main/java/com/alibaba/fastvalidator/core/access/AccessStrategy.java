package com.alibaba.fastvalidator.core.access;

/**
 * Abstract class to encapsulate different strategies
 * to set the value to the target object.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public interface AccessStrategy {

    /**
     * Set the value for the given instance with specifal arguments.
     * @param instance
     * @param args arguments
     * @throws IllegalArgumentException in case of an error
     */
    void set(Object instance, Object args);
}
