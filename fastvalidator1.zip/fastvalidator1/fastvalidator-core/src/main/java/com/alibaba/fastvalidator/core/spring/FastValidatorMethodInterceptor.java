package com.alibaba.fastvalidator.core.spring;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.executable.ExecutableValidator;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;

import com.alibaba.fastvalidator.constraints.FVCode;
import com.alibaba.fastvalidator.constraints.FVMessage;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.ConstraintMessage;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageHelper;
import com.alibaba.fastvalidator.core.FastValidatorUtils;
import com.alibaba.fastvalidator.core.access.AccessStrategy;
import com.alibaba.fastvalidator.core.access.FieldAccess;
import com.alibaba.fastvalidator.core.access.MethodAccess;
import com.alibaba.fastvalidator.core.helper.FastValidatorHelper;
import com.alibaba.fastvalidator.jsr.bean.Validate;

/**
 * method interceptor for validate
 *
 * @author: jasen.zhangj
 * @created: 2016-11-21
 */
public class FastValidatorMethodInterceptor implements MethodInterceptor, InitializingBean {

    private ExecutableValidator                                      methodValidator;

    /**
     * The default initial capacity for this cache.
     */
    static final int                                                 DEFAULT_INITIAL_CAPACITY  = 64;

    private static final Map<Method, MethodConstraintsInfo> methodParamsConstraintMap = new ConcurrentHashMap<>(DEFAULT_INITIAL_CAPACITY);
    private static final Map<Method, ReturnTypeInfo>        methodReturnTypeMap       = new ConcurrentHashMap<>(DEFAULT_INITIAL_CAPACITY);

    private static final FastValidatorConstraintHelper      constraintHelper          = FastValidatorConstraintHelper.getInstance();
    private static final Log                                LOG                       = LogFactory.getLog(FastValidatorMethodInterceptor.class);
    private static final Log                                VALIDATE_LOG              = LogFactory.getLog("fastvalidator");

    public FastValidatorMethodInterceptor() {
        this(null);
    }

    public FastValidatorMethodInterceptor(Validator validator) {
        if (validator != null) {
            methodValidator = validator.forExecutables();
        }
    }

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
        Method method = invocation.getMethod();
        MethodConstraintsInfo methodConstraintsInfo = methodParamsConstraintMap.get(method);
        if (methodConstraintsInfo == null) {
            methodConstraintsInfo = new MethodConstraintsInfo();

            initMethodConstraintsInfo(methodConstraintsInfo, method);
            determineValidationGroups(methodConstraintsInfo, invocation);
            methodParamsConstraintMap.put(method, methodConstraintsInfo);
        }

        if (methodConstraintsInfo.hasConstraint()) {
            Object constraintViolation = validateMethod(invocation, methodConstraintsInfo);
            return constraintViolation;
        } else {
            return invocation.proceed();
        }
    }

    protected Object validateMethod(MethodInvocation invocation,
                                    MethodConstraintsInfo methodConstraintsInfo) throws Throwable {
        Set<? extends ConstraintViolation<Object>> result = methodValidator.validateParameters(invocation.getThis(),
                                                                                               invocation.getMethod(),
                                                                                               invocation.getArguments(),
                                                                                               methodConstraintsInfo.groups);
        if (!result.isEmpty()) {
            ConstraintViolation<Object> constraintViolation = result.iterator().next();
            String message = constraintViolation.getMessage();
            ConstraintMessage constraintMessage = MessageHelper.getConstraintMessage(message);

            // if code is blank, append the root cause to message.
            if (StringUtils.isBlank(constraintMessage.getCode())) {
                constraintMessage.setMessage(FastValidatorHelper.getRootCausePath(constraintViolation));
            }

            return getReturnValue(invocation, constraintMessage, constraintViolation);
        } else {
            Object proceedResult =  invocation.proceed();
            if (methodConstraintsInfo.hasReturnValueConstraints){
                result =  methodValidator.validateReturnValue(invocation.getThis(), invocation.getMethod(), proceedResult, methodConstraintsInfo.groups);
                if (!result.isEmpty()) {
                    ConstraintViolation<Object> constraintViolation = result.iterator().next();
                    FastValidatorHelper.throwFastValidateException(constraintViolation);
                }
            }

            return proceedResult;
        }
    }

    protected void initMethodConstraintsInfo(MethodConstraintsInfo methodConstraintsInfo,  Method method) {
        Annotation[] anns = method.getDeclaredAnnotations();
        for (Annotation ann : anns) {
            if (constraintHelper.isConstraintAnnotation(ann.annotationType())){
                methodConstraintsInfo.hasParameterConstraints = true;
                methodConstraintsInfo.hasReturnValueConstraints = true;
                return;
            }
        }

        Annotation[][] parameterAnnotations = method.getParameterAnnotations();
        for (Annotation[] parameterAnnotation : parameterAnnotations) {
            for (Annotation annotation : parameterAnnotation) {
                if (annotation.annotationType() == Valid.class || annotation.annotationType() == Validate.class
                    || constraintHelper.isConstraintAnnotation(annotation.annotationType())) {
                    methodConstraintsInfo.hasParameterConstraints = true;
                    return;
                }
            }
        }


        Class<?> declaringClass = method.getDeclaringClass();
        if (!declaringClass.isInterface()){
            Class<?>[] declaringClassInterfaces = ClassUtils.getAllInterfacesForClass(declaringClass);
            if (declaringClassInterfaces != null){
                for (Class<?> declaringClassInterface : declaringClassInterfaces) {
                    if (ClassUtils.hasMethod(declaringClassInterface, method.getName(), method.getParameterTypes())){
                        initMethodConstraintsInfo(methodConstraintsInfo, ClassUtils.getMethod(declaringClassInterface, method.getName(), method.getParameterTypes()));
                    }
                }
            }
        }
    }

    /**
     * Determine the validation groups to validate against for the given method invocation.
     * <p>
     * Default are the validation groups as specified in the {@link Validate} annotation on the containing target class
     * of the method.
     * 
     * @param invocation the current MethodInvocation
     * @return the applicable validation groups as a Class array
     */
    protected void determineValidationGroups(MethodConstraintsInfo methodConstraintsInfo, MethodInvocation invocation) {
        Validate validatedAnn = AnnotationUtils.findAnnotation(invocation.getMethod(), Validate.class);
        if (validatedAnn == null) {
            validatedAnn = AnnotationUtils.findAnnotation(invocation.getThis().getClass(), Validate.class);
        }

        if (validatedAnn != null && returnTypeIsValidateBean(invocation)){
            methodConstraintsInfo.hasReturnValueConstraints = true;
        }

        Class<?>[] groups =  (validatedAnn != null ? validatedAnn.groups() : new Class<?>[0]);
        methodConstraintsInfo.groups = groups;
    }

    private boolean returnTypeIsValidateBean(MethodInvocation methodInvocation) {
        Method method = methodInvocation.getMethod();
        Class<?> returnType = method.getReturnType();
        if (returnType == Void.class || returnType == null){
            return false;
        }

        return returnType.getAnnotation(ValidateBean.class) != null;
    }

    protected Object getReturnValue(MethodInvocation methodInvocation, ConstraintMessage constraintMessage,
                                    ConstraintViolation<Object> constraintViolation) {
        Method method = methodInvocation.getMethod();
        Class<?> returnType = method.getReturnType();

        ReturnTypeInfo returnTypeInfo = methodReturnTypeMap.get(method);
        if (returnTypeInfo != null) {
            return returnTypeInfo.invoke(constraintMessage.getCode(), constraintMessage.getMessage(),
                                         constraintViolation);
        } else {
            AccessStrategy code = getAccessStrategy(returnType, FV_CODE_FIELD_FILTER, FV_CODE_METHOD_FILTER,
                                                        "setFVCode");
            AccessStrategy message = getAccessStrategy(returnType, FV_MESSAGE_FIELD_FILTER,
                                                           FV_MESSAGE_METHOD_FILTER, "setFVMessage");

            returnTypeInfo = new ReturnTypeInfo(code, message, returnType);
            methodReturnTypeMap.put(method, returnTypeInfo);

            return returnTypeInfo.invoke(constraintMessage.getCode(), constraintMessage.getMessage(),
                                         constraintViolation);
        }
    }

    protected AccessStrategy getAccessStrategy(Class<?> target, ReflectionUtils.FieldFilter fieldFilter,
                                               ReflectionUtils.MethodFilter methodFilter,
                                               String defaultMethodName) {
        if (target == Void.TYPE){
            return null;
        }

        final List<Field> fieldList = new ArrayList<>();
        ReflectionUtils.doWithFields(target, new ReflectionUtils.FieldCallback() {

            @Override
            public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
                fieldList.add(field);
            }
        }, fieldFilter);
        if (!fieldList.isEmpty()) {
            return new FieldAccess(fieldList.get(0));
        }

        final List<Method> methods = new ArrayList<>();
        ReflectionUtils.doWithMethods(target, new ReflectionUtils.MethodCallback() {

            @Override
            public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
                methods.add(method);
            }
        }, methodFilter);
        if (!methods.isEmpty()) {
            return new MethodAccess(methods.get(0));
        }

        Method defaultMethod = ReflectionUtils.findMethod(target, defaultMethodName, String.class);
        return defaultMethod != null ? new MethodAccess(defaultMethod) : null;
    }

    public void setValidator(Validator validator) {
        this.methodValidator = validator.forExecutables();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (methodValidator == null) {
            methodValidator = FastValidatorUtils.getValidator().forExecutables();
        }
    }

    static class MethodConstraintsInfo {

        boolean hasParameterConstraints = false;
        boolean hasReturnValueConstraints = false;
        Class[] groups        = null;

        public boolean hasConstraint(){
            return hasParameterConstraints || hasReturnValueConstraints;
        }
    }

    static class ReturnTypeInfo {

        AccessStrategy codeAccessStrategy;
        AccessStrategy messageAccessStrategy;
        Class<?>       returnType;
        boolean        isVoidType;

        private ReturnTypeInfo(AccessStrategy codeAccessStrategy, AccessStrategy messageAccessStrategy,
                               Class<?> returnType) {
            this.codeAccessStrategy = codeAccessStrategy;
            this.messageAccessStrategy = messageAccessStrategy;
            this.returnType = returnType;
            this.isVoidType = returnType == Void.TYPE;
        }

        public boolean isValid() {
            return codeAccessStrategy != null || messageAccessStrategy != null;
        }

        public Object invoke(String code, String message, ConstraintViolation<Object> constraintViolation) {
            if (isVoidType) {
                FastValidatorHelper.throwFastValidateException(constraintViolation);
                return null;
            }

            if (isValid()) {
                if (VALIDATE_LOG.isDebugEnabled()) {
                    VALIDATE_LOG.debug(getLogMessage(constraintViolation, code, message));
                }

                Object returnObject = BeanUtils.instantiate(returnType);
                invokeMethod(returnObject, code, codeAccessStrategy);
                invokeMethod(returnObject, message, messageAccessStrategy);
                return returnObject;
            } else {
                FastValidatorHelper.throwFastValidateException(constraintViolation);
                return null;
            }
        }

        private String getLogMessage(ConstraintViolation<Object> constraintViolation, String code, String message) {
            Path path = constraintViolation.getPropertyPath();
            StringBuffer validateMessage = new StringBuffer(constraintViolation.getRootBean().getClass().getSimpleName()).append(".");
            for (Path.Node node : path) {
                validateMessage.append(node.getName()).append(".");
            }

            validateMessage.setLength(validateMessage.length() - 1);

            validateMessage.append("|").append(code).append("|").append(message);
            return validateMessage.toString();
        }

        private static void invokeMethod(Object target, String value, AccessStrategy accessStrategy) {
            if (StringUtils.isNotBlank(value) && accessStrategy != null) {
                try {
                    accessStrategy.set(target, value);
                } catch (Exception e) {
                    LOG.error("invoke method " + accessStrategy + " failed", e);
                }
            }
        }
    }

    private static final Class[]              METHOD_PARAMETER_TYPES   = { String.class };
    static final ReflectionUtils.MethodFilter FV_CODE_METHOD_FILTER    = new ReflectionUtils.MethodFilter() {

                                                                           @Override
                                                                           public boolean matches(Method method) {

                                                                               return method.getAnnotation(FVCode.class) != null
                                                                                      && method.getReturnType() == Void.TYPE
                                                                                      && Arrays.equals(METHOD_PARAMETER_TYPES,
                                                                                                       method.getParameterTypes());
                                                                           }
                                                                       };

    static final ReflectionUtils.FieldFilter  FV_CODE_FIELD_FILTER     = new ReflectionUtils.FieldFilter() {

                                                                           @Override
                                                                           public boolean matches(Field field) {
                                                                               return field.isAnnotationPresent(FVCode.class);
                                                                           }
                                                                       };

    static final ReflectionUtils.MethodFilter FV_MESSAGE_METHOD_FILTER = new ReflectionUtils.MethodFilter() {

                                                                           @Override
                                                                           public boolean matches(Method method) {
                                                                               return method.getAnnotation(FVMessage.class) != null
                                                                                      && method.getReturnType() == Void.TYPE
                                                                                      && Arrays.equals(METHOD_PARAMETER_TYPES,
                                                                                                       method.getParameterTypes());
                                                                           }
                                                                       };

    static final ReflectionUtils.FieldFilter  FV_MESSAGE_FIELD_FILTER  = new ReflectionUtils.FieldFilter() {

                                                                           @Override
                                                                           public boolean matches(Field field) {
                                                                               return field.isAnnotationPresent(FVMessage.class);
                                                                           }
                                                                       };
}
