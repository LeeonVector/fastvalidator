package com.alibaba.fastvalidator.core.helper;

import javax.validation.ConstraintViolation;
import javax.validation.Path;

import com.alibaba.fastvalidator.constraints.exception.FastValidatorException;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.ConstraintMessage;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageHelper;

/**
 * Helper for fastvalidator
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public class FastValidatorHelper {

    /***
     * Throw exception for {@link ConstraintViolation}
     *
     * @param constraintViolation {@link ConstraintViolation}
     * @throws FastValidatorException {@link FastValidatorException}
     */
    public static void throwFastValidateException(ConstraintViolation constraintViolation) throws FastValidatorException {
        String message = constraintViolation.getMessage();
        ConstraintMessage constraintMessage = MessageHelper.getConstraintMessage(message);

        FastValidatorException fastValidatorException = new FastValidatorException(getRootCausePath(constraintViolation));
        if (constraintMessage != null) {
            fastValidatorException.setCode(constraintMessage.getCode());
        }

        throw fastValidatorException;
    }

    /***
     * Get root cause path information
     * @param constraintViolation {@link ConstraintViolation}
     * @return root cause path.
     */
    public static String getRootCausePath(ConstraintViolation constraintViolation) {
        Path path = constraintViolation.getPropertyPath();
        StringBuilder validateMessage = new StringBuilder(constraintViolation.getRootBean().getClass().getSimpleName()).append(".");
        if (path != null) {
            for (Path.Node node : path) {
                validateMessage.append(node.getName()).append(".");
            }
        }

        validateMessage.setLength(validateMessage.length() - 1);
        validateMessage.append(" ").append(constraintViolation.getMessage());

        return validateMessage.toString();
    }
}
