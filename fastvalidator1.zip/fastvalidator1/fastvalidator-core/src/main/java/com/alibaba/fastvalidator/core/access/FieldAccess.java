package com.alibaba.fastvalidator.core.access;

import java.lang.reflect.Field;
import org.springframework.util.ReflectionUtils;

/**
 * Field access strategy
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public class FieldAccess implements AccessStrategy {

    private Field field;

    public FieldAccess(Field field){
        this.field = field;
    }

    @Override
    public void set(Object instance, Object args) {
        ReflectionUtils.makeAccessible(field);
        ReflectionUtils.setField(field, instance, args);
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("FieldAccess{");
        sb.append("field=").append(field);
        sb.append('}');
        return sb.toString();
    }
}
