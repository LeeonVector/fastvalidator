package com.alibaba.fastvalidator.core;

import junit.framework.TestCase;
import javax.validation.Validator;
import org.junit.Test;
import com.alibaba.fastvalidator.meta.MetaValidator;

/**
 * {@code FastValidatorUtils} test case
 *
 * @author: jasen.zhangj
 * @date: 16/9/18.
 */
public class FastValidatorUtilsTest extends TestCase{

    @Test
    public void testGetValidator() {
        Validator validator = FastValidator.builder().failFast(true).build();
        assertTrue(validator != null);

        MetaValidator metaValidator = validator.unwrap(MetaValidator.class);
        assertTrue(metaValidator != null);
    }
}
