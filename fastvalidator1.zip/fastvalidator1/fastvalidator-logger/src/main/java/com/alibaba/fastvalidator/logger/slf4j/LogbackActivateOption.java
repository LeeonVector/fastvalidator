package com.alibaba.fastvalidator.logger.slf4j;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import java.io.File;
import java.nio.charset.Charset;
import com.alibaba.fastvalidator.logger.ActivateOption;
import com.alibaba.fastvalidator.logger.support.LoggerHelper;


/**
 * {@link ActivateOption} implements for logback after 0.9.18 version.
 *
 * @author zhuyong
 * @author jasenzhang
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class LogbackActivateOption extends Logback918ActivateOption {

    public LogbackActivateOption(Object logger) {
        super(logger);
    }

    @Override
    protected ch.qos.logback.core.Appender getLogbackDailyRollingFileAppender(String productName, String file,
                                                                              String encoding) {
        RollingFileAppender appender = new RollingFileAppender();
        LoggerContext loggerContext = LogbackLoggerContextUtil.getLoggerContext();
        appender.setContext(loggerContext);

        String appenderName = productName + "." + file.replace(File.separatorChar, '.') + ".Appender";
        appender.setName(appenderName);
        appender.setAppend(true);
        String logFile = LoggerHelper.getLogFile(productName, file);
        appender.setFile(logFile);

        TimeBasedRollingPolicy rolling = new TimeBasedRollingPolicy();
        rolling.setParent(appender);
        rolling.setFileNamePattern(logFile + ".%d{yyyy-MM-dd}");
        rolling.setContext(loggerContext);
        rolling.start();
        appender.setRollingPolicy(rolling);

        PatternLayoutEncoder layout = new PatternLayoutEncoder();
        layout.setPattern(LoggerHelper.getPattern());
        layout.setCharset(Charset.forName(encoding));
        appender.setEncoder(layout);
        layout.setContext(loggerContext);
        layout.start();

        removeFileNameCollision(loggerContext, appenderName, logFile);
        appender.start();

        return appender;
    }

    @Override
    protected ch.qos.logback.core.Appender getLogbackDailyAndSizeRollingFileAppender(String productName, String file,
                                                                                     String encoding, String size) {
        RollingFileAppender appender = new RollingFileAppender();
        LoggerContext loggerContext = LogbackLoggerContextUtil.getLoggerContext();
        appender.setContext(loggerContext);

        String appenderName = productName + "." + file.replace(File.separatorChar, '.') + ".Appender";


        appender.setName(appenderName);
        appender.setAppend(true);
        String fileName = LoggerHelper.getLogFile(productName, file);
        appender.setFile(fileName);

        TimeBasedRollingPolicy rolling = new TimeBasedRollingPolicy();
        rolling.setParent(appender);
        rolling.setFileNamePattern(fileName + ".%d{yyyy-MM-dd}.%i");
        rolling.setContext(loggerContext);

        SizeAndTimeBasedFNATP fnatp = new SizeAndTimeBasedFNATP();
        fnatp.setMaxFileSize(size);
        fnatp.setTimeBasedRollingPolicy(rolling);
        rolling.setTimeBasedFileNamingAndTriggeringPolicy(fnatp);

        rolling.start();
        appender.setRollingPolicy(rolling);

        PatternLayoutEncoder layout = new PatternLayoutEncoder();
        layout.setPattern(LoggerHelper.getPattern());
        layout.setCharset(Charset.forName(encoding));
        appender.setEncoder(layout);
        layout.setContext(loggerContext);
        layout.start();

        removeFileNameCollision(loggerContext, appenderName, fileName);
        appender.start();

        return appender;
    }
}
