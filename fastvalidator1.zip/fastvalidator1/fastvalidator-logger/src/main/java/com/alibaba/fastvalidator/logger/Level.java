package com.alibaba.fastvalidator.logger;

/**
 * Log level
 *
 * @author zhuyong
 * @author jasenzhang
 */
public enum Level {
    DEBUG("DEBUG"), INFO("INFO"), WARN("WARN"), ERROR("ERROR");

    private String name;

    Level(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
