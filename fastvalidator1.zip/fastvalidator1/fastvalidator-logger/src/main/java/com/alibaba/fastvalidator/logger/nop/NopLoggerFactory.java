package com.alibaba.fastvalidator.logger.nop;


import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.support.ILoggerFactory;

/***
 * Log factory for {@link NopLogger}
 *
 * @author jasenzhang
 */
public class NopLoggerFactory implements ILoggerFactory {

    @Override
    public Logger getLogger(Class<?> clazz) {
        return new NopLogger();
    }

    @Override
    public Logger getLogger(String name) {
        return new NopLogger();
    }
}
