package com.alibaba.fastvalidator.logger;


/**
 * <pre>
 * Logger for log.
 *
 * log layout：01 %d{yyyy-MM-dd HH:mm:ss.SSS} %p [%-5t:%c{2}] %m%n
 *
 * 01                           log API version
 * d{yyyy-MM-dd HH:mm:ss.SSS}   datetime，eg.2014-03-19 20:55:08.501
 * %p                           log level. eg. INFO, DEBUG
 * [%-5t:%c{2}]                 thread name
 * %m                           log message
 * %n                           line separator
 *
 * log message's format ：[Context] + [ERROR-CODE] + Message + [Exception stack]
 * Context                      log context information
 * ERROR-CODE                   error code.
 * Message                      log message
 * Exception stack              exception stack trace
 *
 * </pre>
 *
 * @author zhuyong
 * @author jasenzhang
 */
public interface Logger<T> extends ActivateOption {

    /**
     * Debug log
     *
     * @param message log message
     */
    void debug(String message);

    /**
     * Debug log
     *
     * @param format log format. eg. 'Hi,{} {} {}'
     * @param args   log arguments
     */
    void debug(String format, Object... args);

    /**
     * Debug log
     *
     * @param context context info
     * @param message log message
     */
    void debug(String context, String message);

    /**
     * Debug log
     *
     * @param context context info
     * @param format  log format. eg. 'Hi,{} {} {}'
     * @param args    log arguments
     */
    void debug(String context, String format, Object... args);

    /**
     * Info log
     *
     * @param code    error code
     * @param message log message
     */
    void info(String code, String message);

    /**
     * Info log
     *
     * @param code   error code
     * @param format log format. eg. 'Hi,{} {} {}'
     * @param args   log arguments
     */
    void info(String code, String format, Object... args);

    /**
     * Info log
     *
     * @param code    error code
     * @param context context info
     * @param message log message
     */
    void info(String code, String context, String message);

    /**
     * Info log
     *
     * @param code    error code
     * @param context context info
     * @param format  log format. eg. 'Hi,{} {} {}'
     * @param args    log arguments
     */
    void info(String code, String context, String format, Object... args);

    /**
     * Warning log
     *
     * @param code    error code
     * @param message log message
     */
    void warn(String code, String message);

    /**
     * Warning log
     *
     * @param code   error code
     * @param format log format. eg. 'Hi,{} {} {}'
     * @param args   log arguments
     */
    void warn(String code, String format, Object... args);

    /**
     * Warning log
     *
     * @param code    error code
     * @param context context info
     * @param message log message
     */
    void warn(String code, String context, String message);

    /**
     * Warning log
     *
     * @param code    error code
     * @param context context info
     * @param format  log format. eg. 'Hi,{} {} {}'
     * @param args    log arguments
     */
    void warn(String code, String context, String format, Object... args);

    /**
     * Error log
     *
     * @param code    error code
     * @param message log message
     */
    void error(String code, String message);

    /**
     * 输出Error日志
     *
     * @param code    错误码，如HSF-0001；在日志国际化后，也对应的message code
     * @param message 日志信息
     * @param t       异常信息
     */
    void error(String code, String message, Throwable t);

    /**
     * 输出Error日志
     *
     * @param code   错误码，如HSF-0001；在日志国际化后，也对应的message code
     * @param format 日志信息格式化字符串，比如 'Hi,{} {} {}'
     */
    void error(String code, String format, Object... objs);

    /**
     * 输出Error日志
     *
     * @param context 日志上下文信息
     * @param code    错误码，如HSF-0001；在日志国际化后，也对应的message code
     * @param message 日志信息
     */
    void error(String context, String code, String message);

    /**
     * 输出Error日志
     *
     * @param context 日志上下文信息
     * @param code    错误码，如HSF-0001；在日志国际化后，也对应的message code
     * @param message 日志信息
     * @param t       异常信息
     */
    void error(String context, String code, String message, Throwable t);

    /**
     * 输出Error日志
     *
     * @param context 日志上下文信息
     * @param code    错误码，如HSF-0001；在日志国际化后，也对应的message code
     * @param format  日志信息格式化字符串，比如 'Hi,{} {} {}'
     * @param args    格式化串参数
     */
    void error(String context, String code, String format, Object... args);

    /**
     * 判断Debug级别是否开启
     */
    boolean isDebugEnabled();

    /**
     * 判断Info级别是否开启
     */
    boolean isInfoEnabled();

    /**
     * 判断Warn级别是否开启
     */
    boolean isWarnEnabled();

    /**
     * 判断Error级别是否开启
     */
    boolean isErrorEnabled();

    /**
     * 获取内部日志实现对象
     */
    T getDelegate();
}
