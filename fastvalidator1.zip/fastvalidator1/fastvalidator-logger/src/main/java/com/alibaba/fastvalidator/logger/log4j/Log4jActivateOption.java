package com.alibaba.fastvalidator.logger.log4j;

import java.io.File;
import java.util.Enumeration;
import org.apache.log4j.Appender;
import org.apache.log4j.AsyncAppender;
import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.PatternLayout;
import com.alibaba.fastvalidator.logger.Level;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.ActivateOption;
import com.alibaba.fastvalidator.logger.support.LoggerHelper;

/**
 * {@link ActivateOption} impolements for Log4j
 *
 * @author zhuyong 2014年3月20日 上午10:24:36
 */
public class Log4jActivateOption implements ActivateOption {

    protected org.apache.log4j.Logger logger;

    public Log4jActivateOption(org.apache.log4j.Logger logger) {
        this.logger = logger;
    }

    @Override
    public void activateAppender(String productName, String file, String encoding) {
        logger.removeAllAppenders();
        Appender appender =
                getLog4jDailyRollingFileAppender(productName, file, encoding);
        logger.addAppender(appender);
    }

    @Override
    public void activateAsyncAppender(String productName, String file, String encoding) {
        logger.removeAllAppenders();

        AsyncAppender asynAppender = new AsyncAppender();
        asynAppender.setName(productName + "." + file.replace(File.separatorChar, '.')
                + ".AsyncAppender");
        Appender appender =
                getLog4jDailyRollingFileAppender(productName, file, encoding);
        asynAppender.addAppender(appender);
        logger.addAppender(asynAppender);
    }

    @Override
    public void activateAppenderWithTimeAndSizeRolling(String productName, String file,
                                                       String encoding, String size) {
        activateAppender(productName, file, encoding);
    }

    @Override
    public void setLevel(Level level) {
        logger.setLevel(org.apache.log4j.Level.toLevel(level.getName()));
    }

    @Override
    public void setAdditivity(boolean additivity) {
        logger.setAdditivity(additivity);
    }

    protected Appender getLog4jDailyRollingFileAppender(String productName,
                                                        String file, String encoding) {
        DailyRollingFileAppender appender = new DailyRollingFileAppender();
        appender.setName(productName + "." + file.replace(File.separatorChar, '.') + ".Appender");
        appender.setLayout(new PatternLayout(LoggerHelper.getPattern()));
        appender.setAppend(true);
        appender.setFile(LoggerHelper.getLogFileP(productName, file));
        appender.setEncoding(encoding);
        appender.activateOptions();

        return appender;
    }

    @Override
    public void activateAppender(Logger logger) {
        if (!(logger.getDelegate() instanceof org.apache.log4j.Logger)) {
            throw new IllegalArgumentException("logger must be org.apache.log4j.Logger, but it's "
                    + logger.getDelegate().getClass());
        }
        activateAppender((org.apache.log4j.Logger) logger.getDelegate());
    }

    protected void activateAppender(org.apache.log4j.Logger logger) {
        this.logger.removeAllAppenders();

        Enumeration<?> enums = logger.getAllAppenders();
        while (enums != null && enums.hasMoreElements()) {
            this.logger.addAppender((Appender) enums.nextElement());
        }
    }
}
