package com.alibaba.fastvalidator.logger.log4j;

import org.apache.log4j.Level;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.support.LoggerSupport;
import com.alibaba.fastvalidator.logger.util.MessageUtil;

/***
 * Logger for log4j
 *
 * @author jasenzhang
 */
public class Log4jLogger extends LoggerSupport<org.apache.log4j.Logger> implements Logger {

    public Log4jLogger(org.apache.log4j.Logger delegate) {
        super(delegate);

        if (delegate == null) {
            throw new IllegalArgumentException("delegate Logger is null");
        }

        this.activateOption = new Log4jActivateOption(delegate);
    }

    @Override
    public void debug(String context, String message) {
        if (isDebugEnabled()) {
            delegateLogger.debug(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void debug(String context, String format, Object... args) {
        if (isDebugEnabled()) {
            delegateLogger.debug(MessageUtil.getMessage(context, MessageUtil.formatMessage(format, args)));
        }
    }

    @Override
    public void info(String code, String context, String message) {
        if (isInfoEnabled()) {
            delegateLogger.info(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void info(String code, String context, String format, Object... args) {
        if (isInfoEnabled()) {
            delegateLogger.info(MessageUtil.getMessage(context, MessageUtil.formatMessage(format, args)));
        }
    }

    @Override
    public void warn(String code, String context, String message) {
        if (isWarnEnabled()) {
            delegateLogger.warn(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void warn(String code, String context, String format, Object... args) {
        if (isWarnEnabled()) {
            delegateLogger.warn(MessageUtil.getMessage(context, MessageUtil.formatMessage(format, args)));
        }
    }

    @Override
    public void error(String context, String code, String message) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, code, message));
        }
    }

    @Override
    public void error(String context, String code, String message, Throwable t) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, code, message), t);
        }
    }

    @Override
    public void error(String context, String errorCode, String format, Object... args) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, errorCode, MessageUtil.formatMessage(format, args)));
        }
    }

    @Override
    public boolean isDebugEnabled() {
        return delegateLogger.isDebugEnabled();
    }

    @Override
    public boolean isInfoEnabled() {
        return delegateLogger.isInfoEnabled();
    }

    @Override
    public boolean isWarnEnabled() {
        return delegateLogger.isEnabledFor(Level.WARN);
    }

    @Override
    public boolean isErrorEnabled() {
        return delegateLogger.isEnabledFor(Level.ERROR);
    }
}
