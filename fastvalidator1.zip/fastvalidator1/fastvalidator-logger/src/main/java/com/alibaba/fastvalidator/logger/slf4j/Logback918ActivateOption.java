package com.alibaba.fastvalidator.logger.slf4j;

import ch.qos.logback.classic.AsyncAppender;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.SizeAndTimeBasedFNATP;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import java.io.File;
import java.util.Iterator;
import java.util.Map;
import com.alibaba.fastvalidator.logger.ActivateOption;
import com.alibaba.fastvalidator.logger.Level;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.support.LoggerHelper;


/**
 * {@link ActivateOption} implements for logback before 0.9.18 version.
 *
 * @author zhuyong
 * @author jasenzhang
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class Logback918ActivateOption implements ActivateOption {

    private ch.qos.logback.classic.Logger logger;

    public Logback918ActivateOption(Object logger) {
        if (logger instanceof ch.qos.logback.classic.Logger) {
            this.logger = (ch.qos.logback.classic.Logger) logger;
        } else {
            throw new IllegalArgumentException("logger must be instanceof ch.qos.logback.classic.Logger");
        }
    }

    @Override
    public void activateAppender(String productName, String file, String encoding) {
        logger.detachAndStopAllAppenders();

        ch.qos.logback.core.Appender appender =
                getLogbackDailyRollingFileAppender(productName, file, encoding);
        logger.addAppender(appender);
    }

    @Override
    public void activateAsyncAppender(String productName, String file, String encoding) {
        logger.detachAndStopAllAppenders();

        AsyncAppender asynAppender = new AsyncAppender();
        String name = productName + "." + file.replace(File.separatorChar, '.')
                + ".AsyncAppender";
        asynAppender.setName(name);
        asynAppender.setContext(LogbackLoggerContextUtil.getLoggerContext());
        ch.qos.logback.core.Appender appender =
                getLogbackDailyRollingFileAppender(productName, file, encoding);
        asynAppender.addAppender(appender);
        asynAppender.start();
        logger.addAppender(asynAppender);
    }

    @Override
    public void setLevel(Level level) {
        logger.setLevel(ch.qos.logback.classic.Level.valueOf(level.getName()));
    }

    @Override
    public void setAdditivity(boolean additivity) {
        logger.setAdditive(additivity);
    }

    @Override
    public void activateAppenderWithTimeAndSizeRolling(String productName, String file,
                                                       String encoding, String size) {
        logger.detachAndStopAllAppenders();

        ch.qos.logback.core.Appender appender =
                getLogbackDailyAndSizeRollingFileAppender(productName, file, encoding, size);
        logger.addAppender(appender);
    }

    protected ch.qos.logback.core.Appender getLogbackDailyRollingFileAppender(String productName,
                                                                              String file, String encoding) {
        RollingFileAppender appender = new RollingFileAppender();
        LoggerContext loggerContext = LogbackLoggerContextUtil.getLoggerContext();
        String appenderName = productName + "." + file.replace(File.separatorChar, '.') + ".Appender";
        appender.setContext(loggerContext);
        appender.setName(appenderName);
        appender.setAppend(true);

        String logFile = LoggerHelper.getLogFile(productName, file);
        appender.setFile(logFile);

        TimeBasedRollingPolicy rolling = new TimeBasedRollingPolicy();
        rolling.setParent(appender);
        rolling.setFileNamePattern(logFile + ".%d{yyyy-MM-dd}");
        rolling.setContext(loggerContext);
        rolling.start();
        appender.setRollingPolicy(rolling);

        PatternLayout layout = new PatternLayout();
        layout.setPattern(LoggerHelper.getPattern());
        layout.setContext(loggerContext);
        layout.start();
        appender.setLayout(layout);

        removeFileNameCollision(loggerContext, appenderName, logFile);
        appender.start();

        return appender;
    }

    protected void removeFileNameCollision(LoggerContext loggerContext, String appenderName, String fileName) {
        Object fileNameCollisionMap = loggerContext.getObject("RFA_FILENAME_COLLISION_MAP");
        if (fileNameCollisionMap instanceof Map) {
            ((Map) fileNameCollisionMap).remove(appenderName);
        }

        Object fileNamePatternMap = loggerContext.getObject("RFA_FILENAME_PATTERN_COLLISION_MAP");
        if (fileNamePatternMap instanceof Map){
            ((Map) fileNamePatternMap).remove(appenderName);
        }
    }

    protected ch.qos.logback.core.Appender getLogbackDailyAndSizeRollingFileAppender(
            String productName, String file, String encoding, String size) {
        RollingFileAppender appender = new RollingFileAppender();
        LoggerContext loggerContext = LogbackLoggerContextUtil.getLoggerContext();
        appender.setContext(loggerContext);

        String appenderName = productName + "." + file.replace(File.separatorChar, '.') + ".Appender";
        appender.setName(appenderName);
        appender.setAppend(true);
        String logFile = LoggerHelper.getLogFile(productName, file);
        appender.setFile(logFile);

        TimeBasedRollingPolicy rolling = new TimeBasedRollingPolicy();
        rolling.setParent(appender);
        rolling.setFileNamePattern(logFile + ".%d{yyyy-MM-dd}.%i");
        rolling.setContext(loggerContext);

        SizeAndTimeBasedFNATP fnatp = new SizeAndTimeBasedFNATP();
        fnatp.setMaxFileSize(size);
        fnatp.setTimeBasedRollingPolicy(rolling);
        rolling.setTimeBasedFileNamingAndTriggeringPolicy(fnatp);

        rolling.start();
        appender.setRollingPolicy(rolling);

        PatternLayout layout = new PatternLayout();
        layout.setPattern(LoggerHelper.getPattern());
        layout.setContext(loggerContext);
        layout.start();
        appender.setLayout(layout);

        removeFileNameCollision(loggerContext, appenderName, logFile);
        appender.start();

        return appender;
    }

    @Override
    public void activateAppender(Logger logger) {
        if (!(logger.getDelegate() instanceof ch.qos.logback.classic.Logger)) {
            throw new IllegalArgumentException("logger must be ch.qos.logback.classic.Logger, but it's "
                    + logger.getDelegate().getClass());
        }
        this.logger.detachAndStopAllAppenders();

        Iterator<ch.qos.logback.core.Appender<ILoggingEvent>> iter =
                ((ch.qos.logback.classic.Logger) logger.getDelegate()).iteratorForAppenders();
        while (iter.hasNext()) {
            ch.qos.logback.core.Appender<ILoggingEvent> appender = iter.next();
            this.logger.addAppender(appender);
        }
    }
}
