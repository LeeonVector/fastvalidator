package com.alibaba.fastvalidator.logger.support;


import com.alibaba.fastvalidator.logger.Logger;

/***
 * Logger factory
 *
 * @author jasenzhang
 */
public interface ILoggerFactory {

    Logger getLogger(Class<?> clazz);

    Logger getLogger(String name);
}
