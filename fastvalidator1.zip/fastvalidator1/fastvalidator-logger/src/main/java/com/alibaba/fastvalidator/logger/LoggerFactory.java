package com.alibaba.fastvalidator.logger;

import com.alibaba.fastvalidator.logger.log4j.Log4jLoggerFactory;
import com.alibaba.fastvalidator.logger.nop.NopLoggerFactory;
import com.alibaba.fastvalidator.logger.slf4j.Slf4jLoggerFactory;
import com.alibaba.fastvalidator.logger.support.ILoggerFactory;
import com.alibaba.fastvalidator.logger.support.LogLog;

/**
 * <pre>
 *
 * Support logging framework:
 *
 * log4j
 * slf4j + logback
 * slf4j + slf4j-log4j12 + log4j
 * jcl + log4j
 * jcl + jcl-over-slf4j + slf4j + logback
 *
 * </pre>
 *
 * @author zhuyong
 * @author jasenzhang
 */
public class LoggerFactory {

    private static volatile ILoggerFactory LOGGER_FACTORY;

    static {
        try {
            setLoggerFactory(new Slf4jLoggerFactory());
            LogLog.info("Init JM logger with Slf4jLoggerFactory");
        } catch (Throwable e1) {
            try {
                setLoggerFactory(new Log4jLoggerFactory());
                LogLog.info("Init JM logger with Log4jLoggerFactory");
            } catch (Throwable e2) {
                setLoggerFactory(new NopLoggerFactory());
                LogLog.warn("Init JM logger with NopLoggerFactory, pay attention.", e2);
            }
        }

    }

    private LoggerFactory() {
    }

    public static Logger getLogger(String name) {
        return LOGGER_FACTORY.getLogger(name);
    }

    public static Logger getLogger(Class<?> clazz) {
        return getLogger(clazz.getName());
    }

    private static void setLoggerFactory(ILoggerFactory loggerFactory) {
        if (loggerFactory != null) {
            LoggerFactory.LOGGER_FACTORY = loggerFactory;
        }
    }
}
