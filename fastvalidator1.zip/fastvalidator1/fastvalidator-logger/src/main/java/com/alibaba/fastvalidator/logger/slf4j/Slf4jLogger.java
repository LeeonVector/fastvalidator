package com.alibaba.fastvalidator.logger.slf4j;


import java.lang.reflect.Constructor;
import com.alibaba.fastvalidator.logger.ActivateOption;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.support.LoggerSupport;
import com.alibaba.fastvalidator.logger.util.MessageUtil;

/***
 * Logger for SLF4J
 *
 * @author jasenzhang
 */
public class Slf4jLogger extends LoggerSupport<org.slf4j.Logger> implements Logger {

    private static boolean CanUseEncoder = false;

    static {
        try {
            // logback从0.9.19开始采用encoder，@see http://logback.qos.ch/manual/encoders.html
            Class.forName("ch.qos.logback.classic.encoder.PatternLayoutEncoder");
            CanUseEncoder = true;
        } catch (ClassNotFoundException e) {
            CanUseEncoder = false;
        }
    }

    @SuppressWarnings("unchecked")
    public Slf4jLogger(org.slf4j.Logger delegate) {
        super(delegate);
        if (delegate == null) {
            throw new IllegalArgumentException("delegate Logger is null");
        }

        String activateOptionClass = null;
        // logback
        if (delegate.getClass().getName().equals("ch.qos.logback.classic.Logger")) {
            if (CanUseEncoder) {
                activateOptionClass = "com.alibaba.fastvalidator.logger.slf4j.LogbackActivateOption";
            } else {
                activateOptionClass = "com.alibaba.fastvalidator.logger.slf4j.Logback918ActivateOption";
            }
        } else if (delegate.getClass().getName().equals("org.slf4j.impl.Log4jLoggerAdapter")) {
            // log4j
            activateOptionClass = "com.alibaba.fastvalidator.logger.slf4j.Slf4jLog4jAdapterActivateOption";
        }

        try {
            Class<ActivateOption> clazz = (Class<ActivateOption>) Class.forName(activateOptionClass);
            Constructor<ActivateOption> c = clazz.getConstructor(Object.class);
            this.activateOption = c.newInstance(delegate);
        } catch (Exception e) {
            throw new IllegalArgumentException("delegate must be logback impl or slf4j-log4j impl", e);
        }
    }

    @Override
    public void debug(String context, String message) {
        if (isDebugEnabled()) {
            delegateLogger.debug(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void debug(String context, String format, Object... args) {
        if (isDebugEnabled()) {
            delegateLogger.debug(MessageUtil.getMessage(context, format), args);
        }
    }

    @Override
    public void info(String code, String context, String message) {
        if (isInfoEnabled()) {
            delegateLogger.info(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void info(String code, String context, String format, Object... args) {
        if (isInfoEnabled()) {
            delegateLogger.info(MessageUtil.getMessage(context, format), args);
        }
    }

    @Override
    public void warn(String code, String context, String message) {
        if (isWarnEnabled()) {
            delegateLogger.warn(MessageUtil.getMessage(context, message));
        }
    }

    @Override
    public void warn(String code, String context, String format, Object... args) {
        if (isWarnEnabled()) {
            delegateLogger.warn(MessageUtil.getMessage(context, format), args);
        }
    }

    @Override
    public void error(String context, String code, String message) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, code, message));
        }
    }

    @Override
    public void error(String context, String code, String message, Throwable t) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, code, message), t);
        }
    }

    @Override
    public void error(String context, String code, String format, Object... args) {
        if (isErrorEnabled()) {
            delegateLogger.error(MessageUtil.getMessage(context, code, format), args);
        }
    }

    @Override
    public boolean isDebugEnabled() {
        return delegateLogger.isDebugEnabled();
    }

    @Override
    public boolean isInfoEnabled() {
        return delegateLogger.isInfoEnabled();
    }

    @Override
    public boolean isWarnEnabled() {
        return delegateLogger.isWarnEnabled();
    }

    @Override
    public boolean isErrorEnabled() {
        return delegateLogger.isErrorEnabled();
    }
}
