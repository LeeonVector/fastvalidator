package com.alibaba.fastvalidator.logger.log4j;

import org.apache.log4j.LogManager;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.nop.NopLogger;
import com.alibaba.fastvalidator.logger.support.ILoggerFactory;
import com.alibaba.fastvalidator.logger.support.LogLog;

/***
 * Log factory for {@link Log4jLogger}
 *
 * @author jasenzhang
 */
public class Log4jLoggerFactory implements ILoggerFactory {

    @Override
    public Logger getLogger(Class<?> clazz) {
        try {
            return new Log4jLogger(LogManager.getLogger(clazz));
        } catch (Throwable t) {
            LogLog.error("Failed to get Log4jLogger", t);
            return new NopLogger();
        }
    }

    @Override
    public Logger getLogger(String name) {
        try {
            return new Log4jLogger(LogManager.getLogger(name));
        } catch (Throwable t) {
            LogLog.error("Failed to get Log4jLogger", t);
            return new NopLogger();
        }
    }
}
