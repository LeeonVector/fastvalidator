package com.alibaba.fastvalidator.logger;


/**
 * <pre>
 * Custom Appender/Layout, Level, Additivity properties for logger.
 * </pre>
 *
 * @author zhuyong
 * @author jasenzhang
 */
public interface ActivateOption {

    /**
     * Set appender for current logger.
     *
     * @param productName product name
     * @param file        log file path and name.
     * @param encoding    file encoding
     */
    void activateAppender(String productName, String file, String encoding);

    /**
     * set AsyncAppender(default is DailyRollingFileAppender)
     *
     * @param productName product name
     * @param file        log file path and name.
     * @param encoding    file encoding
     */
    void activateAsyncAppender(String productName, String file, String encoding);

    /**
     * Set rolling policy for current logger.
     *
     * @param productName product name
     * @param file        log file path and name.
     * @param encoding    file encoding
     * @param size        file size: eg. 300MB，300KB，3GB
     */
    void activateAppenderWithTimeAndSizeRolling(String productName, String file,
                                                String encoding, String size);

    /**
     * Set appender from specific logger's appender.
     *
     * @param logger
     */
    void activateAppender(Logger logger);

    /**
     * Set log level.
     *
     * @param level log level
     * @see Level
     */
    void setLevel(Level level);

    /**
     * Whether include root logger appender.
     *
     * @param additivity true or false
     */
    void setAdditivity(boolean additivity);
}
