package com.alibaba.fastvalidator.logger.slf4j;

import org.apache.log4j.helpers.LogLog;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.nop.NopLogger;
import com.alibaba.fastvalidator.logger.support.ILoggerFactory;

/***
 * SLF4j logger factory
 *
 * @author jasenzhang
 */
public class Slf4jLoggerFactory implements ILoggerFactory {

    public Slf4jLoggerFactory() throws ClassNotFoundException {
        Class.forName("org.slf4j.impl.StaticLoggerBinder");
    }

    @Override
    public Logger getLogger(String name) {
        try {
            return new Slf4jLogger(org.slf4j.LoggerFactory.getLogger(name));
        } catch (Throwable t) {
            LogLog.error("Failed to get Slf4jLogger", t);
            return new NopLogger();
        }
    }

    @Override
    public Logger getLogger(Class<?> clazz) {
        try {
            return new Slf4jLogger(org.slf4j.LoggerFactory.getLogger(clazz));
        } catch (Throwable t) {
            LogLog.error("Failed to get Slf4jLogger", t);
            return new NopLogger();
        }
    }
}
