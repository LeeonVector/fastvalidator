package com.alibaba.fastvalidator.logger.nop;


import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.support.LoggerSupport;

/***
 * None operation logger
 *
 * @author jasenzhang
 */
public class NopLogger extends LoggerSupport implements Logger {

    public NopLogger() {
        super(null);
    }

    @Override
    public boolean isDebugEnabled() {
        return false;
    }

    @Override
    public boolean isInfoEnabled() {
        return false;
    }

    @Override
    public boolean isWarnEnabled() {
        return false;
    }

    @Override
    public boolean isErrorEnabled() {
        return false;
    }

    @Override
    public void debug(String context, String message) {

    }

    @Override
    public void debug(String context, String format, Object... args) {

    }

    @Override
    public void info(String code, String context, String message) {

    }

    @Override
    public void info(String code, String context, String format, Object... args) {

    }

    @Override
    public void warn(String code, String context, String message) {

    }

    @Override
    public void warn(String code, String context, String format, Object... args) {

    }

    @Override
    public void error(String context, String code, String message) {

    }

    @Override
    public void error(String context, String code, String message, Throwable t) {

    }

    @Override
    public void error(String context, String code, String format, Object... args) {

    }
}
