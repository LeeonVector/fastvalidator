package com.alibaba.fastvalidator.logger.support;


import com.alibaba.fastvalidator.logger.Level;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.ActivateOption;

/***
 * Base logger
 *
 * @author jasenzhang
 */
public abstract class LoggerSupport<T> implements Logger {

    protected T delegateLogger;
    protected ActivateOption activateOption;

    public LoggerSupport(T delegate) {
        this.delegateLogger = delegate;
    }

    @Override
    public void debug(String message) {
        debug(null, message);
    }

    @Override
    public void debug(String format, Object... args) {
        debug(null, format, args);
    }

    @Override
    public void info(String code, String message) {
        info(code, null, message);
    }

    @Override
    public void info(String code, String format, Object... args) {
        info(code, null, format, args);
    }

    @Override
    public void warn(String code, String message) {
        warn(code, null, message);
    }

    @Override
    public void warn(String code, String format, Object... args) {
        warn(code, null, format, args);
    }

    @Override
    public void error(String code, String message) {
        error(null, code, message);
    }

    @Override
    public void error(String code, String message, Throwable t) {
        error(null, code, message, t);
    }

    @Override
    public void error(String code, String format, Object... args) {
        error(null, code, format, args);
    }

    @Override
    public T getDelegate() {
        return delegateLogger;
    }

    @Override
    public void activateAppender(String productName, String file, String encoding) {
        if (activateOption != null) {
            activateOption.activateAppender(productName, file, encoding);
        }
    }

    @Override
    public void setLevel(Level level) {
        if (activateOption != null) {
            activateOption.setLevel(level);
        }
    }

    @Override
    public void setAdditivity(boolean additivity) {
        if (activateOption != null) {
            activateOption.setAdditivity(additivity);
        }
    }

    @Override
    public void activateAsyncAppender(String productName, String file, String encoding) {
        if (activateOption != null) {
            activateOption.activateAsyncAppender(productName, file, encoding);
        }
    }

    @Override
    public void activateAppenderWithTimeAndSizeRolling(String productName, String file,
                                                       String encoding, String size) {
        if (activateOption != null) {
            activateOption.activateAppenderWithTimeAndSizeRolling(productName, file, encoding, size);
        }
    }

    @Override
    public void activateAppender(Logger logger) {
        if (activateOption != null) {
            activateOption.activateAppender(logger);
        }
    }
}
