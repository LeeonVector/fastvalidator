package com.alibaba.fastvalidator.logger.support;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/***
 * Logger helper
 *
 * @author jasenzhang
 */
public abstract class LoggerHelper {

    private static final String CONVERSION_PATTERN = "01 %d{yyyy-MM-dd HH:mm:ss.SSS} %p [%-5t:%c{2}] %m%n";
    private static String LOG_PATH = null;
    private static Map<String, Boolean> Product_Logger_Info;

    static {
        String dpath = System.getProperty("JM.LOG.PATH");
        if (dpath == null || dpath.trim().equals("")) {
            String defaultPath = System.getProperty("user.home");
            LOG_PATH = defaultPath + File.separator + "logs" + File.separator;
        } else {
            if (!dpath.startsWith(File.separator)) {
                throw new RuntimeException("-DJM.LOG.PATH must be an absolute path.");
            }
            if (dpath.endsWith(File.separator)) {
                LOG_PATH = dpath;
            } else {
                LOG_PATH = dpath + File.separator;
            }
        }

        LogLog.info("Log root path: " + LOG_PATH);

        Product_Logger_Info = new ConcurrentHashMap<String, Boolean>();
    }

    /**
     * Get log path. Default is /{user.home}/logs/
     */
    public static String getLogpath() {
        return LOG_PATH;
    }

    /**
     * <pre>
     * Get product log file path and name.
     *
     *
     * eg：LoggerHelper.getLogFile("fastvalidator", "fastvalidator.log")，will return {user.home}/logs/fastvalidator/fastvalidator.log
     * </pre>
     *
     * @param productName product name
     * @param fileName
     */
    public static String getLogFile(String productName, String fileName) {
        String file = LOG_PATH + productName + File.separator + fileName;

        if (Product_Logger_Info.get(productName) == null) {
            Product_Logger_Info.put(productName, true);
            LogLog.info("Set " + productName + " log path: " + LOG_PATH + productName);
        }

        return file;
    }

    /**
     * Common log layout/pattern.
     */
    public static String getPattern() {
        return CONVERSION_PATTERN;
    }

    /**
     * Print error code and problem decription.
     *
     * @param errorCode
     */
    public static String getErrorCodeStr(String errorCode) {
        //return "ERR-CODE: [" + errorCode + "]，More：[" + "http://console.taobao.net/jm/" + errorCode + "]";
        return errorCode;
    }

    public static String getLogFileP(String productName, String fileName) {
        String file = getLogFile(productName, fileName);
        File logfile = new File(file);
        logfile.getParentFile().mkdirs();
        return file;
    }
}
