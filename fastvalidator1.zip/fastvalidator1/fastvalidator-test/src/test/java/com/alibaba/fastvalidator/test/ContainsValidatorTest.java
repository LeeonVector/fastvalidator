package com.alibaba.fastvalidator.test;

import com.alibaba.fastvalidator.generate.utils.Lists;
import com.alibaba.fastvalidator.test.internal.ValidatorFactory;
import junit.framework.TestCase;
import org.junit.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Contains validator test
 */
public class ContainsValidatorTest extends TestCase {

    @Test
    public void testString() {
        ContainsJavaBean normalBean = getNormalBean();
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<ContainsJavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testMap(){
        ContainsJavaBean normalBean = getNormalBean();
        Map<String,String> map = new HashMap<>();
        map.put("a11","b11");
        map.put("1111","c11");
        normalBean.setVar2(map);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<ContainsJavaBean>> set = validator.validate(normalBean);
        assertTrue(set.size()==1);
    }

    @Test
    public void testList(){
        ContainsJavaBean normalBean = getNormalBean();
        normalBean.setVar13(Lists.<Long>newArrayList(1l));
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<ContainsJavaBean>> set = validator.validate(normalBean);
        assertTrue(set.iterator().next().getMessage().equals("should be contains 2"));
    }

    @Test
    public void testArray(){
        ContainsJavaBean normalBean = getNormalBean();
        normalBean.setVar6(new Long[]{2l});
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<ContainsJavaBean>> set = validator.validate(normalBean);
        assertTrue(set.iterator().next().getMessage().equals("should be contains 1"));

    }

    public ContainsJavaBean getNormalBean() {
        ContainsJavaBean normalBean = new ContainsJavaBean();
        normalBean.setVar1("1");
        Map<String,String> map = new HashMap<>();
        map.put("a","b");
        map.put("1","c");
        normalBean.setVar2(map);
        normalBean.setVar3(Lists.<String>newArrayList("a","2"));
        normalBean.setVar4(Lists.<Long>newArrayList(1l,2l));
        normalBean.setVar5(new Double[]{1.0,2.0});
        normalBean.setVar6(new Long[]{1l,2l});
        normalBean.setVar7(new int[]{1,2});
        normalBean.setVar8(new Float[]{1.0f,2.0f});
        normalBean.setVar9(new Boolean[]{true,false});
        normalBean.setVar10(new Double[]{0.0,1.0});
        normalBean.setVar11(new String[]{"true","1"});
        normalBean.setVar13(Lists.<Long>newArrayList(1L,2l));
        return normalBean;
    }


}
