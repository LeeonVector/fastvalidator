package com.alibaba.fastvalidator.test.internal;


import javax.validation.Validation;
import javax.validation.Validator;
import org.apache.bval.jsr.ApacheValidationProvider;
import org.hibernate.validator.HibernateValidator;
import com.alibaba.fastvalidator.core.FastValidator;

/**
 * validator factory
 *
 * @author: jasen.zhangj
 * @date: 16/9/20.
 */
public enum ValidatorFactory {

    FAST_VALIDATOR {
        @Override
        public Validator getValidator() {
            return FastValidator.builder().failFast(true).logValidateDetail(true).build();
        }
    },

    NON_FAIL_FAST_VALIDATOR {
        @Override
        public Validator getValidator() {
            return FastValidator.builder().failFast(false).build();
        }
    },

    HIBERNATE_VALIDATOR {
        @Override
        public Validator getValidator() {
            return Validation.byProvider(HibernateValidator.class).configure().buildValidatorFactory().getValidator();
        }
    },

    APACHE_VALIDATOR {
        @Override
        public Validator getValidator() {
            return Validation.byProvider(ApacheValidationProvider.class).configure().buildValidatorFactory().getValidator();
        }
    };


    public abstract Validator getValidator();
}
