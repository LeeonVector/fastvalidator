package com.alibaba.fastvalidator.test.internal;

import junit.framework.TestCase;
import java.lang.annotation.Annotation;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import com.alibaba.fastvalidator.generate.utils.Lists;
import com.alibaba.fastvalidator.test.ComposeBean;
import com.alibaba.fastvalidator.test.ComposeJavaBean;
import com.alibaba.fastvalidator.test.JavaBean;
import com.alibaba.fastvalidator.test.JavaBeanWithConstrainDesc;

/**
 * base test case for fast validator
 *
 * @author: jasen.zhangj
 * @date: 16/10/20.
 */
@RunWith(JUnit4.class)
@Ignore
public class BaseTestCase extends TestCase {

    @Override
    @Before
    public void setUp() throws Exception {
        Locale.setDefault(Locale.US);
    }

    protected <T> void checkMessageAndProperty(String property, String message,
                                               Set<ConstraintViolation<T>> constraintViolationSet) {
        checkMessageAndProperty(property, message, constraintViolationSet, null);
    }

    protected <T> void checkMessageAndProperty(String property, String message,
                                               Set<ConstraintViolation<T>> constraintViolationSet,
                                               Class<? extends Annotation> constraintType) {
        assertTrue(!constraintViolationSet.isEmpty());
        ConstraintViolation constraintViolation = constraintViolationSet.iterator().next();
        assertTrue(constraintViolation.getMessage().equals(message));

        assertTrue(constraintViolation.getConstraintDescriptor() != null);
        assertTrue(constraintViolation.getConstraintDescriptor().getAnnotation() != null);
        if (constraintType != null) {
            Class<? extends Annotation> aClass = constraintViolation.getConstraintDescriptor().getAnnotation().annotationType();
            assertTrue(aClass == constraintType);
        }

        Path path = constraintViolation.getPropertyPath();
        assertTrue(path != null);
        StringBuffer sb = new StringBuffer();
        for (Path.Node node : path) {
            if (node.isInIterable()) {
                sb.setLength(sb.length() - 1);
                sb.append("[");
                if (node.getIndex() != null) {
                    sb.append(node.getIndex());
                } else if (node.getKey() != null) {
                    sb.append(node.getKey());
                }
                sb.append("]");
                sb.append(".");
            } else {
                sb.append(node.getName()).append(".");
            }
        }

        sb.setLength(sb.length() - 1);
        assertTrue(sb.toString().equals(property));
    }

    protected JavaBean getNormalJavaBean() {
        JavaBean normalBean = new JavaBean();
        normalBean.setName("jasen");
        normalBean.setAge(19);
        normalBean.setEmail("asf@wer.com");
        List<String> address = new ArrayList<String>();
        address.add("HangzZhou");
        address.add("Binjiang");
        normalBean.setAddress(address);
        normalBean.setBrand("my brands");
        normalBean.setMoney(new BigDecimal("2.3"));
        normalBean.setGender("MALE");
        normalBean.setEmail("abcd@aa.com");
        normalBean.setLastname("lastname");
        normalBean.setColor("white");

        List<String> cars = new ArrayList<>();
        cars.add("BMW");
        normalBean.setCars(cars);

        ComposeJavaBean car = new ComposeJavaBean();
        car.setColor("red");
        car.setMiles(20);
        car.setParentPro1("parentPro1");

        normalBean.setComposeBean(car);

        normalBean.setConditionNotNull("not null");
        normalBean.setParentPro1("parentPro1");
        normalBean.setPassword("123456");
        normalBean.setRepassword("123456");

        String jsonString = "{\"key\":\"value\"}";
        normalBean.setJsonString(jsonString);
        List<String> jsonList = new ArrayList<>();
        jsonList.add(jsonString);
        normalBean.setEachJsonString(jsonList);

        String birth = "1998-01-01 14:20:00";
        normalBean.setBirth(birth);
        List<String> childrenBirth = new ArrayList<>();
        childrenBirth.add(birth);
        normalBean.setChildrenBirth(childrenBirth);

        normalBean.setAgeRange(-1);

        List<Integer> eachRange = new ArrayList<>();
        eachRange.add(15);
        normalBean.setEachRange(eachRange);

        normalBean.setRanges(14);

        normalBean.setListSize("12345");

        normalBean.setPrimitiveArray(new long[] { 1L });
        normalBean.setObjectArray(new JavaBean[] { normalBean });

        normalBean.setIfConstraint("1234");
        normalBean.setIfConstraint2("1234");
        normalBean.setIfConstraintBoolean(false);
        normalBean.setIfConstraintBoolean2(false);
        normalBean.setContains(new int[] { 1 });

        normalBean.setNotEquals("Null");
        normalBean.setNotEquals2("not equals");
        normalBean.setMessageAndCode("messageAndCodes");
        normalBean.setLengthWithCodeAndMessage("lengthWithCodeAndMessage");
        normalBean.setEmail2("jasen.zhangj@alibaba-inc.com");

        List<ComposeBean> composeBeanList = new ArrayList<>();
        ComposeBean composeBean = new ComposeBean();
        composeBean.setColor("red");
        composeBean.setMiles(123);
        ;
        composeBeanList.add(composeBean);
        normalBean.setComposeBeanList(composeBeanList);

        // EachValidate
        normalBean.setStrEachValueSize("67890");
        normalBean.setListEachValueSize(Lists.newArrayList("67890"));
        normalBean.setStrEachValueEmail("jasen.zhangj@alibaba-inc.com");
        normalBean.setListEachValueEmail(Lists.newArrayList("jasen.zhangj@alibaba-inc.com"));
        normalBean.setStrEachNotBlank("1234");
        normalBean.setStrEachRange("234,567");
        normalBean.setListEachRange(Lists.newArrayList(1234L, 5678L));
        normalBean.setStrEachIsEnum("MALE,FEMALE");
        normalBean.setListEachIsEnum(Lists.newArrayList("MALE", "FEMALE"));
        return normalBean;
    }

    protected JavaBeanWithConstrainDesc getNormalBeanWithConstrainDesc() {
        JavaBeanWithConstrainDesc bean = new JavaBeanWithConstrainDesc();
        bean.setName("jasen");
        bean.setLastname("zhang");
        bean.setAge(18);
        bean.setBrand("BMW");
        bean.setMoney(new BigDecimal(12.34, new MathContext(4, RoundingMode.HALF_UP)));

        ComposeBean composeBean = new ComposeBean();
        composeBean.setColor("red");
        composeBean.setMiles(123);

        bean.setComposeBean(composeBean);

        List<String> cars = new ArrayList<>();
        cars.add("BMW");
        cars.add("BenZ");

        return bean;
    }
}
