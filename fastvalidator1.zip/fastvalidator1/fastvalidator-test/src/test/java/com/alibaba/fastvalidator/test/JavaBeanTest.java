package com.alibaba.fastvalidator.test;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.junit.Test;

import com.alibaba.fastvalidator.constraints.Conditional;
import com.alibaba.fastvalidator.constraints.Contains;
import com.alibaba.fastvalidator.constraints.If;
import com.alibaba.fastvalidator.constraints.IsDate;
import com.alibaba.fastvalidator.constraints.IsEnum;
import com.alibaba.fastvalidator.constraints.IsJSON;
import com.alibaba.fastvalidator.constraints.NotEquals;
import com.alibaba.fastvalidator.constraints.collection.EachIsDate;
import com.alibaba.fastvalidator.constraints.collection.EachIsEnum;
import com.alibaba.fastvalidator.constraints.collection.EachIsJSON;
import com.alibaba.fastvalidator.constraints.collection.EachNotBlank;
import com.alibaba.fastvalidator.constraints.collection.EachRange;
import com.alibaba.fastvalidator.constraints.validator.ValidateBeanValidator;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.test.annotation.EachCustomNotBlank;
import com.alibaba.fastvalidator.test.group.GroupA;
import com.alibaba.fastvalidator.test.group.GroupB;
import com.alibaba.fastvalidator.test.internal.BaseTestCase;
import com.alibaba.fastvalidator.test.internal.ValidatorFactory;

/**
 * MyBeanTest
 *
 * @author: jasen.zhangj
 * @date: 15/11/5.
 */
public class JavaBeanTest extends BaseTestCase {

    @Test
    public void validatorIsExist() {
        Class beanClass = JavaBean.class;
        ValidateBeanValidator.ValidateBeanInfo validateBeanInfo = ValidateBeanValidator.getValidateBeanConstraintValidator(beanClass);
        ConstraintValidator constraintValidator = validateBeanInfo.getConstraintValidator();
        assertTrue(constraintValidator != null);
    }

    @Test
    public void testNormalMyBean() {
        JavaBean normalBean = getNormalJavaBean();
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testNotBlank_when_null() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setName(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("name", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testNotBlank_when_empty_string() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setName("");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("name", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testNotEmpty() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setColor(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("color", "may not be empty", set, NotEmpty.class);
    }

    @Test
    public void testEachNotBlank() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.getAddress().add("");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("address", "may not be empty", set, EachNotBlank.class);
    }

    @Test
    public void testSize() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.getAddress().add("222");
        normalBean.getAddress().add("333");
        normalBean.getAddress().add("444");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("address", "size must be between 1 and 3", set, Size.class);

        normalBean.getAddress().clear();
        validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        set = validator.validate(normalBean);
        checkMessageAndProperty("address", "size must be between 1 and 3", set, Size.class);
    }

    @Test
    public void testDecimalMaxAndMin() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setAge(201);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("age", "must be less than or equal to 200", set, DecimalMax.class);
    }

    @Test
    public void testNotNull() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setGender(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("gender", "may not be null", set, NotNull.class);
    }

    @Test
    public void testLength_when_string_empty() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setBrand("");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("brand", "length must be between 1 and 30", set, Length.class);
    }

    @Test
    public void testLength_when_exceeded_max_length() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setBrand("1234567891234567891234567891234");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("brand", "length must be between 1 and 30", set, Length.class);
    }

    @Test
    public void testPattern() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setEmail("asdf");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("email",
                                "must match \"^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$\"",
                                set, Pattern.class);

        set = validator.validate(normalBean);
        checkMessageAndProperty("email",
                                "must match \"^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$\"",
                                set, Pattern.class);
    }

    @Test
    public void testCustomNotBlank() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setLastname(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("lastname", "may not be empty", set, CustomNotBlank.class);
    }

    @Test
    public void testEachCustomNotBlank() {
        JavaBean normalBean = getNormalJavaBean();
        List<String> cars = new ArrayList<>();
        cars.add("");
        normalBean.setCars(cars);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("cars", "may not be empty", set, EachCustomNotBlank.class);
    }

    @Test
    public void testComposeBean() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.getComposeBean().setColor("");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("composeBean.color", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testParentProperty() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setParentPro1(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("parentPro1", "may not be null", set, NotNull.class);
    }

    @Test
    public void testConditional() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setConditionNotNull(null);
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("conditionNotNull", "conditionNotNull is null", set, Conditional.class);
    }

    @Test
    public void testConditional_when_use_utils_in_defalut_context() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setPassword("differentPassword");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("repassword", "password not equal repassword", set, Conditional.class);
    }

    @Test
    public void testIsEnum() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setGender("unknown");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("gender", "should be " + GenderEnum.class.getName() + " type", set, IsEnum.class);
    }

    @Test
    public void testEachIsEnum() {
        JavaBean normalBean = getNormalJavaBean();
        List<String> childrenGenders = new ArrayList<>();
        childrenGenders.add(GenderEnum.FEMALE.name());
        normalBean.setChildrenGenders(childrenGenders);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        childrenGenders.add("unknown gender type");
        set = validator.validate(normalBean);
        checkMessageAndProperty("childrenGenders", "should be class " + GenderEnum.class.getName() + " type", set, EachIsEnum.class);
    }

    @Test
    public void testIsDate() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setBirth("1984/01/02 12:00:00");

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("birth", "should be yyyy-MM-dd HH:mm:ss format", set, IsDate.class);

        normalBean.setBirth("1984-01-01 14:00:00");
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testEachIsDate() {
        JavaBean normalBean = getNormalJavaBean();
        List<String> births = new ArrayList<>();
        births.add("1234");
        normalBean.setChildrenBirth(births);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("childrenBirth", "should be yyyy-MM-dd HH:mm:ss format", set, EachIsDate.class);

        births = new ArrayList<>();
        births.add("1999-12-12 18:00:00");
        normalBean.setChildrenBirth(births);
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testJSON() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setJsonString("1234kl");

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("jsonString", "may be JSON format", set, IsJSON.class);

        normalBean.setJsonString("{\"name\":1234}");
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testEachJSON() {
        JavaBean normalBean = getNormalJavaBean();
        List<String> jsonSringList = new ArrayList<>();
        jsonSringList.add("{\"name\':1234}");
        normalBean.setEachJsonString(jsonSringList);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("eachJsonString", "may be JSON format", set, EachIsJSON.class);

        jsonSringList = new ArrayList<>();
        jsonSringList.add("{\"name\":1234}");
        normalBean.setEachJsonString(jsonSringList);
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testRange() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setAgeRange(-11);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("ageRange", "must be between -10 and 10", set, Range.class);
    }

    @Test
    public void testEachRange() {
        JavaBean normalBean = getNormalJavaBean();
        List<Integer> eachRange = new ArrayList<>();
        eachRange.add(-11);
        normalBean.setEachRange(eachRange);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("eachRange", "must be between -10 and 20", set, EachRange.class);
    }

    @Test
    public void testRangeList() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setRanges(11);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("ranges", "must be between 12 and 15", set, Range.List.class);
    }

    @Test
    public void testListWithoutComposed() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setListSize("12");

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("listSize", "size must be between 4 and 9", set, Size.List.class);

        normalBean.setListSize("");
        set = validator.validate(normalBean);
        checkMessageAndProperty("listSize", "size must be between 1 and 10", set, Size.List.class);
    }

    @Test
    public void testPrimitiveArray() {
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setPrimitiveArray(new long[] {});

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("primitiveArray", "size must be between 1 and " + Integer.MAX_VALUE + "", set, Size.class);

        normalBean.setPrimitiveArray(new long[]{2L});
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testObjectArray(){
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setObjectArray(new JavaBean[]{});

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("objectArray", "size must be between 1 and " + Integer.MAX_VALUE + "", set, Size.class);

        normalBean.setObjectArray(new JavaBean[]{normalBean});
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testNonFailFastMode(){
        Validator validator = ValidatorFactory.NON_FAIL_FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        normalBean.setName(null);
        normalBean.setAge(300);

        set = validator.validate(normalBean);
        assertTrue(set.size() == 2);
    }

    @Test
    public void testIf(){
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setIfConstraint(null);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("ifConstraint", "ifConstraint is blank", set, If.class);

        normalBean.setIfConstraint("23");
        set = validator.validate(normalBean);
        checkMessageAndProperty("ifConstraint2", "ifConstraint not equal ifConstraint2", set, If.class);
    }

    @Test
    public void testIfWithBooleanType(){
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setIfConstraintBoolean(null);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("ifConstraintBoolean", "ifConstraintBoolean is null", set, If.class);

        normalBean.setIfConstraintBoolean(true);
        set = validator.validate(normalBean);
        checkMessageAndProperty("ifConstraintBoolean2", "ifConstraintBoolean not equal ifConstraintBoolean2", set);
    }

    @Test
    public void testIfWithBooleanPrimitiveType(){
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setBoolean1(true);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("boolean1", "boolean1 not equal boolean2", set, If.class);
    }

    @Test
    public void testContains(){
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setContains(new int[]{2});

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("contains", "should be contains 1", set, Contains.class);

        normalBean.setContains(new int[]{1,2});
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testGroupSerializableGroup(){
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup1("group1");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean, Serializable.class);
        assertTrue(set.isEmpty());

        normalBean.setGroup1(null);
        set = validator.validate(normalBean, Serializable.class);
        checkMessageAndProperty("group1", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testGroupA(){
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup2("notEmpty");
        normalBean.setGroup3("group3");
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean, GroupA.class);
        assertTrue(set.isEmpty());

        normalBean.setGroup2(null);
        set = validator.validate(normalBean, GroupA.class);
        checkMessageAndProperty("group2", "group2 is empty", set, If.class);
    }

    @Test
    public void testNonExistGroup(){
        JavaBean normalBean = new JavaBean();
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean, List.class);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testNonFailFastModeWithGroup(){
        Validator validator = ValidatorFactory.NON_FAIL_FAST_VALIDATOR.getValidator();
        JavaBean normalBean = new JavaBean();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean, GroupA.class);
        assertTrue(set.size() == 2);
    }

    @Test
    public void testNonFailFastModeWithGroupB(){
        Validator validator = ValidatorFactory.NON_FAIL_FAST_VALIDATOR.getValidator();
        JavaBean normalBean = new JavaBean();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean, GroupB.class);
        checkMessageAndProperty("group3", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testNotEquals(){
        Validator validator = ValidatorFactory.NON_FAIL_FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setNotEquals("null");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("notEquals", "should not equals \"null\" when ignoreCase=false", set, NotEquals.class);

        normalBean.setNotEquals("NULL");
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testNotEqualsWhenIgnoreCase() {
        Validator validator = ValidatorFactory.NON_FAIL_FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setNotEquals2("NULL");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("notEquals2", "should not equals \"null\" when ignoreCase=true", set, NotEquals.class);
    }

    @Test
    public void testEmail(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setEmail2("11234@");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("email2", "not a well-formed email address", set, Email.class);

        normalBean.setEmail2("jasen.aahhgfdsaqwertyuiasdfoaahhgfdsaqwertyuio@alibaba-inc.com");
        set = validator.validate(normalBean);
        checkMessageAndProperty("email2", "length must be between 0 and 32", set, Length.class);
    }

    @Test
    public void testValidListBean(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.getComposeBeanList().get(0).setColor(null);

        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("composeBeanList[0].color", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testInnerBean(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        BaseBean.InnerBean innerBean = new BaseBean.InnerBean();
        Set<ConstraintViolation<BaseBean.InnerBean>> set = validator.validate(innerBean);
        checkMessageAndProperty("name", "may not be empty", set, NotBlank.class);
    }

    @Test
    public void testInnerBean2(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        BaseBean baseBean = new BaseBean();
        BaseBean.InnerBean2 innerBean2 = baseBean.new InnerBean2();
        Set<ConstraintViolation<BaseBean.InnerBean2>> set = validator.validate(innerBean2);
        checkMessageAndProperty("name", "may not be empty", set, NotBlank.class);
    }
}
