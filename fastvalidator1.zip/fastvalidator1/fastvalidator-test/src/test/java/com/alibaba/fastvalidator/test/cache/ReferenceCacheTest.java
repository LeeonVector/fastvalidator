package com.alibaba.fastvalidator.test.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.hibernate.validator.internal.util.ConcurrentReferenceHashMap;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Created by jipengfei on 16/12/21.
 */
@RunWith(JUnit4.class)
public class ReferenceCacheTest {

    /**
     * VM options -Xms5M -Xmx5M
     */
    @Test
    @Ignore
    public void ConcurrentReferenceHashMap() {

        ConcurrentReferenceHashMap<Integer, String> map =
            new ConcurrentReferenceHashMap(100, ConcurrentReferenceHashMap.ReferenceType.SOFT,
                ConcurrentReferenceHashMap.ReferenceType.SOFT);

        int i = 0;
        try {

            for (; ; ) {
                map.put(i++, i + 1 + "");
                System.out.println(map.size());
            }

        } catch (Throwable t) {
            System.out.println(t.toString());
        }
    }


    /**
     * VM options -Xms5M -Xmx5M
     */
    @Test
    @Ignore
    public void ConcurrentHashMap() {

        Map<Integer, String> map = new ConcurrentHashMap<>();

        int i = 0;
        try {

            for (; ; ) {
                map.put(i++, i + 1 + "");
                System.out.println(map.size());
            }

        } catch (Throwable t) {
            System.out.println(t.toString());
        }
    }



}
