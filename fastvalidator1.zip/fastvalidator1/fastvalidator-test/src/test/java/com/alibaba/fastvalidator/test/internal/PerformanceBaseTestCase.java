package com.alibaba.fastvalidator.test.internal;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.junit.Test;

import com.alibaba.fastvalidator.test.ComposeBean;
import com.alibaba.fastvalidator.test.PerformanceTestBean1;
import com.alibaba.fastvalidator.test.PerformanceTestBean10;
import com.alibaba.fastvalidator.test.PerformanceTestBean5;

/**
 * base test case class for performance test.
 *
 * @author: jasen.zhangj
 * @date: 16/11/30.
 */
public abstract class PerformanceBaseTestCase extends BaseTestCase {

    protected abstract Validator getValidator();

    @Test
    public void testPerformanceTestBean_testBean_with1f() {
        Validator validator = getValidator();

        Map<String, Object> testMap = new HashMap<>();
        testMap.put("testBean1", getPerformanceTestBean1());
        performanceTest(validator, testMap);
    }

    @Test
    public void testPerformanceTestBean_testBean_with5f() {
        Validator validator = getValidator();

        Map<String, Object> testMap = new HashMap<>();
        testMap.put("testBean5", getPerformanceTestBean5());
        performanceTest(validator, testMap);
    }

    @Test
    public void testPerformanceTestBean_testBean_with10f() {
        Validator validator = getValidator();

        Map<String, Object> testMap = new HashMap<>();
        testMap.put("testBean10", getPerformanceTestBean10());
        performanceTest(validator, testMap);
    }

    private void performanceTest(Validator validator, Map<String, Object> testMap) {
        for (Map.Entry<String, Object> entry : testMap.entrySet()) {
            Object testBean = entry.getValue();
            for (int i = 0; i < 10000; i++) {
                Set<ConstraintViolation<Object>> constraintViolations = validator.validate(testBean);
                assertTrue(constraintViolations.isEmpty());
            }

            long start = System.currentTimeMillis();
            for (int i = 0; i < 1000000; i++) {
                validator.validate(testBean);
            }
            long end = System.currentTimeMillis();
            System.out.println(this.getClass().getSimpleName() + " -> " + entry.getKey() + " total cost:"
                               + (end - start));
        }
    }

    protected Object getPerformanceTestBean1() {
        PerformanceTestBean1 performanceTestBean1 = new PerformanceTestBean1();
        performanceTestBean1.setName("not empty");
        return performanceTestBean1;
    }

    protected Object getPerformanceTestBean5() {
        PerformanceTestBean5 performanceTestBean5 = new PerformanceTestBean5();
        List<String> address = new ArrayList<>();
        address.add("HangzZhou");
        address.add("Binjiang");
        performanceTestBean5.setAddress(address);
        performanceTestBean5.setAge(124);
        performanceTestBean5.setFemail(true);
        performanceTestBean5.setEmail("abcd@aa.com");

        ComposeBean car = new ComposeBean();
        car.setColor("red");
        car.setMiles(20);

        performanceTestBean5.setComposeBean(car);
        return performanceTestBean5;
    }

    protected Object getPerformanceTestBean10() {
        PerformanceTestBean10 performanceTestBean10 = new PerformanceTestBean10();
        performanceTestBean10.setName("jasen");
        performanceTestBean10.setAge(19);
        performanceTestBean10.setEmail("asf@wer.com");
        List<String> address = new ArrayList<>();
        address.add("HangzZhou");
        address.add("Binjiang");
        performanceTestBean10.setAddress(address);
        performanceTestBean10.setMoney(new BigDecimal("2.3"));
        performanceTestBean10.setFemail(true);
        performanceTestBean10.setEmail("abcd@aa.com");
        performanceTestBean10.setLastname("lastname");

        ComposeBean car = new ComposeBean();
        car.setColor("red");
        car.setMiles(20);

        performanceTestBean10.setComposeBean(car);
        return performanceTestBean10;
    }
}
