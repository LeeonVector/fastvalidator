package com.alibaba.fastvalidator.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.alibaba.fastvalidator.constraints.exception.FastValidatorException;
import com.alibaba.fastvalidator.test.internal.BaseTestCase;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithCodeAndMessageAnnotationMethod;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithCodeAndMessageDefaultMethod;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithCodeAndMessageField;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithConstraint;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithFVCodeAnnotationMethod;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithFVMessageAnnotationMethod;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithoutCodeDefaultMethod;
import com.alibaba.fastvalidator.test.spring.ReturnTypeWithoutMessageDefaultMethod;
import com.alibaba.fastvalidator.test.spring.ValidatorService;
import com.alibaba.fastvalidator.test.spring.helper.ServiceInvokeHelper;

/**
 * spring method validate
 *
 * @author: jasen.zhangj
 * @date: 16/11/23.
 */
public class InterfaceMethodTest extends BaseTestCase {

    ApplicationContext       context;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Override
    @Before
    public void setUp() throws Exception {
        super.setUp();
        context = new ClassPathXmlApplicationContext("classpath:validate_for_spring.xml");
    }

    @After
    public void after(){
        ServiceInvokeHelper.clear();
    }

    protected ValidatorService getValidatorService() {
        return context.getBean("validatorService", ValidatorService.class);
    }

    @Test
    public void testNothing(){
        ValidatorService validatorService = getValidatorService();
        validatorService.nothing();
        ServiceInvokeHelper.check("nothing", 1);
    }

    @Test
    public void testNothing2(){
        ValidatorService validatorService = getValidatorService();
        validatorService.nothing();
        ServiceInvokeHelper.check("nothing", 1);
        validatorService.nothing();
        ServiceInvokeHelper.check("nothing", 2);
    }

    @Test
    public void testJavaBeanNormal() {
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        validatorService.insertJavaBean("test", normalBean);
        ServiceInvokeHelper.check("insertJavaBean", 1);
    }

    @Test
    public void testJavaBeanNormal2() {
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        validatorService.insertJavaBean("test", normalBean);
        ServiceInvokeHelper.check("insertJavaBean", 1);
        validatorService.insertJavaBean("test", normalBean);
        ServiceInvokeHelper.check("insertJavaBean", 2);
    }

    @Test
    public void testParentProperty(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBean.arg1.parentPro1 may not be null");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setParentPro1(null);
        validatorService.insertJavaBean("test", normalBean);
    }

    @Test
    public void testNotBlank() {
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBean.arg0.name may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setName(null);
        validatorService.insertJavaBean(normalBean);
    }

    @Test
    public void testComposeBean(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanComposeBean.arg0.composeBean.color may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.getComposeBean().setColor(null);

        validatorService.insertJavaBeanComposeBean(normalBean);
    }

    @Test
    public void testParametersConstraint() {
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBean.arg1 may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        validatorService.insertJavaBean(normalBean, "");
    }

    @Test
    public void testParametersConstraint2() {
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBean.arg1.name may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setName("");
        validatorService.insertJavaBean("test", normalBean);
    }

    @Test
    public void testWithoutConstraints() {
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setName("");
        validatorService.insertJavaBeanWithoutConstraint(normalBean);
    }

    @Test
    public void testReturnTypeWithCodeAndMessageDefaultMethod(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithCodeAndMessageDefaultMethod response = validatorService.returnTypeWithCodeAndMessageDefaultMethod(javaBean);
        assertTrue(response != null);
        assertTrue(response.getCode().equals("messageAndCode_is_blank"));
        assertTrue(response.getMessage().equals("messageAndCode may be empty"));

        response = validatorService.returnTypeWithCodeAndMessageDefaultMethod(javaBean);
        assertTrue(response != null);
        assertTrue(response.getCode().equals("messageAndCode_is_blank"));
        assertTrue(response.getMessage().equals("messageAndCode may be empty"));

        javaBean = getNormalJavaBean();
        javaBean.setLengthWithCodeAndMessage("");
        response = validatorService.returnTypeWithCodeAndMessageDefaultMethod(javaBean);
        assertTrue(response.getCode().equals("lengthWithCodeAndMessage_illegal"));
        assertTrue(response.getMessage().equals("lengthWithCodeAndMessage is illegal"));
    }

    @Test
    public void testReturnTypeWithoutMessageDefaultMethod(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithoutMessageDefaultMethod returnTypeWithCodeAndNoMessage = validatorService.returnTypeWithoutMessageDefaultMethod(javaBean);
        assertTrue(returnTypeWithCodeAndNoMessage != null);
        assertTrue(returnTypeWithCodeAndNoMessage.getCode().equals("messageAndCode_is_blank"));
        assertTrue(returnTypeWithCodeAndNoMessage.getMessage() == null);
    }

    @Test
    public void testReturnTypeWithoutMessageAnnotation(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithFVCodeAnnotationMethod returnTypeWithCodeAndNoMessage = validatorService.returnTypeWithFVCodeAnnotationMethod(javaBean);
        assertTrue(returnTypeWithCodeAndNoMessage != null);
        assertTrue(returnTypeWithCodeAndNoMessage.getCode().equals("messageAndCode_is_blank"));
        assertTrue(returnTypeWithCodeAndNoMessage.getMessage() == null);
    }

    @Test
    public void testReturnTypeWithCodeAndMessageMethodAnnotation(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithCodeAndMessageAnnotationMethod response = validatorService.returnTypeWithCodeAndMessageAnnotationMethod(javaBean);
        assertTrue(response != null);

        assertTrue(response.getCode().equals("messageAndCode_is_blank"));
        assertTrue(response.getMessage().equals("messageAndCode may be empty"));

        response = validatorService.returnTypeWithCodeAndMessageAnnotationMethod(javaBean);
        assertTrue(response != null);

        assertTrue(response.getCode().equals("messageAndCode_is_blank"));
        assertTrue(response.getMessage().equals("messageAndCode may be empty"));
    }

    @Test
    public void testWithoutCodeDefaultMethod(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithoutCodeDefaultMethod returnTypeWithoutCodeDefaultMethod = validatorService.insertJavaBeanWithoutCode(javaBean);
        assertTrue(returnTypeWithoutCodeDefaultMethod.getMessage().equals("messageAndCode may be empty"));
    }

    @Test
    public void testWithoutCodeMethodAnnotation(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithFVMessageAnnotationMethod returnTypeWithFVMessageAnnotationMethod = validatorService.returnTypeWithFVMessageAnnotationMethod(javaBean);
        assertTrue(returnTypeWithFVMessageAnnotationMethod.getMessage().equals("messageAndCode may be empty"));
    }

    @Test
    public void testWithoutCodeAndMessageMethodAnnotation(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.returnTypeWithoutCodeAndMessage.arg0.messageAndCode messageAndCode may be empty|messageAndCode_is_blank");
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        validatorService.returnTypeWithoutCodeAndMessage(javaBean);
    }

    @Test
    public void testWithoutCodeAndMessageMethodAnnotationTryCatch(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        try {
            validatorService.returnTypeWithoutCodeAndMessage(javaBean);
        } catch (FastValidatorException ex){
            assertTrue("messageAndCode_is_blank".equals(ex.getCode()));
            assertTrue("ValidatorServiceImpl.returnTypeWithoutCodeAndMessage.arg0.messageAndCode messageAndCode may be empty|messageAndCode_is_blank".equals(ex.getMessage()));
        }
    }

    @Test
    public void testNormalBeanWithCodeAndMessageField(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);
        ValidatorService validatorService = getValidatorService();
        ReturnTypeWithCodeAndMessageField returnTypeWithCodeAndMessageField = validatorService.returnTypeWithCodeAndMessageAnnotationField(javaBean);
        assertTrue(returnTypeWithCodeAndMessageField.getCode().equals("messageAndCode_is_blank"));
        assertTrue(returnTypeWithCodeAndMessageField.getMessage().equals("messageAndCode may be empty"));
    }

    @Test
    public void testReturnTypeIsVoid(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithVoidType.arg0.messageAndCode messageAndCode may be empty|messageAndCode_is_blank");
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageAndCode(null);

        ValidatorService validatorService = getValidatorService();
        validatorService.insertJavaBeanWithVoidType(javaBean);
    }

    @Test
    public void testJavaBeanWithGroup(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithGroup.arg0.group1 may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup1(null);
        validatorService.insertJavaBeanWithGroup(normalBean);
    }

    @Test
    public void testJavaBeanWithGroupNormal(){
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup1("group1");
        validatorService.insertJavaBeanWithGroup(normalBean);
    }

    @Test
    public void testJavaBeanWithGroup2(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithGroup2.arg1 may not be empty");


        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup1("group1");
        validatorService.insertJavaBeanWithGroup2(normalBean, null);
    }

    @Test
    public void testJavaBeanWithGroup3(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithGroup3.arg0.group2 group2 is empty");


        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup2(null);
        normalBean.setGroup3("group3");
        validatorService.insertJavaBeanWithGroup3(normalBean);
    }

    @Test
    public void testJavaBeanWithGroup3Normal(){
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup2("group2");
        normalBean.setGroup3("group3");
        validatorService.insertJavaBeanWithGroup3(normalBean);
    }

    @Test
    public void testJavaBeanWithGroup3_1Normal(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithGroup3.arg0.group3 may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = new JavaBean();
        normalBean.setGroup2("group2");
        validatorService.insertJavaBeanWithGroup3(normalBean);
    }

    @Test
    public void testInsertJavaBeanWithGroup4(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.insertJavaBeanWithGroup4.arg0.name may not be empty");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setGroup2("group2");
        normalBean.setGroup3("group3");

        normalBean.setName(null);
        validatorService.insertJavaBeanWithGroup4(normalBean);
    }

    @Test
    public void testParameterScriptAssert(){
        ValidatorService validatorService = getValidatorService();

        JavaBean javaBean1 = new JavaBean();
        javaBean1.setName("name1");

        JavaBean javaBean2 = new JavaBean();
        javaBean2.setName("name2");

        ReturnTypeWithCodeAndMessageField result = validatorService.testParameterScriptAssert(javaBean1, javaBean2);
        assertTrue(result.getMessage().equals("javaBean1's name not equals javaBean2's name"));
        assertTrue(result.getCode().equals("ARGS_NAME_NOT_EQUALS"));


        javaBean2.setName("name1");
        result = validatorService.testParameterScriptAssert(javaBean1, javaBean2);
        assertTrue(result == null);
    }

    @Test
    public void testReturnTypeWithSimpleConstraintReturnNull(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.returnTypeWithSimpleConstraintReturnNull.<return value> may not be null");

        ValidatorService validatorService = getValidatorService();
        validatorService.returnTypeWithSimpleConstraintReturnNull();
    }

    @Test
    public void testReturnTypeWithConstraintReturnNull(){
        ValidatorService validatorService = getValidatorService();
        validatorService.returnTypeWithConstraintReturnNull();
    }

    @Test
    public void testReturnTypeWithConstraintCascade(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.returnTypeWithConstraintReturnNormal.<return value>.name may not be empty");

        ValidatorService validatorService = getValidatorService();
        validatorService.returnTypeWithConstraintReturnNormal();
    }

    @Test
    public void testReturnTypeWithConstraintAndParameterConstraint(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.returnTypeWithConstraintReturnNormal.arg0.color may not be empty");

        ValidatorService validatorService = getValidatorService();

        JavaBean normalBean = getNormalJavaBean();
        normalBean.setColor(null);

        ReturnTypeWithConstraint returnTypeWithConstraint = validatorService.returnTypeWithConstraintReturnNormal(normalBean);

        assertTrue(returnTypeWithConstraint != null);
    }

    @Test
    public void testReturnTypeWithConstraintAndParameterConstraint2(){
        thrown.expect(FastValidatorException.class);
        thrown.expectMessage("ValidatorServiceImpl.returnTypeWithConstraintAndParameterConstraint.<return value>.ifConstraint2 ifConstraint2 not equal 'ifConstraint2'");

        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        validatorService.returnTypeWithConstraintAndParameterConstraint(normalBean);
    }

    @Test
    public void testReturnTypeWithConstraintAndParameterConstraint3(){
        ValidatorService validatorService = getValidatorService();
        JavaBean normalBean = getNormalJavaBean();
        ReturnTypeWithConstraint returnTypeWithConstraint = validatorService.returnTypeWithConstraintAndParameterConstraintNormal(normalBean);

        assertTrue(returnTypeWithConstraint != null);
    }
}
