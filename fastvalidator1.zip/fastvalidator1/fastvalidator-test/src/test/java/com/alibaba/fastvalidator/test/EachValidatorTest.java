package com.alibaba.fastvalidator.test;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ValidationException;
import javax.validation.Validator;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import com.alibaba.fastvalidator.generate.utils.Lists;
import com.alibaba.fastvalidator.test.internal.BaseTestCase;
import com.alibaba.fastvalidator.test.internal.ValidatorFactory;

/**
 * Test case for {@link com.alibaba.fastvalidator.constraints.EachValidate}
 *
 * @author: jasen.zhangj
 * @date: 2017-08-07
 */
public class EachValidatorTest extends BaseTestCase {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void testStrEachValueSize() {
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.size() == 0);

        normalBean.setStrEachValueSize("12,ab");
        set = validator.validate(normalBean);
        checkMessageAndProperty("strEachValueSize",
                                "each element may not violate the constraint: javax.validation.constraints.Size with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=min, value=5),@com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=max, value=15),",
                                set);
    }

    @Test
    public void testListEachValueSize() {
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();

        normalBean.setListEachValueSize(Lists.newArrayList("1234"));
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("listEachValueSize",
                                "each element may not violate the constraint: javax.validation.constraints.Size with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=min, value=5),@com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=max, value=15),",
                                set);
    }

    @Test
    public void testListEachValueEmail() {
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        normalBean.setListEachValueEmail(Lists.newArrayList("asdf1234"));
        set = validator.validate(normalBean);
        checkMessageAndProperty("listEachValueEmail",
                                "each element may not violate the constraint: org.hibernate.validator.constraints.Email with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=regexp, value=^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$),",
                                set);
    }

    @Test
    public void testStrEachValueEmail() {
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();

        normalBean.setStrEachValueEmail("abc@163.com|sadfs@6789.com");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        normalBean.setStrEachValueEmail("abc@163.com|sadfs@6789");
        set = validator.validate(normalBean);
        checkMessageAndProperty("strEachValueEmail",
                                "each element may not violate the constraint: org.hibernate.validator.constraints.Email with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=regexp, value=^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$),",
                                set);
    }

    @Test
    public void testStrEachNotBlank() {
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();

        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        normalBean.setStrEachNotBlank("123|3 67");
        set = validator.validate(normalBean);
        assertTrue(set.isEmpty());

        normalBean.setStrEachNotBlank("123|3 67|");
        set = validator.validate(normalBean);
        checkMessageAndProperty("strEachNotBlank", "each element may not violate the constraint: org.hibernate.validator.constraints.NotBlank with property ", set);
    }

    @Test
    public void testStrEachRange(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();

        normalBean.setStrEachRange("1234,-1");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("strEachRange", "each element may not violate the constraint: org.hibernate.validator.constraints.Range with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=min, value=0),@com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=max, value=9223372036854775807),", set);
    }

    @Test
    public void testListEachRange(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();

        normalBean.setListEachRange(Lists.newArrayList(0L,-2L));
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("listEachRange", "each element may not violate the constraint: org.hibernate.validator.constraints.Range with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=min, value=0),@com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=max, value=9223372036854775807),", set);
    }

    @Test
    public void testStrEachIsEnum(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setStrEachIsEnum("MALE,FEMALE1");
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("strEachIsEnum","each element may not violate the constraint: com.alibaba.fastvalidator.constraints.IsEnum with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=enumType, value=com.alibaba.fastvalidator.test.GenderEnum),",set);
    }

    @Test
    public void testListEachIsEnum(){
        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBean normalBean = getNormalJavaBean();
        normalBean.setListEachIsEnum(Lists.newArrayList("MALE", "FEMALE1"));
        Set<ConstraintViolation<JavaBean>> set = validator.validate(normalBean);
        checkMessageAndProperty("listEachIsEnum","each element may not violate the constraint: com.alibaba.fastvalidator.constraints.IsEnum with property @com.alibaba.fastvalidator.constraints.EachValidate$ConstraintProperty(name=enumType, value=com.alibaba.fastvalidator.test.GenderEnum),",set);
    }

    @Test
    public void testEachIsEnumNotProperties(){
        thrown.expect(ValidationException.class);

        Validator validator = ValidatorFactory.FAST_VALIDATOR.getValidator();
        JavaBeanForEachValidate normalBean = new JavaBeanForEachValidate();
        normalBean.setStrEachIsEnumWithoutNeededProperties("MALE,FEMALE");
        validator.validate(normalBean);
    }
}
