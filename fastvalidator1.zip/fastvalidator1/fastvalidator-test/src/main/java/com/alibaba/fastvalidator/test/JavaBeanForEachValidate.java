package com.alibaba.fastvalidator.test;

import com.alibaba.fastvalidator.constraints.EachValidate;
import com.alibaba.fastvalidator.constraints.IsEnum;
import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 *
 * @author: jasen.zhangj
 * @date: 2017-08-08
 */
@ValidateBean
public class JavaBeanForEachValidate {

    @EachValidate(constraint = IsEnum.class)
    private String strEachIsEnumWithoutNeededProperties;

    public String getStrEachIsEnumWithoutNeededProperties() {
        return strEachIsEnumWithoutNeededProperties;
    }

    public void setStrEachIsEnumWithoutNeededProperties(String strEachIsEnumWithoutNeededProperties) {
        this.strEachIsEnumWithoutNeededProperties = strEachIsEnumWithoutNeededProperties;
    }
}
