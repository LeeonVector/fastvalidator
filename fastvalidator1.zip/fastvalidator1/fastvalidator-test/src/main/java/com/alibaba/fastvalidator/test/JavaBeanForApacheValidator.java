package com.alibaba.fastvalidator.test;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.test.annotation.CustomLength;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;

/**
 * validate bean
 *
 * @author: jasen.zhangj
 * @date: 15/11/3.
 */
@ValidateBean
public class JavaBeanForApacheValidator {

    @CustomNotBlank(message = "name not blank")
    private String       name;

    @Size(max = 3, min = 1)
    private List<String> address;

    @DecimalMax("200")
    @DecimalMin("0")
    private Integer      age;

    @NotNull
    private Boolean      femail;

    @Pattern(regexp = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
    private String       email;

    @Valid
    private ComposeBean myCar;

    @CustomLength(min = 1, max = 30)
    private String       brand;

    @Digits(integer = 10, fraction = 2)
    private BigDecimal   money;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getFemail() {
        return femail;
    }

    public void setFemail(Boolean femail) {
        this.femail = femail;
    }

    public List<String> getAddress() {
        return address;
    }

    public void setAddress(List<String> address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ComposeBean getMyCar() {
        return myCar;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setMyCar(ComposeBean myCar) {
        this.myCar = myCar;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }
}
