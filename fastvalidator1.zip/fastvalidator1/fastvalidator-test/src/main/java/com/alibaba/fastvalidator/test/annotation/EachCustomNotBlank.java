package com.alibaba.fastvalidator.test.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import com.alibaba.fastvalidator.constraints.collection.EachConstraint;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 *  collection constraint of {@link CustomNotBlank}
 *
 * @author: jasen.zhangj
 * @date: 16/11/30.
 */
@Documented
@Retention(RUNTIME)
@Target({METHOD, FIELD, ANNOTATION_TYPE})
@EachConstraint(validateAs = CustomNotBlank.class)
@Constraint(validatedBy = CommonEachValidator.class)
public @interface EachCustomNotBlank {

    String message() default "";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
