package com.alibaba.fastvalidator.test.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Validate that the string is between min and max included.
 *
 * @author Emmanuel Bernard
 * @author Hardy Ferentschik
 */
@Documented
@Constraint(validatedBy = {CustomLength.CustomLengthValidator.class})
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
public @interface CustomLength {
    int min() default 0;

    int max() default Integer.MAX_VALUE;

    String message() default "{org.hibernate.validator.constraints.Length.message}";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    /**
     * Defines several {@code @Length} annotations on the same element.
     */
    @Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
    @Retention(RUNTIME)
    @Documented
    public @interface List {
        CustomLength[] value();
    }

    public static class CustomLengthValidator implements ConstraintValidator<CustomLength, CharSequence> {

        private int min;
        private int max;

        public void initialize(CustomLength parameters) {
            min = parameters.min();
            max = parameters.max();
            validateParameters();
        }

        public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext) {
            if ( value == null ) {
                return true;
            }
            int length = value.length();
            return length >= min && length <= max;
        }

        private void validateParameters() {
            if ( min < 0 ) {
                throw new IllegalArgumentException("min < 0");
            }
            if ( max < 0 ) {
                throw new IllegalArgumentException("max < 0");
            }
            if ( max < min ) {
                throw new IllegalArgumentException("max < min");
            }
        }
    }
}
