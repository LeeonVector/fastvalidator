package com.alibaba.fastvalidator.test.apache;

import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;

/**
 * performance test bean
 *
 * @author: jasen.zhangj
 * @date: 16/11/30.
 */
public class PerformanceTestBean1ForApache {

    @CustomNotBlank
    private String       name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
