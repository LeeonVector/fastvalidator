package com.alibaba.fastvalidator.test;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import com.alibaba.fastvalidator.constraints.Conditional;
import com.alibaba.fastvalidator.constraints.ConstraintDesc;
import com.alibaba.fastvalidator.constraints.Contains;
import com.alibaba.fastvalidator.constraints.EachValidate;
import com.alibaba.fastvalidator.constraints.If;
import com.alibaba.fastvalidator.constraints.Import;
import com.alibaba.fastvalidator.constraints.IsDate;
import com.alibaba.fastvalidator.constraints.IsEnum;
import com.alibaba.fastvalidator.constraints.IsJSON;
import com.alibaba.fastvalidator.constraints.NotEquals;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.collection.EachIsDate;
import com.alibaba.fastvalidator.constraints.collection.EachIsEnum;
import com.alibaba.fastvalidator.constraints.collection.EachIsJSON;
import com.alibaba.fastvalidator.constraints.collection.EachNotBlank;
import com.alibaba.fastvalidator.constraints.collection.EachRange;
import com.alibaba.fastvalidator.constraints.utils.ObjectUtils;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.test.annotation.EachCustomNotBlank;
import com.alibaba.fastvalidator.test.group.GroupA;
import com.alibaba.fastvalidator.test.group.GroupB;
import com.alibaba.fastvalidator.test.utils.CustomUtils;
import com.alibaba.fastvalidator.test.utils.StringUtils;

/**
 * validate bean
 *
 * @author: jasen.zhangj
 * @date: 15/11/3.
 */
@ValidateBean
@Import(CustomUtils.class)
@Import.List({ @Import(StringUtils.class), @Import(ObjectUtils.class) })
public class JavaBean extends BaseBean {

    @NotBlank
    private String          name;

    @Size.List({ @Size(min = 1, max = 10), @Size(min = 4, max = 9) })
    @NotNull
    private String          listSize;

    @CustomNotBlank
    private String          lastname;

    @EachCustomNotBlank
    private List<String>    cars;

    @Size(max = 3, min = 1)
    @EachNotBlank
    private List<String>    address;

    @DecimalMax("200")
    @DecimalMin("0")
    private Integer         age;

    @Range(min = -10, max = 10)
    @NotNull
    private Integer         ageRange;

    @Range.List({ @Range(min = 10, max = 20), @Range(min = 12, max = 15) })
    @NotNull
    private Integer         ranges;

    @EachRange(min = -10, max = 20)
    @NotEmpty
    private List<Integer>   eachRange;

    @NotNull
    @IsEnum(enumType = GenderEnum.class)
    private String          gender;

    @EachIsEnum(enumType = GenderEnum.class)
    private List<String>    childrenGenders;

    @Pattern(regexp = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
    private String          email;

    @Email
    @NotBlank
    @Length(max=32)
    private String          email2;

    @Valid
    private ComposeJavaBean composeBean;

    @Length(min = 1, max = 30)
    private String          brand;

    @Length(min = 1, max = 30, message = "lengthWithCodeAndMessage is illegal|lengthWithCodeAndMessage_illegal")
    private String          lengthWithCodeAndMessage;

    @Digits(integer = 10, fraction = 2)
    private BigDecimal      money;

    @NotEmpty
    private String          color;

    @Conditional(sourceCode = "bean.getConditionNotNull() == null", message = "conditionNotNull is null")
    private String          conditionNotNull;

    private String          password;

    @Conditional(sourceCode = "!ObjectUtils.equals(bean.getPassword(), bean.getRepassword())", message = "password not equal repassword")
    private String          repassword;

    @If(sourceCode = "StringUtils.isBlank(bean.getIfConstraint())", message = "ifConstraint is blank")
    @ConstraintDesc(order = 200, constraint = If.class)
    private String          ifConstraint;

    @If(sourceCode = "!ObjectUtils.equals(bean.ifConstraint, bean.ifConstraint2)", message = "ifConstraint not equal ifConstraint2")
    @ConstraintDesc(order = 100, constraint = If.class)
    private String          ifConstraint2;

    @If(sourceCode = "bean.getIfConstraintBoolean() == null", message = "ifConstraintBoolean is null")
    @ConstraintDesc(order = 200, constraint = If.class)
    private Boolean         ifConstraintBoolean;

    @If(sourceCode = "!ObjectUtils.equals(bean.ifConstraintBoolean2, bean.ifConstraintBoolean)", message = "ifConstraintBoolean not equal ifConstraintBoolean2")
    @ConstraintDesc(order = 100, constraint = If.class)
    private Boolean         ifConstraintBoolean2;

    @If(sourceCode = "!ObjectUtils.equals(bean.boolean1, bean.boolean2)", message = "boolean1 not equal boolean2")
    @ConstraintDesc(order = 300, constraint = If.class)
    private boolean         boolean1;
    private boolean         boolean2;

    @IsJSON
    @NotBlank
    private String          jsonString;

    @NotNull
    @EachIsJSON
    private List<String>    eachJsonString;

    @NotEmpty
    @IsDate(dateFormat = "yyyy-MM-dd HH:mm:ss")
    private String          birth;

    @NotNull
    @EachIsDate(dateFormat = "yyyy-MM-dd HH:mm:ss")
    private List<String>    childrenBirth;

    @Size(min = 1)
    @NotNull
    private long[]          primitiveArray;

    @NotNull
    @Size(min = 1)
    private JavaBean[]      objectArray;

    @Contains(value = "1", type = Contains.Type.INT)
    private int[]           contains;

    @NotBlank(groups = Serializable.class)
    private String          group1;

    @If(sourceCode = "StringUtils.isBlank(bean.group2)", message = "group2 is empty", groups = GroupA.class)
    private String          group2;

    @NotBlank(groups = { GroupA.class, GroupB.class })
    private String          group3;

    @NotEquals("null")
    private String          notEquals;

    @NotEquals(value = "null", ignoreCase = true)
    private String          notEquals2;

    @NotBlank(message = "messageAndCode may be empty|messageAndCode_is_blank")
    private String          messageAndCode;

    @Valid
    private List<ComposeBean> composeBeanList;

    @EachValidate(constraint = Size.class, constraintProperties = {
            @EachValidate.ConstraintProperty(name = "min", value = "5"),
            @EachValidate.ConstraintProperty(name = "max", value = "15")
    })
    private String strEachValueSize;

    @EachValidate(constraint = Size.class, constraintProperties = {
            @EachValidate.ConstraintProperty(name = "min", value = "5"),
            @EachValidate.ConstraintProperty(name = "max", value = "15")
    })
    private List<String> listEachValueSize;

    @EachValidate(constraint = Email.class, separator = "|", constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name = "regexp",
                    value = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
            }
    )
    private String strEachValueEmail;

    @EachValidate(constraint = Email.class,  constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name = "regexp",
                    value = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
    }
    )
    private List<String> listEachValueEmail;


    @EachValidate(constraint = NotBlank.class, separator = "|", preserveAllTokens = true)
    private String strEachNotBlank;

    @EachValidate(constraint = Range.class, constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name = "min", value = "0"
            ),
            @EachValidate.ConstraintProperty(
                    name="max", value = Long.MAX_VALUE + ""
            )
    })
    private String strEachRange;

    @EachValidate(constraint = Range.class, constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name = "min", value = "0"
            ),
            @EachValidate.ConstraintProperty(
                    name="max", value = Long.MAX_VALUE + ""
            )
    })
    private List<Long> listEachRange;

    @EachValidate(constraint = IsEnum.class, constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name="enumType", value = "com.alibaba.fastvalidator.test.GenderEnum"
            )
    })
    private String strEachIsEnum;

    @EachValidate(constraint = IsEnum.class, constraintProperties = {
            @EachValidate.ConstraintProperty(
                    name="enumType", value = "com.alibaba.fastvalidator.test.GenderEnum"
            )
    })
    private List<String> listEachIsEnum;

    public String getStrEachRange() {
        return strEachRange;
    }

    public void setStrEachRange(String strEachRange) {
        this.strEachRange = strEachRange;
    }

    public List<Long> getListEachRange() {
        return listEachRange;
    }

    public void setListEachRange(List<Long> listEachRange) {
        this.listEachRange = listEachRange;
    }

    public String getStrEachIsEnum() {
        return strEachIsEnum;
    }

    public void setStrEachIsEnum(String strEachIsEnum) {
        this.strEachIsEnum = strEachIsEnum;
    }

    public List<String> getListEachIsEnum() {
        return listEachIsEnum;
    }

    public void setListEachIsEnum(List<String> listEachIsEnum) {
        this.listEachIsEnum = listEachIsEnum;
    }

    public List<ComposeBean> getComposeBeanList() {
        return composeBeanList;
    }

    public void setComposeBeanList(List<ComposeBean> composeBeanList) {
        this.composeBeanList = composeBeanList;
    }

    public String getLengthWithCodeAndMessage() {
        return lengthWithCodeAndMessage;
    }

    public void setLengthWithCodeAndMessage(String lengthWithCodeAndMessage) {
        this.lengthWithCodeAndMessage = lengthWithCodeAndMessage;
    }

    public String getMessageAndCode() {
        return messageAndCode;
    }

    public void setMessageAndCode(String messageAndCode) {
        this.messageAndCode = messageAndCode;
    }

    public String getNotEquals() {
        return notEquals;
    }

    public void setNotEquals(String notEquals) {
        this.notEquals = notEquals;
    }

    public String getNotEquals2() {
        return notEquals2;
    }

    public void setNotEquals2(String notEquals2) {
        this.notEquals2 = notEquals2;
    }

    public String getGroup1() {
        return group1;
    }

    public void setGroup1(String group1) {
        this.group1 = group1;
    }

    public String getGroup2() {
        return group2;
    }

    public void setGroup2(String group2) {
        this.group2 = group2;
    }

    public String getConditionNotNull() {
        return conditionNotNull;
    }

    public void setConditionNotNull(String conditionNotNull) {
        this.conditionNotNull = conditionNotNull;
    }

    public long[] getPrimitiveArray() {
        return primitiveArray;
    }

    public void setPrimitiveArray(long[] primitiveArray) {
        this.primitiveArray = primitiveArray;
    }

    public JavaBean[] getObjectArray() {
        return objectArray;
    }

    public void setObjectArray(JavaBean[] objectArray) {
        this.objectArray = objectArray;
    }

    public List<String> getEachJsonString() {
        return eachJsonString;
    }

    public void setEachJsonString(List<String> eachJsonString) {
        this.eachJsonString = eachJsonString;
    }

    public List<String> getChildrenBirth() {
        return childrenBirth;
    }

    public void setChildrenBirth(List<String> childrenBirth) {
        this.childrenBirth = childrenBirth;
    }

    public String getJsonString() {
        return jsonString;
    }

    public void setJsonString(String jsonString) {
        this.jsonString = jsonString;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRepassword() {
        return repassword;
    }

    public void setRepassword(String repassword) {
        this.repassword = repassword;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<String> getAddress() {
        return address;
    }

    public void setAddress(List<String> address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public ComposeJavaBean getComposeBean() {
        return composeBean;
    }

    public void setComposeBean(ComposeJavaBean composeBean) {
        this.composeBean = composeBean;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public List<String> getCars() {
        return cars;
    }

    public void setCars(List<String> cars) {
        this.cars = cars;
    }

    public List<String> getChildrenGenders() {
        return childrenGenders;
    }

    public void setChildrenGenders(List<String> childrenGenders) {
        this.childrenGenders = childrenGenders;
    }

    public Integer getAgeRange() {
        return ageRange;
    }

    public void setAgeRange(Integer ageRange) {
        this.ageRange = ageRange;
    }

    public List<Integer> getEachRange() {
        return eachRange;
    }

    public void setEachRange(List<Integer> eachRange) {
        this.eachRange = eachRange;
    }

    public Integer getRanges() {
        return ranges;
    }

    public void setRanges(Integer ranges) {
        this.ranges = ranges;
    }

    public String getListSize() {
        return listSize;
    }

    public void setListSize(String listSize) {
        this.listSize = listSize;
    }

    public String getIfConstraint() {
        return ifConstraint;
    }

    public void setIfConstraint(String ifConstraint) {
        this.ifConstraint = ifConstraint;
    }

    public String getIfConstraint2() {
        return ifConstraint2;
    }

    public void setIfConstraint2(String ifConstraint2) {
        this.ifConstraint2 = ifConstraint2;
    }

    public Boolean getIfConstraintBoolean() {
        return ifConstraintBoolean;
    }

    public void setIfConstraintBoolean(Boolean ifConstraintBoolean) {
        this.ifConstraintBoolean = ifConstraintBoolean;
    }

    public Boolean getIfConstraintBoolean2() {
        return ifConstraintBoolean2;
    }

    public void setIfConstraintBoolean2(Boolean ifConstraintBoolean2) {
        this.ifConstraintBoolean2 = ifConstraintBoolean2;
    }

    public boolean isBoolean1() {
        return boolean1;
    }

    public void setBoolean1(boolean boolean1) {
        this.boolean1 = boolean1;
    }

    public boolean isBoolean2() {
        return boolean2;
    }

    public void setBoolean2(boolean boolean2) {
        this.boolean2 = boolean2;
    }

    public int[] getContains() {
        return contains;
    }

    public void setContains(int[] contains) {
        this.contains = contains;
    }

    public String getGroup3() {
        return group3;
    }

    public void setGroup3(String group3) {
        this.group3 = group3;
    }

    public String getEmail2() {
        return email2;
    }

    public void setEmail2(String email2) {
        this.email2 = email2;
    }

    public String getStrEachValueSize() {
        return strEachValueSize;
    }

    public void setStrEachValueSize(String strEachValueSize) {
        this.strEachValueSize = strEachValueSize;
    }

    public List<String> getListEachValueSize() {
        return listEachValueSize;
    }

    public void setListEachValueSize(List<String> listEachValueSize) {
        this.listEachValueSize = listEachValueSize;
    }

    public String getStrEachValueEmail() {
        return strEachValueEmail;
    }

    public void setStrEachValueEmail(String strEachValueEmail) {
        this.strEachValueEmail = strEachValueEmail;
    }

    public List<String> getListEachValueEmail() {
        return listEachValueEmail;
    }

    public void setListEachValueEmail(List<String> listEachValueEmail) {
        this.listEachValueEmail = listEachValueEmail;
    }

    public String getStrEachNotBlank() {
        return strEachNotBlank;
    }

    public void setStrEachNotBlank(String strEachNotBlank) {
        this.strEachNotBlank = strEachNotBlank;
    }
}
