package com.alibaba.fastvalidator.test.spring;

import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.ParameterScriptAssert;
import com.alibaba.fastvalidator.jsr.bean.Validate;
import com.alibaba.fastvalidator.test.JavaBean;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.test.group.GroupA;

/**
 * just for test service
 *
 * @author: jasen.zhangj
 * @date: 16/11/23.
 */
public interface ValidatorService extends  Serializable {

    void nothing();

    void insertJavaBean(@Valid JavaBean javaBean);

    void insertJavaBeanComposeBean(@Valid JavaBean javaBean);

    void insertJavaBean(@Valid JavaBean javaBean, @CustomNotBlank String name);

    void insertJavaBean(@NotBlank String name, @Valid JavaBean javaBean);

    void insertJavaBeanWithoutConstraint(JavaBean javaBean);

    ReturnTypeWithCodeAndMessageField returnTypeWithCodeAndMessageAnnotationField(@Valid JavaBean javaBean);

    ReturnTypeWithCodeAndMessageDefaultMethod returnTypeWithCodeAndMessageDefaultMethod(@Valid JavaBean javaBean);

    ReturnTypeWithoutMessageDefaultMethod returnTypeWithoutMessageDefaultMethod(@Valid JavaBean javaBean);

    ReturnTypeWithoutCodeDefaultMethod insertJavaBeanWithoutCode(@Valid JavaBean javaBean);

    ReturnTypeWithCodeAndMessageAnnotationMethod returnTypeWithCodeAndMessageAnnotationMethod(@Valid JavaBean javaBean);

    ReturnTypeWithFVMessageAnnotationMethod returnTypeWithFVMessageAnnotationMethod(@Valid JavaBean javaBean);

    ReturnTypeWithFVCodeAnnotationMethod returnTypeWithFVCodeAnnotationMethod(@Valid JavaBean javaBean);

    void insertJavaBeanWithVoidType(@Valid JavaBean javaBean);

    ReturnTypeWithoutCodeAndMessage returnTypeWithoutCodeAndMessage(@Valid JavaBean javaBean);

    @Validate(groups = Serializable.class)
    void insertJavaBeanWithGroup(@Valid JavaBean javaBean);

    @Validate(groups = Serializable.class)
    void insertJavaBeanWithGroup2(@Valid  JavaBean javaBean, @CustomNotBlank(groups = Serializable.class) String name);

    @Validate(groups = GroupA.class)
    void insertJavaBeanWithGroup3(@Valid JavaBean javaBean);

    @Validate(groups = {GroupA.class, Default.class})
    void insertJavaBeanWithGroup4(@Valid JavaBean javaBean);

    @Validate
    @ParameterScriptAssert(lang = "javascript", script = "arg0.name==arg1.name", message = "javaBean1's name not equals javaBean2's name|ARGS_NAME_NOT_EQUALS")
    ReturnTypeWithCodeAndMessageField testParameterScriptAssert(JavaBean javaBean1, JavaBean javaBean2);

    @NotNull
    Integer returnTypeWithSimpleConstraintReturnNull();

    @Validate
    ReturnTypeWithConstraint returnTypeWithConstraintReturnNull();


    @Validate
    ReturnTypeWithConstraint returnTypeWithConstraintReturnNormal();

    @Validate
    ReturnTypeWithConstraint returnTypeWithConstraintReturnNormal(@Valid JavaBean javaBean);

    @Validate
    ReturnTypeWithConstraint returnTypeWithConstraintAndParameterConstraint(@Valid JavaBean javaBean);

    @Validate
    ReturnTypeWithConstraint returnTypeWithConstraintAndParameterConstraintNormal(@Valid JavaBean javaBean);
}
