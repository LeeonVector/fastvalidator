package com.alibaba.fastvalidator.test;

import org.hibernate.validator.constraints.NotEmpty;
import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/04/2017.
 */
@ValidateBean
public class JavaBean2 extends JavaBean {

    @NotEmpty
    private String constant = "1234";

    public String getConstant() {
        return constant;
    }

    public void setConstant(String constant) {
        this.constant = constant;
    }
}
