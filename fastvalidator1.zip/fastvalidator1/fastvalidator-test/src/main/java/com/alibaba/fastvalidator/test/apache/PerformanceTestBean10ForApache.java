package com.alibaba.fastvalidator.test.apache;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.test.annotation.EachCustomNotBlank;

/**
 * performance test bean
 *
 * @author: jasen.zhangj
 * @date: 15/11/3.
 */
public class PerformanceTestBean10ForApache {

    @CustomNotBlank
    private String       name;

    @CustomNotBlank
    private String       lastname;

    @Size(max = 3, min = 1)
    @EachCustomNotBlank
    private List<String> address;

    @DecimalMax("200")
    @DecimalMin("0")
    private Integer      age;

    @NotNull
    private Boolean      femail;

    @Pattern(regexp = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
    private String       email;

    @Valid
    private ComposeBeanForApache  composeBean;

    @Digits(integer = 10, fraction = 2)
    private BigDecimal   money;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getFemail() {
        return femail;
    }

    public void setFemail(Boolean femail) {
        this.femail = femail;
    }

    public List<String> getAddress() {
        return address;
    }

    public void setAddress(List<String> address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public ComposeBeanForApache getComposeBean() {
        return composeBean;
    }

    public void setComposeBean(ComposeBeanForApache composeBean) {
        this.composeBean = composeBean;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
}
