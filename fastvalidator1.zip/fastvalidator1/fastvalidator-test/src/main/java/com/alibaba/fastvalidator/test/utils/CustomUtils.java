package com.alibaba.fastvalidator.test.utils;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public class CustomUtils {

    public int customCompare(String a, String b) {
        return a.compareTo(b);
    }
}
