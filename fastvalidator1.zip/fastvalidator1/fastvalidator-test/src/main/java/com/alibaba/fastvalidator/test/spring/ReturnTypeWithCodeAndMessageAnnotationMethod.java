package com.alibaba.fastvalidator.test.spring;


import com.alibaba.fastvalidator.constraints.FVCode;
import com.alibaba.fastvalidator.constraints.FVMessage;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/12/14.
 */
public class ReturnTypeWithCodeAndMessageAnnotationMethod {

    private String code;

    private String message;


    public String getCode() {
        return code;
    }

    @FVCode
    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    @FVMessage
    public void setMessage(String message) {
        this.message = message;
    }
}
