package com.alibaba.fastvalidator.test;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * base bean
 *
 * @author: jasen.zhangj
 * @date: 16/9/12.
 */
// @ClassAnnotation
public class BaseBean {

    @NotNull
    private String parentPro1;

    private String parentPro2 = "test";

    public String getParentPro1() {
        return parentPro1;
    }

    public void setParentPro1(String parentPro1) {
        this.parentPro1 = parentPro1;
    }

    public String getParentPro2() {
        return parentPro2;
    }

    public void setParentPro2(String parentPro2) {
        this.parentPro2 = parentPro2;
    }

    @ValidateBean
    public static class InnerBean {

        @NotBlank
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @ValidateBean
    public class InnerBean2 {

        @NotBlank
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
