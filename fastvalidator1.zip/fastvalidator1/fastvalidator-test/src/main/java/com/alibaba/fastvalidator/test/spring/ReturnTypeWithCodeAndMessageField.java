package com.alibaba.fastvalidator.test.spring;

import com.alibaba.fastvalidator.constraints.FVCode;
import com.alibaba.fastvalidator.constraints.FVMessage;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/12/14.
 */
public class ReturnTypeWithCodeAndMessageField {

    @FVCode
    private String code;

    @FVMessage
    private String message;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
