package com.alibaba.fastvalidator.test;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/3/22.
 */
@ValidateBean
public class ComposeBean {

    @NotBlank
    private String  color;

    @NotNull
    private Integer miles;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }
}
