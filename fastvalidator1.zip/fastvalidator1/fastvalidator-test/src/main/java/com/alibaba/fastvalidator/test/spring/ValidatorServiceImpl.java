package com.alibaba.fastvalidator.test.spring;

import javax.validation.Valid;
import com.alibaba.fastvalidator.test.JavaBean;
import com.alibaba.fastvalidator.test.spring.helper.ServiceInvokeHelper;

/**
 *
 * @author: jasen.zhangj
 * @date: 16/11/23.
 */
public class ValidatorServiceImpl implements ValidatorService {

    private static final long serialVersionUID = 8371371659119958830L;

    @Override
    public void nothing() {
        ServiceInvokeHelper.collect("nothing");
    }

    @Override
    public void insertJavaBean(String name, JavaBean normalBean) {
        ServiceInvokeHelper.collect("insertJavaBean");
    }

    @Override
    public void insertJavaBean(JavaBean normalBean) {

    }

    @Override
    public void insertJavaBeanComposeBean(JavaBean normalBean) {

    }

    @Override
    public void insertJavaBean(JavaBean normalBean, String name) {

    }

    @Override
    public void insertJavaBeanWithoutConstraint(JavaBean normalBean) {

    }

    @Override
    public ReturnTypeWithCodeAndMessageField returnTypeWithCodeAndMessageAnnotationField(@Valid JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithCodeAndMessageDefaultMethod returnTypeWithCodeAndMessageDefaultMethod(JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithoutMessageDefaultMethod returnTypeWithoutMessageDefaultMethod(JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithCodeAndMessageAnnotationMethod returnTypeWithCodeAndMessageAnnotationMethod(JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithoutCodeDefaultMethod insertJavaBeanWithoutCode(JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithFVMessageAnnotationMethod returnTypeWithFVMessageAnnotationMethod(JavaBean javaBean) {
        return null;
    }

    @Override
    public ReturnTypeWithFVCodeAnnotationMethod returnTypeWithFVCodeAnnotationMethod(JavaBean javaBean) {
        return null;
    }

    @Override
    public void insertJavaBeanWithVoidType(JavaBean javaBean) {

    }

    @Override
    public ReturnTypeWithoutCodeAndMessage returnTypeWithoutCodeAndMessage(JavaBean javaBean) {
        return null;
    }

    @Override
    public void insertJavaBeanWithGroup(JavaBean normalBean) {

    }

    @Override
    public void insertJavaBeanWithGroup2(JavaBean javaBean, String name) {

    }

    @Override
    public void insertJavaBeanWithGroup3(JavaBean javaBean) {

    }

    @Override
    public void insertJavaBeanWithGroup4(JavaBean javaBean) {

    }

    @Override
    public ReturnTypeWithCodeAndMessageField testParameterScriptAssert(JavaBean javaBean1, JavaBean javaBean2) {
        return null;
    }

    @Override
    public Integer returnTypeWithSimpleConstraintReturnNull() {
        return null;
    }

    @Override
    public ReturnTypeWithConstraint returnTypeWithConstraintReturnNull() {
        return null;
    }

    @Override
    public ReturnTypeWithConstraint returnTypeWithConstraintReturnNormal() {
        ReturnTypeWithConstraint returnTypeWithConstraint = new ReturnTypeWithConstraint();
        returnTypeWithConstraint.setName(null);

        returnTypeWithConstraint.setListSize("aaa45");
        return returnTypeWithConstraint;
    }

    @Override
    public ReturnTypeWithConstraint returnTypeWithConstraintReturnNormal(@Valid JavaBean javaBean) {
        ReturnTypeWithConstraint returnTypeWithConstraint = new ReturnTypeWithConstraint();
        returnTypeWithConstraint.setName(null);

        returnTypeWithConstraint.setListSize("aaa45");
        return returnTypeWithConstraint;
    }

    @Override
    public ReturnTypeWithConstraint returnTypeWithConstraintAndParameterConstraint(@Valid JavaBean javaBean) {
        ReturnTypeWithConstraint returnTypeWithConstraint = new ReturnTypeWithConstraint();
        returnTypeWithConstraint.setName("name");
        returnTypeWithConstraint.setListSize("aaa45");
        returnTypeWithConstraint.setIfConstraint2("nothoing");

        return returnTypeWithConstraint;
    }

    @Override
    public ReturnTypeWithConstraint returnTypeWithConstraintAndParameterConstraintNormal(@Valid JavaBean javaBean) {
        ReturnTypeWithConstraint returnTypeWithConstraint = new ReturnTypeWithConstraint();
        returnTypeWithConstraint.setName("name");
        returnTypeWithConstraint.setListSize("aaa45");

        return returnTypeWithConstraint;
    }
}
