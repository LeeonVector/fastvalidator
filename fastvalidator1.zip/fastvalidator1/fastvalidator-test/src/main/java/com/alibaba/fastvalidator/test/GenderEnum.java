package com.alibaba.fastvalidator.test;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public enum GenderEnum {

    MALE, FEMALE;

}
