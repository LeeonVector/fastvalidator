package com.alibaba.fastvalidator.test;

import com.alibaba.fastvalidator.constraints.Contains;
import com.alibaba.fastvalidator.constraints.ValidateBean;

import java.util.List;
import java.util.Map;

/**
 * Created by jipengfei on 17/2/21.
 */
@ValidateBean
public class ContainsJavaBean {


    @Contains(value = "1",type = Contains.Type.STRING,message = "most contais a")
    private String var1;

    @Contains.List({
        @Contains(value = "a",type = Contains.Type.STRING),
        @Contains(value = "a",type = Contains.Type.STRING)
    })
    private Map<String,String> var2;

    @Contains(value = "a",type = Contains.Type.STRING)
    private List<String> var3;

    @Contains(value = "1" ,type= Contains.Type.LONG)
    private List<Long> var4;

    @Contains(value = "1" ,type= Contains.Type.DOUBLE)
    private Double[] var5;

    @Contains(value = "1" ,type= Contains.Type.LONG)
    private Long[] var6;

    @Contains(value = "1" ,type= Contains.Type.INT)
    private int[] var7;

    @Contains(value = "1.0",type = Contains.Type.FLOAT)
    private Float[] var8;

    @Contains(value = "true",type = Contains.Type.BOOLEAN)
    private Boolean[] var9;

    @Contains(value = "0",type = Contains.Type.DOUBLE)
    private Double[] var10;

    @Contains(value = "true",type = Contains.Type.STRING)
    private String[] var11;


    @Contains.List({@Contains(value = "1" ,type= Contains.Type.LONG),@Contains(value = "2",type = Contains.Type.LONG)})
    private List<Long> var13;


    public Double[] getVar10() {
        return var10;
    }

    public void setVar10(Double[] var10) {
        this.var10 = var10;
    }



    public String getVar1() {
        return var1;
    }

    public void setVar1(String var1) {
        this.var1 = var1;
    }

    public Map<String, String> getVar2() {
        return var2;
    }

    public void setVar2(Map<String, String> var2) {
        this.var2 = var2;
    }

    public List<String> getVar3() {
        return var3;
    }

    public void setVar3(List<String> var3) {
        this.var3 = var3;
    }

    public List<Long> getVar4() {
        return var4;
    }

    public void setVar4(List<Long> var4) {
        this.var4 = var4;
    }

    public Double[] getVar5() {
        return var5;
    }

    public void setVar5(Double[] var5) {
        this.var5 = var5;
    }

    public Long[] getVar6() {
        return var6;
    }

    public void setVar6(Long[] var6) {
        this.var6 = var6;
    }

    public int[] getVar7() {
        return var7;
    }

    public void setVar7(int[] var7) {
        this.var7 = var7;
    }

    public Float[] getVar8() {
        return var8;
    }

    public void setVar8(Float[] var8) {
        this.var8 = var8;
    }

    public Boolean[] getVar9() {
        return var9;
    }

    public void setVar9(Boolean[] var9) {
        this.var9 = var9;
    }

    public String[] getVar11() {
        return var11;
    }

    public void setVar11(String[] var11) {
        this.var11 = var11;
    }

    public List<Long> getVar13() {
        return var13;
    }

    public void setVar13(List<Long> var13) {
        this.var13 = var13;
    }
}


