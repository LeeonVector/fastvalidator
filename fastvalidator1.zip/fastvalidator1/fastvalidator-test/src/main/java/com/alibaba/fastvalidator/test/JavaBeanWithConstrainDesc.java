package com.alibaba.fastvalidator.test;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.ConstraintDesc;
import com.alibaba.fastvalidator.constraints.ConstraintDescList;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.test.annotation.EachCustomNotBlank;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/12/13.
 */
@ValidateBean
public class JavaBeanWithConstrainDesc {

    @NotBlank
    @ConstraintDesc(order = 100, code = "name_illegal")
    private String      name;

    @CustomNotBlank(message = "lastname can't be empty")
    @ConstraintDesc(order = 200, code = "lastname_illegal")
    private String      lastname;

    @Valid
    @ConstraintDesc(order = 300, code = "composeBean_illegal")
    private ComposeBean composeBean;

    @Digits(integer = 10, fraction = 2)
    private BigDecimal  money;

    @DecimalMax("200")
    @DecimalMin("0")
    @ConstraintDescList({ @ConstraintDesc(constraint = DecimalMax.class, code = "age_max", order = 50),
                           @ConstraintDesc(constraint = DecimalMin.class, code = "age_min", order = 250) })
    private Integer     age;

    @EachCustomNotBlank
    @ConstraintDesc(order = 120, code = "cars_is_empty")
    private List<String> cars;

    @Length(min = 1, max = 30, message = "brand is illegal|brand_illegal")
    private String       brand;

    public List<String> getCars() {
        return cars;
    }

    public void setCars(List<String> cars) {
        this.cars = cars;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public ComposeBean getComposeBean() {
        return composeBean;
    }

    public void setComposeBean(ComposeBean composeBean) {
        this.composeBean = composeBean;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
