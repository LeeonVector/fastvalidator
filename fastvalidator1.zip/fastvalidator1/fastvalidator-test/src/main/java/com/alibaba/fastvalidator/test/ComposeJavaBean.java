package com.alibaba.fastvalidator.test;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * Compose bean for normal test
 *
 * @author: jasen.zhangj
 * @date: 2017/3/13.
 */
@ValidateBean
public class ComposeJavaBean extends BaseBean {

    @NotBlank
    private String  color;

    @NotNull
    private Integer miles;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }
}
