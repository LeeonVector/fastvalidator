package com.alibaba.fastvalidator.test;

import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * performance test bean
 *
 * @author: jasen.zhangj
 * @date: 16/11/30.
 */
@ValidateBean
public class PerformanceTestBean1 {

    @NotBlank
    private String       name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
