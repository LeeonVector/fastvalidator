package com.alibaba.fastvalidator.test.group;

/**
 * Group to validate
 *
 * @author: jasen.zhangj
 * @date: 24/03/2017.
 */
public interface GroupA {
}
