package com.alibaba.fastvalidator.test.spring;


import com.alibaba.fastvalidator.constraints.FVCode;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/12/14.
 */
public class ReturnTypeWithFVCodeAnnotationMethod {

    private String code;

    private String message;


    public String getCode() {
        return code;
    }

    @FVCode
    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
