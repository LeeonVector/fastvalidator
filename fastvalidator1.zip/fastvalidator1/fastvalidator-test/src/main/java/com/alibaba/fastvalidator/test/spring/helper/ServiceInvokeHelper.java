package com.alibaba.fastvalidator.test.spring.helper;

import java.util.ArrayList;
import java.util.List;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-07-24
 */
public class ServiceInvokeHelper {

    private static List<String> list = new ArrayList<>();

    public static void collect(String value){
        list.add(value);
    }

    public static void check(String value, int size){
        assertTrue("size is not equals",list.size() == size);
        assertTrue("size is not equals",list.contains(value));
    }

    public static void clear(){
        list.clear();
    }

    static private void assertTrue(String message, boolean condition) {
        if (!condition){
            throw new IllegalArgumentException(message);
        }
    }
}
