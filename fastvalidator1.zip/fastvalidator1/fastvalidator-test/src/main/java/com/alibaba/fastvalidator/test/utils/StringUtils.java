package com.alibaba.fastvalidator.test.utils;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public class StringUtils {

    public int compare(String a, String b) {
        return a.compareTo(b);
    }
}
