package com.alibaba.fastvalidator.test.apache;

import javax.validation.constraints.NotNull;
import com.alibaba.fastvalidator.test.annotation.CustomNotBlank;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 16/3/22.
 */
public class ComposeBeanForApache {

    @CustomNotBlank
    private String color;

    @NotNull
    private Integer miles;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getMiles() {
        return miles;
    }

    public void setMiles(Integer miles) {
        this.miles = miles;
    }
}
