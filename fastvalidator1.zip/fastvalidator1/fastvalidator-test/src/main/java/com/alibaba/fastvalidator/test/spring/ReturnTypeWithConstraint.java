package com.alibaba.fastvalidator.test.spring;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import com.alibaba.fastvalidator.constraints.If;
import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 *
 * @author: jasen.zhangj
 * @date: 2017-08-04
 */
@ValidateBean
public class ReturnTypeWithConstraint {

    @NotBlank
    private String          name;

    @Size.List({ @Size(min = 1, max = 10), @Size(min = 4, max = 9) })
    @NotNull
    private String          listSize;

    @If(sourceCode = "!ObjectUtils.equals(\"ifConstraint2\", bean.ifConstraint2)", message = "ifConstraint2 not equal 'ifConstraint2'")
    private String          ifConstraint2 = "ifConstraint2";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getListSize() {
        return listSize;
    }

    public void setListSize(String listSize) {
        this.listSize = listSize;
    }

    public String getIfConstraint2() {
        return ifConstraint2;
    }

    public void setIfConstraint2(String ifConstraint2) {
        this.ifConstraint2 = ifConstraint2;
    }
}
