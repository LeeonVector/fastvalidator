package com.alibaba.fastvalidator.test;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.collection.EachNotBlank;


/**
 * performance test bean
 *
 * @author: jasen.zhangj
 * @date: 16/11/30.
 */
@ValidateBean
public class PerformanceTestBean5 {

    @Size(max = 3, min = 1)
    @EachNotBlank
    private List<String> address;

    @DecimalMax("200")
    @DecimalMin("0")
    private Integer      age;

    @NotNull
    private Boolean      femail;

    @Pattern(regexp = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$")
    private String       email;

    @Valid
    private ComposeBean  composeBean;

    public List<String> getAddress() {
        return address;
    }

    public void setAddress(List<String> address) {
        this.address = address;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Boolean getFemail() {
        return femail;
    }

    public void setFemail(Boolean femail) {
        this.femail = femail;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ComposeBean getComposeBean() {
        return composeBean;
    }

    public void setComposeBean(ComposeBean composeBean) {
        this.composeBean = composeBean;
    }
}
