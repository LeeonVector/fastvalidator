package com.alibaba.boot.fastvalidator;

import javax.validation.MessageInterpolator;
import javax.validation.Validator;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.boot.fastvalidator.processor.FastValidatorBeanPostProcessor;
import com.alibaba.boot.fastvalidator.properties.FastValidatorProperties;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.FastValidatorMessageInterpolator;
import com.alibaba.fastvalidator.core.FastValidator;
import com.alibaba.fastvalidator.core.helper.WarmUpHelper;

/**
 * fastvalidator auto configuration
 *
 * @author jipengfei
 * @author: jasen.zhangj
 * @date: 16/12/9.
 */
@Configuration
@EnableConfigurationProperties(FastValidatorProperties.class)
public class FastValidatorAutoConfiguration implements InitializingBean {

    private Validator               validator;

    @Autowired
    private MessageInterpolator     messageInterpolator;

    @Autowired
    private FastValidatorProperties fastValidatorProperties;

    @Override
    public void afterPropertiesSet() throws Exception {
        validator = FastValidator.builder().failFast(fastValidatorProperties.isFailFast()).logValidateDetail(fastValidatorProperties.isLogValidateDetail()).messageInterpolator(messageInterpolator).build();

        String validateBeanPackage = fastValidatorProperties.getWarmupPackage();
        WarmUpHelper.warmUpValidateBean(validateBeanPackage, validator);
    }

    /**
     * Common service validate
     *
     * @return
     */
    @Bean
    @ConditionalOnClass(name = "com.alibaba.boot.fastvalidator.annotation.ValidateService")
    public FastValidatorBeanPostProcessor fastValidatorServiceBeanPostProcessor() {
        return new FastValidatorBeanPostProcessor("com.alibaba.boot.fastvalidator.annotation.ValidateService",
                                                  validator);
    }

    /**
     * AE HSF validate
     *
     * @return
     */
    @Bean
    @ConditionalOnClass(name = "com.taobao.hsf.app.spring.util.annotation.HSFProvider")
    public FastValidatorBeanPostProcessor fastValidatorHSFBeanPostProcessor() {
        return new FastValidatorBeanPostProcessor("com.taobao.hsf.app.spring.util.annotation.HSFProvider", validator);
    }

    /**
     * Pandora boot HSF validate
     *
     * @return
     */
    @Bean
    @ConditionalOnClass(name = "com.alibaba.boot.hsf.annotation.HSFProvider")
    public FastValidatorBeanPostProcessor fastValidatorPandoraHSFBeanPostProcessor() {
        return new FastValidatorBeanPostProcessor("com.alibaba.boot.hsf.annotation.HSFProvider", validator);
    }

    @Bean
    @ConditionalOnMissingBean(MessageInterpolator.class)
    public MessageInterpolator messageInterpolator(){
        return new FastValidatorMessageInterpolator();
    }

    @Bean
    public Validator validator() {
        return validator;
    }
}
