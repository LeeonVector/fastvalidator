package com.alibaba.boot.fastvalidator.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Configuration of fast valiator
 *
 * @author: jasen.zhangj
 * @date: 2017/3/13.
 */
@ConfigurationProperties(prefix = "fastvalidator", ignoreUnknownFields = true)
public class FastValidatorProperties {

    @Value("${fastvalidator.failfast:true}")
    private boolean failFast = true;

    @Value("${fastvalidator.warmup.package:}")
    private String  warmupPackage;

    @Value("${fastvalidator.logvalidateresult:false}")
    private boolean logValidateDetail = false;

    public boolean isFailFast() {
        return failFast;
    }

    public void setFailFast(boolean failFast) {
        this.failFast = failFast;
    }

    public String getWarmupPackage() {
        return warmupPackage;
    }

    public void setWarmupPackage(String warmupPackage) {
        this.warmupPackage = warmupPackage;
    }

    public boolean isLogValidateDetail() {
        return logValidateDetail;
    }

    public void setLogValidateDetail(boolean logValidateDetail) {
        this.logValidateDetail = logValidateDetail;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("FastValidatorProperties{");
        sb.append("failFast=").append(failFast);
        sb.append(", warmupPackage='").append(warmupPackage).append('\'');
        sb.append(", logValidateDetail=").append(logValidateDetail);
        sb.append('}');
        return sb.toString();
    }
}
