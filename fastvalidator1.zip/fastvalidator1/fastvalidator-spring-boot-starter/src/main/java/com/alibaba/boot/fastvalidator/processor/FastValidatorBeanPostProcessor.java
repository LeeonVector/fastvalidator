package com.alibaba.boot.fastvalidator.processor;

import java.lang.annotation.Annotation;
import javax.validation.Validator;
import org.aopalliance.aop.Advice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
import org.springframework.aop.support.AbstractPointcutAdvisor;
import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
import com.alibaba.fastvalidator.core.spring.FastValidatorMethodInterceptor;

/**
 * fastvalidator bean post processor
 *
 * @author: jasen.zhangj
 * @author jipengfei
 * @date: 16/12/10.
 */
public class FastValidatorBeanPostProcessor extends AbstractAdvisingBeanPostProcessor {

    private static final long serialVersionUID = -6280694151036394983L;
    private static final Logger LOGGER = LoggerFactory.getLogger(FastValidatorBeanPostProcessor.class);

    public FastValidatorBeanPostProcessor(String annotationName, final Validator validator) {
        Class<? extends Annotation> annotation = null;
        try {
            annotation = (Class<? extends Annotation>) Class.forName(annotationName);
        } catch (ClassNotFoundException e) {
            LOGGER.error("can't load class: " + annotationName);
        }

        final Pointcut POINTCUT = new AnnotationMatchingPointcut(annotation, true);

        advisor = new AbstractPointcutAdvisor() {

            @Override
            public Pointcut getPointcut() {
                return POINTCUT;
            }

            @Override
            public Advice getAdvice() {
                return new FastValidatorMethodInterceptor(validator);
            }
        };

    }


}
