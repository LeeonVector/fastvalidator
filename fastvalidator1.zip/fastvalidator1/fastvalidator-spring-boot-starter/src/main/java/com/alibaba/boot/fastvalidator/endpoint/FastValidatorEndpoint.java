package com.alibaba.boot.fastvalidator.endpoint;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author: jasen.zhangj
 * @date: 16/12/10.
 */
public class FastValidatorEndpoint  {

    private static final String NAME = "fastvalidator";

    public FastValidatorEndpoint() {
        //super(NAME);
    }

    public String getName() {
        return NAME;
    }

    public String getVersion() {
        return "1.0.0";
    }

    public List<String> getAuthors() {
        return Arrays.asList("jasen.zhangj");
    }

    public String getDocs() {
        return "http://gitlab.alibaba-inc.com/ae-wsmobile/fastvalidator/wikis/home";
    }

    public String getScm() {
        return "http://gitlab.alibaba-inc.com/ae-wsmobile/fastvalidator";
    }
}
