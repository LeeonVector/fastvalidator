package com.alibaba.boot.fastvalidator.listener;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.GenericApplicationListener;
import org.springframework.core.Ordered;
import org.springframework.core.ResolvableType;

import com.alibaba.fastvalidator.constraints.validator.prompt.FastValidatorLogger;

/**
 * Because {@link org.springframework.boot.logging.LoggingApplicationListener} maybe reset log framework,
 * so this listener will reinitialize Fastvalidtor log after application startup.
 *
 * @author: jasen.zhangj
 * @date: 25/04/2017.
 */
public class FastValidatorLoggerListener implements GenericApplicationListener {


    @Override
    public boolean supportsEventType(ResolvableType eventType) {
        return ApplicationReadyEvent.class.isAssignableFrom(eventType.getRawClass());
    }

    @Override
    public boolean supportsSourceType(Class<?> sourceType) {
        return SpringApplication.class.isAssignableFrom(sourceType);
    }

    @Override
    public void onApplicationEvent(ApplicationEvent event) {
        FastValidatorLogger.reinitialize();
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
