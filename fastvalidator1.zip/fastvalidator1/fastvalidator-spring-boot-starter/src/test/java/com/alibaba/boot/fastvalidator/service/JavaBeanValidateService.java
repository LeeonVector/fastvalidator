package com.alibaba.boot.fastvalidator.service;

import javax.validation.Valid;

import org.springframework.stereotype.Component;

import com.alibaba.boot.fastvalidator.annotation.ValidateService;
import com.alibaba.boot.fastvalidator.bean.JavaBean;
import com.alibaba.boot.fastvalidator.results.Response;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017/3/16.
 */
@Component
@ValidateService
public class JavaBeanValidateService{

    public void validate(@Valid JavaBean bean) {

    }

    public Response returnTypeWithCodeAndeMessage(@Valid JavaBean bean) {
        return null;
    }
}
