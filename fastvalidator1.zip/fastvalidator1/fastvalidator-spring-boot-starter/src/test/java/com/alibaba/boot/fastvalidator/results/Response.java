package com.alibaba.boot.fastvalidator.results;

import com.alibaba.fastvalidator.constraints.FVCode;
import com.alibaba.fastvalidator.constraints.FVMessage;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public class Response {

    @FVCode
    private String errorCode;

    @FVMessage
    private String errorMsg;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
