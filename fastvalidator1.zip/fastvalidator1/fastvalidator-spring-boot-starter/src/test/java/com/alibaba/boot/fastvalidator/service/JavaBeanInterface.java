package com.alibaba.boot.fastvalidator.service;

import javax.validation.Valid;

import com.alibaba.boot.fastvalidator.bean.JavaBean;
import com.alibaba.boot.fastvalidator.results.Response;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-07-15
 */
public interface JavaBeanInterface {

    Response returnTypeWithCodeAndeMessage(@Valid JavaBean bean);
}
