package com.alibaba.boot.fastvalidator.bean;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.alibaba.fastvalidator.constraints.FVLocale;
import com.alibaba.fastvalidator.constraints.If;
import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017/3/13.
 */
@ValidateBean
public class JavaBean {

    @NotNull
    @If(sourceCode = "bean.name.equals(\"Null\")", message = "name_illegal")
    private String  name;

    @NotBlank(message = "messageAndCode_illegal|messageAndCode_illegal")
    private String  messageAndCode;

    @NotBlank(message = "qualityPicksHandbags@home|messageAndCodeByMCMS_illegal")
    private String  messageAndCodeByMCMS;

    @NotBlank(message = "messageAndCodeAndArgs?{name}|messageAndCodeAndArgs_illegal")
    private String  messageAndCodeAndArgs;

    @Min(10)
    @NotNull
    private Integer id;

    // mcms key
    @If(sourceCode = "bean.category != null && bean.category.contains(\"Bag\")", message = "qualityPicksHandbags@home")
    private String  category;

    @FVLocale
    private String  locale;

    public String getMessageAndCodeAndArgs() {
        return messageAndCodeAndArgs;
    }

    public void setMessageAndCodeAndArgs(String messageAndCodeAndArgs) {
        this.messageAndCodeAndArgs = messageAndCodeAndArgs;
    }

    public String getLocale() {
        return locale;
    }

    public String getMessageAndCodeByMCMS() {
        return messageAndCodeByMCMS;
    }

    public void setMessageAndCodeByMCMS(String messageAndCodeByMCMS) {
        this.messageAndCodeByMCMS = messageAndCodeByMCMS;
    }

    public String getMessageAndCode() {
        return messageAndCode;
    }

    public void setMessageAndCode(String messageAndCode) {
        this.messageAndCode = messageAndCode;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
