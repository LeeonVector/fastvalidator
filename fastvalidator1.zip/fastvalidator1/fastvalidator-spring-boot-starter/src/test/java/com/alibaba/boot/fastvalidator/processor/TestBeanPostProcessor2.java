package com.alibaba.boot.fastvalidator.processor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-07-15
 */
@Configuration
@Component
public class TestBeanPostProcessor2 extends BeanNameAutoProxyCreator {

    private static final long serialVersionUID = 1198240387666431920L;

    public TestBeanPostProcessor2() {
        setBeanNames("javaBeanInter*");
        setInterceptorNames("testAdvice");
        setOrder(Ordered.HIGHEST_PRECEDENCE + 1);
        setProxyTargetClass(true);
    }

    @Component(value = "testAdvice")
    static class TestAdvice implements MethodInterceptor {

        public TestAdvice(){
            System.out.println("*************");
        }

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            System.out.println("reaches here");
            return invocation.proceed();

        }
    }
}
