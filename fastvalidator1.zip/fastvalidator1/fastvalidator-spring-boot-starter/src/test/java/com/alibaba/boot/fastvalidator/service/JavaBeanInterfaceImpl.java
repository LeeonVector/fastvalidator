package com.alibaba.boot.fastvalidator.service;

import org.springframework.stereotype.Component;
import com.alibaba.boot.fastvalidator.annotation.ValidateService;
import com.alibaba.boot.fastvalidator.bean.JavaBean;
import com.alibaba.boot.fastvalidator.results.Response;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-07-15
 */
@Component
@ValidateService
public class JavaBeanInterfaceImpl implements JavaBeanInterface {

    @Override
    public Response returnTypeWithCodeAndeMessage(JavaBean bean) {
        return null;
    }
}
