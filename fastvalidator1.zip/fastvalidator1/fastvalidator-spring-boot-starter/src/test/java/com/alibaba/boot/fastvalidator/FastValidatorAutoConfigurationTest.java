package com.alibaba.boot.fastvalidator;

import junit.framework.TestCase;
import java.util.Locale;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.alibaba.boot.fastvalidator.bean.JavaBean;
import com.alibaba.boot.fastvalidator.i18n.helper.FastValidatorLocaleContextHolder;
import com.alibaba.boot.fastvalidator.results.Response;
import com.alibaba.boot.fastvalidator.service.JavaBeanInterface;
import com.alibaba.boot.fastvalidator.service.JavaBeanValidateService;
import com.alibaba.fastvalidator.constraints.exception.FastValidatorException;

/**
 * Test for {@link FastValidatorAutoConfiguration}
 *
 * @author: jasen.zhangj
 * @date: 2017/3/10.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(FastValidatorApplication.class)
public class FastValidatorAutoConfigurationTest extends TestCase {

    @Autowired
    private Validator   validator;

    @Autowired
    private JavaBeanValidateService javaBeanValidateService;

    @Autowired
    private JavaBeanInterface javaBeanInterface;

    @Test
    public void fastValidator() throws Exception {
        assertTrue(validator != null);
    }

    @Test(expected = FastValidatorException.class)
    public void testValidate() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setId(1);
        javaBeanValidateService.validate(javaBean);
    }

    @Test
    public void testReturnTypeWithCodeAndeMessage() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setLocale(Locale.CHINA.toString());
        javaBean.setMessageAndCode(null);

        Response response = javaBeanValidateService.returnTypeWithCodeAndeMessage(javaBean);
        assertTrue(response.getErrorCode().equals("messageAndCode_illegal"));
        assertTrue(response.getErrorMsg().equals("messageAndCode 不能为空"));
    }

    @Test
    public void testReturnTypeWithCodeAndeMessageByInterface() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setLocale(Locale.CHINA.toString());
        javaBean.setMessageAndCode(null);

        Response response = javaBeanInterface.returnTypeWithCodeAndeMessage(javaBean);
        assertTrue(response.getErrorCode().equals("messageAndCode_illegal"));
        assertTrue(response.getErrorMsg().equals("messageAndCode 不能为空"));
    }

    @Test
    public void testReturnTypeWithCodeAndeMessageByMCMS() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setLocale(Locale.US.toString());
        javaBean.setMessageAndCodeByMCMS(null);

        Response response = javaBeanValidateService.returnTypeWithCodeAndeMessage(javaBean);
        assertTrue(response.getErrorCode().equals("messageAndCodeByMCMS_illegal"));
        assertTrue(response.getErrorMsg().equals("Shoes & Bags"));
    }

    @Test
    public void testReturnTypeWithCodeAndMessageWithMessageArgs(){
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setLocale(Locale.US.toString());
        javaBean.setMessageAndCodeAndArgs(null);
        javaBean.setName("success");

        Response response = javaBeanValidateService.returnTypeWithCodeAndeMessage(javaBean);
        assertTrue(response.getErrorCode().equals("messageAndCodeAndArgs_illegal"));
        assertTrue(response.getErrorMsg().equals("message and code test success"));

        javaBean.setLocale(Locale.CHINA.toString());
        response = javaBeanValidateService.returnTypeWithCodeAndeMessage(javaBean);
        assertTrue(response.getErrorCode().equals("messageAndCodeAndArgs_illegal"));
        assertTrue(response.getErrorMsg().equals("message和code测试success"));
    }

    @Test
    public void testValidateBeanByCustomMessageInterpolator() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setName("Null");

        Set<ConstraintViolation<JavaBean>> set = validator.validate(javaBean);
        assertTrue(set.size() == 1);

        ConstraintViolation<JavaBean> constraintViolation = set.iterator().next();
        constraintViolation.getMessage().equals("name may not be Null");
    }

    @Test
    public void testValidateBeanByCustomMessageInterpolatorWithSpecialLocale() {
        FastValidatorLocaleContextHolder.setLocale(Locale.CHINA);
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setName("Null");

        Set<ConstraintViolation<JavaBean>> set = validator.validate(javaBean);
        assertTrue(set.size() == 1);

        ConstraintViolation<JavaBean> constraintViolation = set.iterator().next();
        constraintViolation.getMessage().equals("name 不能为 Null");
        FastValidatorLocaleContextHolder.setLocale(null);
    }

    @Test
    public void testValidateBeanByCustomMessageInterpolatorByMCMS() {
        JavaBean javaBean = getNormalValidationBean();
        javaBean.setCategory("big Bag");

        Set<ConstraintViolation<JavaBean>> set = validator.validate(javaBean);
        assertTrue(set.size() == 1);

        ConstraintViolation<JavaBean> constraintViolation = set.iterator().next();
        constraintViolation.getMessage().equals("Shoes & Bags");
    }

    protected JavaBean getNormalValidationBean() {
        JavaBean javaBean = new JavaBean();
        javaBean.setName("jasen.zhangj");
        javaBean.setId(12);
        javaBean.setCategory("big case");
        javaBean.setMessageAndCode("test");
        javaBean.setMessageAndCodeByMCMS("MessageAndCodeByMCMS");
        javaBean.setMessageAndCodeAndArgs("message and message arguments");

        return javaBean;
    }
}
