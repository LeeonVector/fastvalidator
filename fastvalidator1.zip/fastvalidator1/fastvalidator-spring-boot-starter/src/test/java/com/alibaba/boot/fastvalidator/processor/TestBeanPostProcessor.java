package com.alibaba.boot.fastvalidator.processor;

import org.aopalliance.aop.Advice;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.Pointcut;
import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
import org.springframework.aop.support.AbstractPointcutAdvisor;
import org.springframework.aop.support.ComposablePointcut;
import org.springframework.aop.support.annotation.AnnotationClassFilter;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.alibaba.boot.fastvalidator.annotation.ValidateService;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-07-15
 */
@Component
public class TestBeanPostProcessor extends AbstractAdvisingBeanPostProcessor {

    private static final long serialVersionUID = 1198240387666431920L;

    public TestBeanPostProcessor() {
        advisor = new AbstractPointcutAdvisor() {

            @Override
            public Pointcut getPointcut() {
                ComposablePointcut composablePointcut = new ComposablePointcut(new AnnotationClassFilter(ValidateService.class));
                return composablePointcut;
            }

            @Override
            public Advice getAdvice() {
                return new TestAdvice();
            }
        };

        setOrder(Ordered.HIGHEST_PRECEDENCE);
        setProxyTargetClass(true);
    }

    static class TestAdvice implements MethodInterceptor {

        @Override
        public Object invoke(MethodInvocation invocation) throws Throwable {
            System.out.println("reaches here");
            return invocation.proceed();

        }
    }
}
