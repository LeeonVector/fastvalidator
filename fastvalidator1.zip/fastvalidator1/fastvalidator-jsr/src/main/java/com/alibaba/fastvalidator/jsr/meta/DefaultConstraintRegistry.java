package com.alibaba.fastvalidator.jsr.meta;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.validator.constraints.EAN;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.Mod10Check;
import org.hibernate.validator.constraints.Mod11Check;
import org.hibernate.validator.constraints.ModCheck;
import org.hibernate.validator.constraints.ParameterScriptAssert;
import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;

import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.collection.EachEAN;
import com.alibaba.fastvalidator.constraints.collection.EachParameterScriptAssert;
import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.meta.constraints.Constraint;
import com.alibaba.fastvalidator.meta.constraints.ConstraintRegistry;

/**
 * Default constrains registries
 *
 * @author: jasen.zhangj
 * @date: 2017/2/23.
 */
public class DefaultConstraintRegistry implements ConstraintRegistry {

    private static final ConstraintRegistry            CONSTRAINT_REGISTRY              = new DefaultConstraintRegistry();

    private static final FastValidatorConstraintHelper FAST_VALIDATOR_CONSTRAINT_HELPER = FastValidatorConstraintHelper.getInstance();

    private static final Filter                        DEFAULT_FILTER                   = new DefaultFilter();

    private DefaultConstraintRegistry() {

    }

    public static ConstraintRegistry getInstance() {
        return CONSTRAINT_REGISTRY;
    }

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     * 
     * @return all constraint information in constraint registry through {@link Filter}.
     */
    public Set<Constraint> getAllConstraints(Filter filter) {
        Set<Class<? extends Annotation>> constraints = FAST_VALIDATOR_CONSTRAINT_HELPER.getAllConstraintAnnotation();

        Set<Constraint> constrains = new TreeSet<>();
        for (Class<? extends Annotation> constraint : constraints) {
            Constraint constraintInfo = new Constraint();
            constraintInfo.setName(constraint.getSimpleName());
            constraintInfo.setType(constraint);

            Map<String, Type> attributeMap = AnnotationUtils.readAllAttributes(constraint);
            constraintInfo.setConstraintPropertyTypes(attributeMap);

            if (filter != null && filter.isFilter(constraintInfo)) {
                continue;
            }

            constrains.add(constraintInfo);
        }

        return constrains;
    }

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this result set of this method.
     * </pre>
     *
     * @return all constraint in constraint registry.
     */
    public Set<Constraint> getAllConstraints() {
        return getAllConstraints(DEFAULT_FILTER);
    }

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     *
     * @param filter constraint filter
     * @return all constraint in constraint registry without 'message', 'payload' and 'groups' attributes.
     */
    public Set<Constraint> getAllConstraintsWithoutDefaultAttribute(Filter filter) {
        Set<Constraint> constraints = getAllConstraints(filter);
        for (Constraint constraint : constraints) {
            constraint.getConstraintPropertyTypes().remove(FastValidatorConstraintHelper.GROUPS);
            constraint.getConstraintPropertyTypes().remove(FastValidatorConstraintHelper.MESSAGE);
            constraint.getConstraintPropertyTypes().remove(FastValidatorConstraintHelper.PAYLOAD);
        }

        return constraints;
    }

    /***
     * <pre>
     * Note: if you needn't register any constraint in {@link ConstraintRegistry}, you'd better cache this set of this method.
     * </pre>
     *
     * @return all constraint elements in constraint registry without 'message', 'payload' and 'groups' attributes.
     */
    public Set<Constraint> getAllConstraintsWithoutDefaultAttribute() {
        return getAllConstraintsWithoutDefaultAttribute(DEFAULT_FILTER);
    }

    /***
     * Put constraints and constraint's validator in constraint registry.
     *
     * @param annotationTypes constraint annotation
     */
    public void putConstraints(Class<? extends Annotation>... annotationTypes) {
        for (Class<? extends Annotation> annotationType : annotationTypes) {
            FAST_VALIDATOR_CONSTRAINT_HELPER.getAllValidatorClasses(annotationType);
        }
    }

    private static class DefaultFilter implements Filter {

        private static final Class[] EXCLUDE_CONSTRAINTS_ARRAY = new Class[] { CNPJ.class, CPF.class, EAN.class,
                                                                               EachEAN.class,
                                                                               EachParameterScriptAssert.class,
                                                                               LuhnCheck.class, Mod10Check.class,
                                                                               Mod11Check.class, ModCheck.class,
                                                                               ParameterScriptAssert.class,
                                                                               ValidateBean.class

        };

        private static List<Class>   EXCLUDE_CONSTRAINTS       = Arrays.asList(EXCLUDE_CONSTRAINTS_ARRAY);

        @Override
        public boolean isFilter(Constraint constraint) {
            return EXCLUDE_CONSTRAINTS.contains(constraint.getType());
        }
    }
}
