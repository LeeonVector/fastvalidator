/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.    
 */
package com.alibaba.fastvalidator.jsr;

import javax.validation.Configuration;
import javax.validation.ValidationException;
import javax.validation.ValidatorFactory;
import javax.validation.spi.BootstrapState;
import javax.validation.spi.ConfigurationState;
import javax.validation.spi.ValidationProvider;

import com.alibaba.fastvalidator.jsr.util.Reflection;


/**
 * Description: Implementation of {@link ValidationProvider} for jsr
 * implementation of the apache-validation framework.
 * <p/>
 * <br/>
 */
public class FastValidatorValidationProvider implements ValidationProvider<FastValidatorConfiguration> {


    /**
     * {@inheritDoc}
     */
    @Override
    public FastValidatorConfiguration createSpecializedConfiguration(BootstrapState state) {
        return new ConfigurationImpl(state, this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Configuration<?> createGenericConfiguration(BootstrapState state) {
        return new ConfigurationImpl(state, null);
    }

    /**
     * {@inheritDoc}
     * 
     * @throws ValidationException
     *             if the ValidatorFactory cannot be built
     */
    @Override
    public ValidatorFactory buildValidatorFactory(final ConfigurationState configuration) {
        final Class<? extends ValidatorFactory> validatorFactoryClass;
        try {
            final String validatorFactoryClassname =
                configuration.getProperties().get(FastValidatorConfiguration.Properties.VALIDATOR_FACTORY_CLASSNAME);

            if (validatorFactoryClassname == null) {
                validatorFactoryClass = FastValidatorFactory.class;
            } else {
                validatorFactoryClass =
                    Reflection.toClass(validatorFactoryClassname).asSubclass(ValidatorFactory.class);
            }
        } catch (ValidationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ValidationException("error building ValidatorFactory", ex);
        }

        try {
            return validatorFactoryClass.getConstructor(ConfigurationState.class).newInstance(configuration);
        } catch (final Exception ex) {
            throw new ValidationException("Cannot instantiate : " + validatorFactoryClass, ex);
        }
    }

}
