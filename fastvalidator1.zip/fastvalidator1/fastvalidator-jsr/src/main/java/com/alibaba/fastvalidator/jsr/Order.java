package com.alibaba.fastvalidator.jsr;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *  Defines the sort order for an annotated type.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface Order {

    /**
     * The order value. The smaller the number, the higher the priority.
     */
    int value() default Integer.MAX_VALUE;
}
