/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.alibaba.fastvalidator.jsr;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintDefinitionException;
import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.Payload;
import javax.validation.ValidationException;
import javax.validation.metadata.ConstraintDescriptor;
import com.alibaba.fastvalidator.jsr.bean.access.AccessStrategy;
import com.alibaba.fastvalidator.jsr.bean.model.Validation;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationContext;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationListener;
import com.alibaba.fastvalidator.jsr.context.ConstraintValidatorContextImpl;
import com.alibaba.fastvalidator.jsr.context.GroupValidationContext;
import com.alibaba.fastvalidator.jsr.util.NodeImpl;
import com.alibaba.fastvalidator.jsr.util.PathImpl;

/**
 * Description: Adapter between Constraint (JSR303) and Validation (Core)<br/>
 * this instance is immutable!<br/>
 */
public class ConstraintValidation<T extends Annotation> extends  AbstractConstraintValidation<T> implements Validation, ConstraintDescriptor<T> {
    private final AccessStrategy access;
    private final boolean reportFromComposite;
    private final Map<String, Object> attributes;
    private T annotation; // for metadata request API
    private volatile ConstraintValidator<T, ?> validator;

    private Set<ConstraintValidation<?>> composedConstraints;

    private boolean validated = false;

    /**
     * the owner is the type where the validation comes from. it is used to
     * support implicit grouping.
     */
    private final Class<?> owner;
    private Set<Class<?>> groups;
    private Set<Class<? extends Payload>> payload;
    private Class<? extends ConstraintValidator<T, ?>>[] validatorClasses;
    private ConstraintTarget validationAppliesTo = null;

    public ConstraintValidation(Class<? extends ConstraintValidator<T, ?>>[] validatorClasses, T annotation,
        Class<?> owner, AccessStrategy access, boolean reportFromComposite, ConstraintTarget target) {
        this.attributes = new HashMap<String, Object>();
        this.validatorClasses = validatorClasses != null ? validatorClasses.clone() : null;
        this.annotation = annotation;
        this.owner = owner;
        this.access = access;
        this.reportFromComposite = reportFromComposite;
        this.validationAppliesTo = target;
    }

    public void setGroups(final Set<Class<?>> groups) {
        this.groups = groups;
        ConstraintAnnotationAttributes.GROUPS.put(attributes, groups.toArray(new Class<?>[groups.size()]));
    }

    public void setGroups(final Class<?>[] groups) {
        this.groups = new HashSet<Class<?>>();
        Collections.addAll(this.groups, groups);
        ConstraintAnnotationAttributes.GROUPS.put(attributes, groups);
    }

    public void setPayload(Set<Class<? extends Payload>> payload) {
        this.payload = payload;
        ConstraintAnnotationAttributes.PAYLOAD.put(attributes, payload.toArray(new Class[payload.size()]));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isReportAsSingleViolation() {
        return reportFromComposite;
    }

    /**
     * Add a composing constraint.
     *
     * @param aConstraintValidation to add
     */
    public void addComposed(ConstraintValidation<?> aConstraintValidation) {
        if (composedConstraints == null) {
            composedConstraints = new HashSet<ConstraintValidation<?>>();
        }
        composedConstraints.add(aConstraintValidation);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <L extends ValidationListener> void validate(ValidationContext<L> context) {
        validateGroupContext((GroupValidationContext<?>) context);
    }

    /**
     * Validate a {@link GroupValidationContext}.
     *
     * @param context root
     */
    public void validateGroupContext(final GroupValidationContext<?> context) {
        if (validator == null) {
            synchronized (this) {
                if (validator == null) {
                    try {
                        validator = getConstraintValidator(context.getConstraintValidatorFactory(), annotation,
                            validatorClasses, owner, access);
                        if (validator != null) {
                            validator.initialize(annotation);
                        }
                    } catch (final RuntimeException re) {
                        if (ValidationException.class.isInstance(re)) {
                            throw re;
                        }
                        throw new ConstraintDefinitionException(re);
                    }
                }
            }
        }

        context.setConstraintValidation(this);
        /**
         * execute unless the given validation constraint has already been
         * processed during this validation routine (as part of a previous group
         * match)
         */
        if (!isMemberOf(context.getCurrentGroup().getGroup())) {
            return; // do not validate in the current group
        }
        if (context.getCurrentOwner() != null && !this.owner.equals(context.getCurrentOwner())) {
            return;
        }
        if (validator != null && !context.collectValidated(validator))
            return; // already done

        if (context.getMetaProperty() != null && !isReachable(context)) {
            return;
        }

        // process composed constraints
        if (isReportAsSingleViolation()) {
            final ConstraintValidationListener<?> listener = context.getListener();
            listener.beginReportAsSingle();

            boolean failed = listener.hasViolations();
            try {
                // stop validating when already failed and
                // ReportAsSingleInvalidConstraint = true ?
                for (Iterator<ConstraintValidation<?>> composed = getComposingValidations().iterator(); !failed
                    && composed.hasNext();) {
                    composed.next().validate(context);
                    failed = listener.hasViolations();
                }
            } finally {
                listener.endReportAsSingle();
                // Restore current constraint validation
                context.setConstraintValidation(this);
            }

            if (failed) {
                // TODO RSt - how should the composed constraint error report look like?
                addErrors(context, new ConstraintValidatorContextImpl(context, this)); // add defaultErrorMessage only
                return;
            }
        } else {
            for (ConstraintValidation<?> composed : getComposingValidations()) {
                composed.validate(context);
            }

            // Restore current constraint validation
            context.setConstraintValidation(this);
        }

        if (validator != null) {
            @SuppressWarnings("unchecked")
            final ConstraintValidator<T, Object> objectValidator = (ConstraintValidator<T, Object>) validator;
            final ConstraintValidatorContextImpl jsrContext = new ConstraintValidatorContextImpl(context, this);
            if (!objectValidator.isValid(context.getValidatedValue(), jsrContext)) {
                addErrors(context, jsrContext);
            }
        }
    }



    /**
     * Initialize the validator (if not <code>null</code>) with the stored
     * annotation.
     */
    public void initialize() {
        if (null != validator) {
            try {
                validator.initialize(annotation);
            } catch (RuntimeException e) {
                // Either a "legit" problem initializing the validator or a
                // ClassCastException if the validator associated annotation is
                // not a supertype of the validated annotation.
                throw new ConstraintDefinitionException(
                    "Incorrect validator [" + validator.getClass().getCanonicalName() + "] for annotation "
                        + annotation.annotationType().getCanonicalName(),
                    e);
            }
        }
    }

    private boolean isReachable(GroupValidationContext<?> context) {
        final PathImpl path = context.getPropertyPath();
        final NodeImpl node = path.getLeafNode();
        PathImpl beanPath = path.getPathWithoutLeafNode();
        if (beanPath == null) {
            beanPath = PathImpl.create();
        }
        try {
            if (!context.getTraversableResolver().isReachable(context.getBean(), node,
                context.getRootMetaBean().getBeanClass(), beanPath, access.getElementType())) {
                return false;
            }
        } catch (RuntimeException e) {
            throw new ValidationException("Error in TraversableResolver.isReachable() for " + context.getBean(), e);
        }
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return "ConstraintValidation{" + validator + '}';
    }

    /**
     * Get the message template used by this constraint.
     *
     * @return String
     */
    @Override
    public String getMessageTemplate() {
        return ConstraintAnnotationAttributes.MESSAGE.get(attributes);
    }

    public ConstraintValidator<T, ?> getValidator() {
        return validator;
    }

    protected boolean isMemberOf(Class<?> reqGroup) {
        return groups.contains(reqGroup);
    }

    public Class<?> getOwner() {
        return owner;
    }

    @Override
    public T getAnnotation() {
        return annotation;
    }

    @Override
    public AccessStrategy getAccess() {
        return access;
    }

    public void setAnnotation(T annotation) {
        this.annotation = annotation;
    }

    // ///////////////////////// ConstraintDescriptor implementation

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> getAttributes() {
        return attributes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @SuppressWarnings("unchecked")
    public Set<ConstraintDescriptor<?>> getComposingConstraints() {
        return composedConstraints == null ? Collections.EMPTY_SET : new HashSet<>(composedConstraints);
    }

    /**
     * Get the composing {@link ConstraintValidation} objects. This is
     * effectively an implementation-specific analogue to
     * {@link #getComposingConstraints()}.
     *
     * @return {@link Set} of {@link ConstraintValidation}
     */
    public Set<ConstraintValidation<?>> getComposingValidations() {
        return composedConstraints == null ? Collections.<ConstraintValidation<?>> emptySet() : composedConstraints;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<Class<?>> getGroups() {
        return groups;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<Class<? extends Payload>> getPayload() {
        return payload;
    }

    @Override
    public ConstraintTarget getValidationAppliesTo() {
        return validationAppliesTo;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Class<? extends ConstraintValidator<T, ?>>> getConstraintValidatorClasses() {
        return validatorClasses == null ? Collections.<Class<? extends ConstraintValidator<T, ?>>> emptyList()
            : Arrays.asList(validatorClasses);
    }

    public void setValidationAppliesTo(final ConstraintTarget validationAppliesTo) {
        this.validationAppliesTo = validationAppliesTo;
    }

    public boolean isValidated() {
        return validated;
    }

    public void setValidated(final boolean validated) {
        this.validated = validated;
    }
}
