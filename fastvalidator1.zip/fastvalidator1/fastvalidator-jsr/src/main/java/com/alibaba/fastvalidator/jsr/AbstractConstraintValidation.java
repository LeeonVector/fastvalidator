package com.alibaba.fastvalidator.jsr;

import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintDefinitionException;
import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.Payload;
import javax.validation.UnexpectedTypeException;
import javax.validation.ValidationException;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;
import javax.validation.metadata.ConstraintDescriptor;

import com.alibaba.fastvalidator.constraints.utils.ArrayUtils;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.jsr.bean.access.AccessStrategy;
import com.alibaba.fastvalidator.jsr.bean.access.ParameterAccess;
import com.alibaba.fastvalidator.jsr.bean.access.ParametersAccess;
import com.alibaba.fastvalidator.jsr.bean.model.Validation;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationContext;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationListener;
import com.alibaba.fastvalidator.jsr.context.ConstraintValidatorContextImpl;
import com.alibaba.fastvalidator.jsr.context.GroupValidationContext;
import com.alibaba.fastvalidator.jsr.descriptor.ConstraintDescriptorImpl;
import com.alibaba.fastvalidator.jsr.util.Reflection;
import com.alibaba.fastvalidator.jsr.util.TypeUtils;

/**
 * Abstract constraint validation
 *
 * @author: jasen.zhangj
 * @date: 2017/2/27.
 */
public abstract class AbstractConstraintValidation<T extends Annotation> implements Validation, ConstraintDescriptor<T> {

     public abstract AccessStrategy getAccess();

    /**
     * Return a {@link java.io.Serializable} {@link ConstraintDescriptor} capturing a
     * snapshot of current state.
     *
     * @return {@link ConstraintDescriptor}
     */
    public ConstraintDescriptor<T> asSerializableDescriptor() {
        return new ConstraintDescriptorImpl<T>(this);
    }

    protected void addErrors(GroupValidationContext<?> context, ConstraintValidatorContextImpl jsrContext) {
        for (ValidationListener.Error each : jsrContext.getErrorMessages()) {
            context.getListener().addError(each, context);
        }
    }

    protected <A extends Annotation> ConstraintValidator<A, ? super T> getConstraintValidator(ConstraintValidatorFactory factory,
                                                                                              A annotation,
                                                                                              Class<? extends ConstraintValidator<A, ?>>[] constraintClasses,
                                                                                              Class<?> owner,
                                                                                              AccessStrategy access) {
        if (ArrayUtils.isNotEmpty(constraintClasses)) {
            final Type type = determineTargetedType(owner, access);

            /**
             * spec says in chapter 3.5.3.: The ConstraintValidator chosen to validateByMeta a declared type T is the one
             * where the type supported by the ConstraintValidator is a supertype of T and where there is no other
             * ConstraintValidator whose supported type is a supertype of T and not a supertype of the chosen
             * ConstraintValidator supported type.
             */
            final Map<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>> validatorTypes = getValidatorsTypes(constraintClasses);
            reduceTarget(validatorTypes, access);

            final List<Type> assignableTypes = new ArrayList<Type>(constraintClasses.length);
            fillAssignableTypes(type, validatorTypes.keySet(), assignableTypes);
            reduceAssignableTypes(assignableTypes);
            checkOneType(assignableTypes, type, owner, annotation, access);

            if ((type.equals(Object.class) || type.equals(Object[].class)) && validatorTypes.containsKey(Object.class)
                && validatorTypes.containsKey(Object[].class)) {
                throw new ConstraintDefinitionException("Only a validator for Object or Object[] should be provided for cross-parameter validators");
            }

            final Collection<Class<? extends ConstraintValidator<A, ?>>> key = validatorTypes.get(assignableTypes.get(0));
            if (key.size() > 1) {
                final String message = "Factory returned " + key.size() + " validators";
                if (ParametersAccess.class.isInstance(access)) { // cross parameter
                    throw new ConstraintDefinitionException(message);
                }
                throw new UnexpectedTypeException(message);
            }

            @SuppressWarnings("unchecked")
            final ConstraintValidator<A, ? super T> validator = (ConstraintValidator<A, ? super T>) factory.getInstance(key.iterator().next());
            if (validator == null) {
                throw new ValidationException("Factory returned null validator for: " + key);

            }
            return validator;
            // NOTE: validator initialization deferred until append phase
        }
        return null;
    }

    protected <A extends Annotation> void reduceTarget(final Map<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>> validator,
                                                       final AccessStrategy access) {
        for (final Map.Entry<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>> entry : validator.entrySet()) {
            final Collection<Class<? extends ConstraintValidator<A, ?>>> validators = entry.getValue();
            final Iterator<Class<? extends ConstraintValidator<A, ?>>> it = validators.iterator();
            while (it.hasNext()) {
                final Type v = it.next();
                if (!Class.class.isInstance(v)) {
                    continue; // TODO: handle this case
                }

                final Class<?> clazz = Class.class.cast(v);
                final SupportedValidationTarget target = clazz.getAnnotation(SupportedValidationTarget.class);
                if (target != null) {
                    final Collection<ValidationTarget> targets = Arrays.asList(target.value());
                    final boolean isParameter = ParameterAccess.class.isInstance(access)
                                                || ParametersAccess.class.isInstance(access);
                    if ((isParameter && !targets.contains(ValidationTarget.PARAMETERS))
                        || (!isParameter && !targets.contains(ValidationTarget.ANNOTATED_ELEMENT))) {
                        it.remove();
                    }
                }
            }
            if (validators.isEmpty()) {
                validator.remove(entry.getKey());
            }
        }
    }

    protected static void checkOneType(List<Type> types, Type targetType, Class<?> owner, Annotation anno,
                                       AccessStrategy access) {

        if (types.isEmpty()) {
            final String message = "No validator could be found for type " + stringForType(targetType) + ". See: @"
                                   + anno.annotationType().getSimpleName() + " at " + stringForLocation(owner, access);
            if (Object[].class.equals(targetType)) { // cross parameter
                throw new ConstraintDefinitionException(message);
            }
            throw new UnexpectedTypeException(message);
        }
        if (types.size() > 1) {
            throw new UnexpectedTypeException(String.format("Ambiguous validators for type %s. See: @%s at %s. Validators are: %s",
                                                            stringForType(targetType),
                                                            anno.annotationType().getSimpleName(),
                                                            stringForLocation(owner, access),
                                                            StringUtils.join(types, ", ")));
        }
    }

    protected static String stringForType(Type clazz) {
        if (clazz instanceof Class<?>) {
            return ((Class<?>) clazz).isArray() ? ((Class<?>) clazz).getComponentType().getName()
                                                  + "[]" : ((Class<?>) clazz).getName();
        }
        return clazz.toString();
    }

    protected static String stringForLocation(Class<?> owner, AccessStrategy access) {
        return access == null ? owner.getName() : access.toString();
    }

    protected static void fillAssignableTypes(Type type, Set<Type> validatorsTypes, List<Type> suitableTypes) {
        for (final Type validatorType : validatorsTypes) {
            if (TypeUtils.isAssignable(type, validatorType) && !suitableTypes.contains(validatorType)) {
                suitableTypes.add(validatorType);
            }
        }
    }

    /**
     * Tries to reduce all assignable classes down to a single class.
     *
     * @param assignableTypes The set of all classes which are assignable to the class of the value to be validated and
     * which are handled by at least one of the validators for the specified constraint.
     */
    protected static void reduceAssignableTypes(List<Type> assignableTypes) {
        if (assignableTypes.size() <= 1) {
            return; // no need to reduce
        }
        boolean removed = false;
        do {
            final Type type = assignableTypes.get(0);
            for (int i = 1; i < assignableTypes.size(); i++) {
                final Type nextType = assignableTypes.get(i);
                if (TypeUtils.isAssignable(nextType, type)) {
                    assignableTypes.remove(0);
                    i--;
                    removed = true;
                } else if (TypeUtils.isAssignable(type, nextType)) {
                    assignableTypes.remove(i--);
                    removed = true;
                }
            }
        } while (removed && assignableTypes.size() > 1);
    }

    protected static <A extends Annotation> Map<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>> getValidatorsTypes(Class<? extends ConstraintValidator<A, ?>>[] constraintValidatorClasses) {
        final Map<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>> validatorsTypes = new HashMap<Type, Collection<Class<? extends ConstraintValidator<A, ?>>>>();
        for (Class<? extends ConstraintValidator<A, ?>> validatorType : constraintValidatorClasses) {
            Type validatedType = TypeUtils.getTypeArguments(validatorType,
                                                            ConstraintValidator.class).get(ConstraintValidator.class.getTypeParameters()[1]);
            if (validatedType == null) {
                throw new ValidationException(String.format("Could not detect validated type for %s", validatorType));
            }
            if (validatedType instanceof GenericArrayType) {
                final Type componentType = TypeUtils.getArrayComponentType(validatedType);
                if (componentType instanceof Class<?>) {
                    validatedType = Array.newInstance((Class<?>) componentType, 0).getClass();
                }
            }
            if (!validatorsTypes.containsKey(validatedType)) {
                validatorsTypes.put(validatedType, new ArrayList<Class<? extends ConstraintValidator<A, ?>>>());
            }
            validatorsTypes.get(validatedType).add(validatorType);
        }
        return validatorsTypes;
    }

    /**
     * implements spec chapter 3.5.3. ConstraintValidator resolution algorithm.
     */
    protected static Type determineTargetedType(Class<?> owner, AccessStrategy access) {
        // if the constraint declaration is hosted on a class or an interface,
        // the targeted type is the class or the interface.
        if (access == null) {
            return owner;
        }
        final Type type = access.getJavaType();
        if (type == null) {
            return Object.class;
        }
        return type instanceof Class<?> ? Reflection.primitiveToWrapper((Class<?>) type) : type;
    }

    @Override
    public <T extends ValidationListener> void validate(ValidationContext<T> context) {

    }

    @Override
    public T getAnnotation() {
        return null;
    }

    @Override
    public String getMessageTemplate() {
        return null;
    }

    @Override
    public Set<Class<?>> getGroups() {
        return null;
    }

    @Override
    public Set<Class<? extends Payload>> getPayload() {
        return null;
    }

    @Override
    public ConstraintTarget getValidationAppliesTo() {
        return null;
    }

    @Override
    public List<Class<? extends ConstraintValidator<T, ?>>> getConstraintValidatorClasses() {
        return null;
    }

    @Override
    public Map<String, Object> getAttributes() {
        return null;
    }

    @Override
    public Set<ConstraintDescriptor<?>> getComposingConstraints() {
        return null;
    }

    @Override
    public boolean isReportAsSingleViolation() {
        return false;
    }
}
