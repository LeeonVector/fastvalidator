package com.alibaba.fastvalidator.jsr.meta;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.Payload;
import javax.validation.metadata.ConstraintDescriptor;

import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.jsr.AbstractConstraintValidation;
import com.alibaba.fastvalidator.jsr.ConstraintValidationListener;
import com.alibaba.fastvalidator.jsr.bean.access.AccessStrategy;
import com.alibaba.fastvalidator.jsr.bean.model.Validation;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationContext;
import com.alibaba.fastvalidator.jsr.bean.model.ValidationListener;
import com.alibaba.fastvalidator.jsr.context.ConstraintValidatorContextImpl;
import com.alibaba.fastvalidator.jsr.context.GroupValidationContext;

/**
 * Constraint validation for element
 *
 * @author: jasen.zhangj
 * @date: 2017/2/24.
 */
public class ValidationMetaValidation<T extends Annotation> extends AbstractConstraintValidation<T> implements Validation, ConstraintDescriptor<T> {

    public static final FastValidatorConstraintHelper        FAST_VALIDATOR_CONSTRAINT_HELPER = FastValidatorConstraintHelper.getInstance();
    private List<Class<? extends ConstraintValidator<T, ?>>> validatorClasses;

    private Set<ValidationMetaValidation<?>>                 composedConstraints;

    private T                                                annotation;
    private Map<String, Object>                              allAttributes;
    private Class<?>                                         owner;
    private AccessStrategy                                   access;
    private Class<? extends ConstraintValidator<T, ?>>[]     validatorClassArray;

    public ValidationMetaValidation(T annotation, Class<?> owner, AccessStrategy access) {
        this.annotation = annotation;
        this.owner = owner;
        this.access = access;

        allAttributes = AnnotationUtils.readAllAttributesAndOverrideAttribute(annotation);
        validatorClasses = FAST_VALIDATOR_CONSTRAINT_HELPER.getAllValidatorClasses((Class<T>) annotation.annotationType());
        validatorClassArray = validatorClasses.toArray(new Class[validatorClasses.size()]);

        composedConstraints = new HashSet<>();
        for (final Annotation composedAnnotation : annotation.annotationType().getDeclaredAnnotations()) {
            final Class<? extends Annotation> composeType = composedAnnotation.annotationType();
            if (FAST_VALIDATOR_CONSTRAINT_HELPER.isNonCompostingConstraintAnnotation(composeType)) {
                continue;
            }

            List<AnnotationUtils.OverrideAttribute> overrideAttributes = (List<AnnotationUtils.OverrideAttribute>) allAttributes.get(AnnotationUtils.OVERRIDE_ATTRIBUTES);
            if (overrideAttributes != null && overrideAttributes.size() > 0) {
                for (AnnotationUtils.OverrideAttribute overrideAttribute : overrideAttributes) {
                    if (overrideAttribute.getOverrideConstraint() == composeType) {
                        composedConstraints.add(new ValidationMetaValidation(composedAnnotation, overrideAttribute,
                                                                             owner, access));
                    }
                }
            } else {
                composedConstraints.add(new ValidationMetaValidation(composedAnnotation, owner, access));
            }
        }
    }

    protected ValidationMetaValidation(T annotation, AnnotationUtils.OverrideAttribute overrideAttribute,
                                       Class<?> owner, AccessStrategy access) {
        this(annotation, owner, access);
        this.allAttributes.put(overrideAttribute.getOverrideAttributeName(), overrideAttribute.getValue());
        this.annotation = (T) AnnotationUtils.createAnnotation(annotation, allAttributes);
    }

    @Override
    public <T extends ValidationListener> void validate(ValidationContext<T> context) {
        validateGroupContext((GroupValidationContext) context);
    }

    /**
     * Validate a {@link GroupValidationContext}.
     *
     * @param context root
     */
    public void validateGroupContext(final GroupValidationContext<?> context) {

        ConstraintValidator<T, ?> validator = getConstraintValidator(context.getConstraintValidatorFactory(),
                                                                     annotation, validatorClassArray, owner, access);
        if (validator != null) {
            validator.initialize(annotation);
        }

        context.setConstraintValidation(this);

        // process composed constraints
        final ConstraintValidationListener<?> listener = context.getListener();
        listener.beginReportAsSingle();

        boolean failed = listener.hasViolations();
        try {
            // stop validating when already failed and
            // ReportAsSingleInvalidConstraint = true ?
            for (Iterator<ValidationMetaValidation<?>> composed = composedConstraints.iterator(); composed.hasNext();) {
                composed.next().validate(context);
                failed = listener.hasViolations();
            }
        } finally {
            listener.endReportAsSingle();
            // Restore current constraint validation
            context.setConstraintValidation(this);
        }

        if (failed) {
            addErrors(context, new ConstraintValidatorContextImpl(context, this));
        }

        if (validator != null) {
            final ConstraintValidator<T, Object> objectValidator = (ConstraintValidator<T, Object>) validator;
            final ConstraintValidatorContextImpl jsrContext = new ConstraintValidatorContextImpl(context, this);
            if (!objectValidator.isValid(context.getValidatedValue(), jsrContext)) {
                addErrors(context, jsrContext);
            }
        }
    }

    @Override
    public T getAnnotation() {
        return annotation;
    }

    @Override
    public String getMessageTemplate() {
        return (String) allAttributes.get("message");
    }

    @Override
    public Set<Class<?>> getGroups() {
        return null;
    }

    @Override
    public Set<Class<? extends Payload>> getPayload() {
        return null;
    }

    @Override
    public ConstraintTarget getValidationAppliesTo() {
        return ConstraintTarget.IMPLICIT;
    }

    @Override
    public List<Class<? extends ConstraintValidator<T, ?>>> getConstraintValidatorClasses() {
        return validatorClasses;
    }

    @Override
    public Map<String, Object> getAttributes() {
        return allAttributes;
    }

    @Override
    public Set<ConstraintDescriptor<?>> getComposingConstraints() {
        return composedConstraints == null ? Collections.EMPTY_SET : new HashSet<>(composedConstraints);
    }

    @Override
    public boolean isReportAsSingleViolation() {
        return true;
    }

    @Override
    public AccessStrategy getAccess() {
        return access;
    }
}
