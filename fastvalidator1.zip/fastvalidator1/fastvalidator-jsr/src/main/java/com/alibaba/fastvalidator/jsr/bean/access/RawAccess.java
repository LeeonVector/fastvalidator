package com.alibaba.fastvalidator.jsr.bean.access;

import java.lang.annotation.ElementType;
import java.lang.reflect.Type;

/**
 * A simple access
 *
 * @author: jasen.zhangj
 * @date: 17/1/22.
 */
public class RawAccess extends AccessStrategy {

    private Object object;
    private String name;

    public RawAccess(Object object) {
        this.object = object;
    }

    public RawAccess(Object object, String name) {
        this.object = object;
        this.name = name;
    }

    @Override
    public Object get(Object instance) {
        return object;
    }

    @Override
    public ElementType getElementType() {
        return ElementType.TYPE;
    }

    @Override
    public Type getJavaType() {
        return object != null ? object.getClass() : null;
    }

    @Override
    public String getPropertyName() {
        return name;
    }
}
