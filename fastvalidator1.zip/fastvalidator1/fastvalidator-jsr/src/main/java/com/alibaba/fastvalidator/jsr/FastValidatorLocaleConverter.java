package com.alibaba.fastvalidator.jsr;

import java.util.Locale;

/**
 * Converter for locale.
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public interface FastValidatorLocaleConverter {

    /***
     * Convert the characters to the {@link Locale}
     *
     * @param bean the bean contains the locale characters.
     * @param locale locale string. may be null.
     * @return {@link Locale} converted locale
     */
    Locale convert(Object bean, String locale);
}
