package com.alibaba.fastvalidator.jsr.bean.util;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotBlank;
import com.alibaba.fastvalidator.constraints.FVLocale;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/20.
 */
public class JavaBean {

    @NotBlank
    private String name;

    @NotNull
    private Integer id;

    @NotBlank(message = "can''t be blank {0} {1}?{name}{notExistName}")
    private String messageWithArguments;

    @Valid
    private JavaBean child;

    @FVLocale
    private String locale;

    @Valid
    private ComposedBean composedBean;

    @FVLocale
    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public JavaBean getChild() {
        return child;
    }

    public void setChild(JavaBean child) {
        this.child = child;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ComposedBean getComposedBean() {
        return composedBean;
    }

    public void setComposedBean(ComposedBean composedBean) {
        this.composedBean = composedBean;
    }

    public String getMessageWithArguments() {
        return messageWithArguments;
    }

    public void setMessageWithArguments(String messageWithArguments) {
        this.messageWithArguments = messageWithArguments;
    }
}
