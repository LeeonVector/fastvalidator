package com.alibaba.fastvalidator.jsr.bean.util;

import org.hibernate.validator.constraints.NotBlank;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
public class ComposedBean {

    @NotBlank
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
