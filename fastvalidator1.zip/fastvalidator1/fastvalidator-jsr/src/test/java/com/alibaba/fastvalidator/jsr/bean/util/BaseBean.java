package com.alibaba.fastvalidator.jsr.bean.util;

/**
 * base bean
 *
 * @author: jasen.zhangj
 * @date: 2017/3/6.
 */
public class BaseBean {

    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
