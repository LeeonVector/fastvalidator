package com.alibaba.fastvalidator.jsr.bean.util.convert;

import java.util.Locale;

import com.alibaba.fastvalidator.jsr.FastValidatorLocaleConverter;
import com.alibaba.fastvalidator.jsr.Order;
import com.alibaba.fastvalidator.jsr.util.LocaleUtils;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 2017-05-11
 */
@Order(2)
public class Convert2 implements FastValidatorLocaleConverter {

    @Override
    public Locale convert(Object bean, String locale) {
        return LocaleUtils.toLocale(locale);
    }
}
