package com.alibaba.fastvalidator.jsr.bean.util;

/**
 * Meta Bean for test
 *
 * @author: jasen.zhangj
 * @date: 2017/3/3.
 */
public class MetaBean extends BaseBean {

    private String   str1;
    private Integer  int1;

    private JavaBean javaBean;

    public String getStr1() {
        return str1;
    }

    public void setStr1(String str1) {
        this.str1 = str1;
    }

    public Integer getInt1() {
        return int1;
    }

    public void setInt1(Integer int1) {
        this.int1 = int1;
    }

    public JavaBean getJavaBean() {
        return javaBean;
    }

    public void setJavaBean(JavaBean javaBean) {
        this.javaBean = javaBean;
    }
}
