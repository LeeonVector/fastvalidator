package com.alibaba.fastvalidator.jsr.bean.util;

import junit.framework.TestCase;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import com.alibaba.fastvalidator.jsr.ClassValidator;
import com.alibaba.fastvalidator.jsr.ConstraintValidationListener;
import com.alibaba.fastvalidator.jsr.FastValidatorConfiguration;
import com.alibaba.fastvalidator.jsr.FastValidatorLocaleConverter;
import com.alibaba.fastvalidator.jsr.FastValidatorValidationProvider;
import com.alibaba.fastvalidator.jsr.bean.util.annotation.CustomNotBlank;
import com.alibaba.fastvalidator.jsr.bean.util.convert.Convert1;
import com.alibaba.fastvalidator.jsr.bean.util.convert.Convert2;
import com.alibaba.fastvalidator.jsr.bean.util.convert.Convert3;
import com.alibaba.fastvalidator.jsr.meta.DefaultConstraintRegistry;
import com.alibaba.fastvalidator.meta.ComposedValidationMeta;
import com.alibaba.fastvalidator.meta.ConstraintMeta;
import com.alibaba.fastvalidator.meta.MetaValidator;
import com.alibaba.fastvalidator.meta.ValidationMeta;
import com.alibaba.fastvalidator.meta.constraints.Constraint;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/17.
 */
@RunWith(JUnit4.class)
public class FastValidatorTest extends TestCase {

    protected MetaValidator getValidator() {
        FastValidatorConfiguration configure = Validation.byProvider(FastValidatorValidationProvider.class).configure();
        configure.failFast(true);
        return (MetaValidator) configure.buildValidatorFactory().getValidator();
    }

    @Test
    public void testValidate() throws Exception {
        FastValidatorConfiguration configure = Validation.byProvider(FastValidatorValidationProvider.class).configure();
        configure.failFast(true);
        ClassValidator validator = (ClassValidator) configure.buildValidatorFactory().getValidator();
        JavaBean bean = getNormalJavaBean();
        JavaBean child = new JavaBean();
        child.setName("childTest");
        child.setMessageWithArguments("message");
        bean.setChild(child);

        Set<ConstraintViolation<JavaBean>> set = validator.validate(bean);
        checkMessage("child.id", "may not be null", set);
    }

    @Test
    public void testLocale(){
        JavaBean bean = getNormalJavaBean();
        bean.setId(null);
        bean.setLocale(Locale.CANADA_FRENCH.toString());
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(bean);
        checkMessage("id", "may not be null", set);

        bean.setId(1);
        ComposedBean composedBean = new ComposedBean();
        bean.setComposedBean(composedBean);
        set = validator.validate(bean);
        checkMessage("composedBean.name", "may not be empty", set);
    }

    @Test
    public void testMessageArgs(){
        JavaBean javaBean = getNormalJavaBean();
        javaBean.setMessageWithArguments(null);
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<JavaBean>> set = validator.validate(javaBean);
        checkMessage("messageWithArguments", "can't be blank jasen.zhangj notExistName", set);
    }

    @Test
    public void testConverSequence(){
        new ConstraintValidationListener(null, null);
        List<FastValidatorLocaleConverter> localeConverterList = ConstraintValidationListener.getLocaleConverterList();
        assertTrue(localeConverterList.size() == 3);
        assertTrue(localeConverterList.get(0).getClass() == Convert1.class);
        assertTrue(localeConverterList.get(1).getClass() == Convert2.class);
        assertTrue(localeConverterList.get(2).getClass() == Convert3.class);
    }

    @Test
    public void getAllConstraintsWithoutDefaultAttribute() throws Exception {
        Set<Constraint> constraintSet = DefaultConstraintRegistry.getInstance().getAllConstraintsWithoutDefaultAttribute();
        System.out.println("constraints size: " + constraintSet.size());
        for (Constraint constraint : constraintSet) {
            System.out.println("***************************");
            System.out.println(constraint.getName() + ":");
            for (Map.Entry<String, Type> typeEntry : constraint.getConstraintPropertyTypes().entrySet()) {
                System.out.print("(" + typeEntry.getKey() + "->");
                System.out.print("(" + typeEntry.getValue() + ")");
                System.out.println();
            }
        }
    }

    @Test
    public void putConstraints() throws Exception {
        DefaultConstraintRegistry.getInstance().putConstraints(CustomNotBlank.class);
        getAllConstraintsWithoutDefaultAttribute();
    }

    @Test
    public void testMeta_NotNull() {
        MetaValidator validator = getValidator();

        // 1.定义一个验证元数据
        ValidationMeta validationMeta = new ValidationMeta();
        ConstraintMeta constraintMeta = new ConstraintMeta();
        constraintMeta.setType(NotNull.class);

        // 2.在验证元数据里增加一个约束(验证条件)
        validationMeta.addConstraintMeta(constraintMeta);

        // 3. 通过验证器验证实际数据(null)
        Set<ConstraintViolation<ValidationMeta>> set = validator.validateByMeta(validationMeta, null);
        checkMessage(null, "may not be null", set);
    }

    @Test
    public void testMeta_Size() {
        MetaValidator validator = getValidator();

        ValidationMeta validationMeta = new ValidationMeta();

        ConstraintMeta constraintMeta = new ConstraintMeta();
        constraintMeta.setType(Size.class);
        constraintMeta.putAttributeValue("min", "10");
        constraintMeta.putAttributeValue("max", "20");

        validationMeta.addConstraintMeta(constraintMeta);

        Set<ConstraintViolation<String>> set = validator.validateByMeta(validationMeta, "1234");
        checkMessage(null, "size must be between 10 and 20", set);
    }

    @Test
    public void testMeta_Range() {
        MetaValidator validator = getValidator();

        ValidationMeta element = new ValidationMeta();

        ConstraintMeta constraintElement = new ConstraintMeta();
        constraintElement.setType(Range.class);
        constraintElement.putAttributeValue("min", "10");
        constraintElement.putAttributeValue("max", "20");

        element.addConstraintMeta(constraintElement);

        Set<ConstraintViolation<String>> set = validator.validateByMeta(element, "8");
        checkMessage(null, "must be between 10 and 20", set);
    }

    @Test
    public void testMeta_Bean() {
        MetaValidator validator = getValidator();

        // 组合约束元数据:validationMeta1+validationMeta2
        ComposedValidationMeta composedValidationMeta = new ComposedValidationMeta();

        ValidationMeta validationMeta1 = new ValidationMeta("str1");
        validationMeta1.addConstraintMeta(new ConstraintMeta(NotEmpty.class));

        ValidationMeta validationMeta2 = new ValidationMeta("int1");
        validationMeta2.addConstraintMeta(new ConstraintMeta(NotNull.class));

        composedValidationMeta.addValidationMeta(validationMeta1);
        composedValidationMeta.addValidationMeta(validationMeta2);

        MetaBean metaBean = new MetaBean();
        metaBean.setStr1("teststring");
        Set<ConstraintViolation<MetaBean>> set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("int1", "may not be null", set);

        metaBean.setInt1(12);
        metaBean.setStr1("");
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("str1", "may not be empty", set);
        metaBean.setStr1("123");

        // add another composed validation meta
        ValidationMeta validationMeta3 = new ValidationMeta("name");
        validationMeta3.addConstraintMeta(new ConstraintMeta(NotEmpty.class));
        ComposedValidationMeta anotherComposedValidationMeta = new ComposedValidationMeta();
        anotherComposedValidationMeta.setName("javaBean");
        anotherComposedValidationMeta.addValidationMeta(validationMeta3);
        composedValidationMeta.addValidationMeta(anotherComposedValidationMeta);

        metaBean.setJavaBean(null);
        anotherComposedValidationMeta.addConstraintMeta(new ConstraintMeta(NotNull.class));
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("javaBean", "may not be null", set);

        metaBean.setJavaBean(new JavaBean());
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("javaBean.name", "may not be empty", set);

        ValidationMeta idValidationMeta = new ValidationMeta("id");
        idValidationMeta.addConstraintMeta(new ConstraintMeta(NotNull.class));
        composedValidationMeta.addValidationMeta(idValidationMeta);

        metaBean.getJavaBean().setName("1234");
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("id", "may not be null", set);

        metaBean.setId(123);
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testMeta_Bean_When_Cascade_Bean_Is_Null(){
        MetaValidator validator = getValidator();
        ComposedValidationMeta metaBeanComposedValidationMeta = new ComposedValidationMeta();

        ComposedValidationMeta testBeanComposedValidationMeta = new ComposedValidationMeta();
        testBeanComposedValidationMeta.setName("javaBean");
        ValidationMeta nameValidationMeta = new ValidationMeta("name");
        nameValidationMeta.addConstraintMeta(new ConstraintMeta(NotEmpty.class));
        testBeanComposedValidationMeta.addValidationMeta(nameValidationMeta);
        metaBeanComposedValidationMeta.addValidationMeta(testBeanComposedValidationMeta);

        ValidationMeta idValidationMeta = new ValidationMeta("id");
        nameValidationMeta.addConstraintMeta(new ConstraintMeta(NotNull.class));
        metaBeanComposedValidationMeta.addValidationMeta(idValidationMeta);

        MetaBean object = new MetaBean();
        object.setId(1234);
        Set<ConstraintViolation<MetaBean>> set = validator.validateByMeta(metaBeanComposedValidationMeta, object);
        assertTrue(set.isEmpty());
    }

    @Test
    public void testMeta_Bean_Range() {
        MetaValidator validator = getValidator();

        // 组合约束元数据:validationMeta
        ComposedValidationMeta composedValidationMeta = new ComposedValidationMeta();

        ValidationMeta validationMeta = new ValidationMeta("int1");
        ConstraintMeta rangeMeta = new ConstraintMeta(Range.class);
        rangeMeta.putAttributeValue("min", "10");
        rangeMeta.putAttributeValue("max", "20");
        validationMeta.addConstraintMeta(rangeMeta);

        composedValidationMeta.addValidationMeta(validationMeta);

        MetaBean metaBean = new MetaBean();
        metaBean.setInt1(5);
        Set<ConstraintViolation<MetaBean>> set = validator.validateByMeta(composedValidationMeta, metaBean);
        checkMessage("int1", "must be between 10 and 20", set);

        metaBean.setInt1(12);
        set = validator.validateByMeta(composedValidationMeta, metaBean);
        assertTrue(set.isEmpty());
    }

    public JavaBean getNormalJavaBean(){
        JavaBean javaBean = new JavaBean();
        javaBean.setName("jasen.zhangj");
        javaBean.setId(10);
        javaBean.setMessageWithArguments("message");

        return javaBean;
    }

    protected <T> void checkMessage(String fieldName, String message,
                                    Set<ConstraintViolation<T>> constraintViolationSet) {
        assertTrue(!constraintViolationSet.isEmpty());
        ConstraintViolation constraintViolation = constraintViolationSet.iterator().next();
        assertTrue(constraintViolation.getMessage().equals(message));
        if (fieldName != null) {
            Path path = constraintViolation.getPropertyPath();
            assertTrue(path != null);
            StringBuffer sb = new StringBuffer();
            for (Path.Node node : path) {
                sb.append(node.getName()).append(".");
            }

            sb.setLength(sb.length() - 1);
            assertTrue(sb.toString().equals(fieldName));
        }
    }
}
