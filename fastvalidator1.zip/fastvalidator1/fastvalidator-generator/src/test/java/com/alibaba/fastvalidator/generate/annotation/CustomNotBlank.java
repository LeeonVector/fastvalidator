package com.alibaba.fastvalidator.generate.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Constraint(validatedBy = {CustomNotBlank.CustomNotBlankValidator.class})
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
@ReportAsSingleViolation
@NotNull
@NotEmpty
@Size(max=10)
public @interface CustomNotBlank {
    String message() default "{org.hibernate.validator.constraints.NotBlank.message}";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    String code() default "";

    /**
     * Defines several {@code @NotBlank} annotations on the same element.
     */
    @Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
    @Retention(RUNTIME)
    @Documented
    public @interface List {
        CustomNotBlank[] value();
    }

    /**
     * Check that a character sequence's (e.g. string) trimmed length is not empty.
     *
     * @author Hardy Ferentschik
     */
    public static class CustomNotBlankValidator implements ConstraintValidator<CustomNotBlank, CharSequence> {

        public void initialize(CustomNotBlank annotation) {
        }

        /**
         * Checks that the trimmed string is not empty.
         *
         * @param charSequence The character sequence to validate.
         * @param constraintValidatorContext context in which the constraint is evaluated.
         *
         * @return Returns <code>true</code> if the string is <code>null</code> or the length of <code>charSequence</code> between the specified
         *         <code>min</code> and <code>max</code> values (inclusive), <code>false</code> otherwise.
         */
        public boolean isValid(CharSequence charSequence, ConstraintValidatorContext constraintValidatorContext) {
            if ( charSequence == null ) {
                return true;
            }

            return charSequence.toString().trim().length() > 0;
        }
    }

}