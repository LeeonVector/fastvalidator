package com.alibaba.fastvalidator.generate;

import java.util.List;

import org.hibernate.validator.constraints.NotBlank;
import com.alibaba.fastvalidator.constraints.ValidateBean;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/18.
 */
@ValidateBean
public class TestBean {

    // @Range(min = -1, max = 1, message = "must between -1 and 1")
    private int           age;

    // @EachRange
    private List<Integer> eachRange;

    // @Range.List({ @Range(min = 18, max = 24), @Range(min = 40, max = 48) })
    private int           ranges;

    // @CustomNotBlank(groups = {UpdateGroup.class, Serializable.class})
    private String        name;

    // @Pattern.List({@Pattern(regexp = "aa"), @Pattern(regexp = "bb")})
    private String        patterns;

    // @Conditional(sourceCode = "ObjectUtils.equals(bean.getConditional(), bean.getName())", message = "conditional is
    // empty")
    private String        conditional;

    // @If(sourceCode = "!ObjectUtils.equals(bean.conditional2, bean.conditional)", message = "conditional2 is not
    // equals conditional")
    private String        conditional2;

    // @If(sourceCode = "StringUtils.isBlank(bean.getIfConstraint())", message = "ifConstraint is blank" )
    // @ConstraintDesc(order = 200, constraint = If.class)
    private String        ifConstraint;

    // @If(sourceCode = "!ObjectUtils.equals(bean.ifConstraint, bean.ifConstraint2)", message = "ifConstraint not equal
    // ifConstraint2" )
    // @ConstraintDesc(order = 100, constraint = If.class)
    private String        ifConstraint2;

    // @If(sourceCode = "!ObjectUtils.equals(bean.boolean1, bean.boolean2)", message = "boolean1 not equal boolean2",
    // groups = UpdateGroup.class)
    // @ConstraintDesc(order = 300, constraint = If.class)
    private boolean       boolean1;
    private boolean       boolean2;

    // @Email
    private String        email;

    // @Size(min = 2)
    // @NotNull
    private long[]        ids;

    // @Size(min = 1)
    // @NotNull
    private TestBean[]    testBeens;

    // @NotBlank
    private Long          id;

    // @CustomNotBlank
    private Long          id2;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getId2() {
        return id2;
    }

    public void setId2(Long id2) {
        this.id2 = id2;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TestBean[] getTestBeens() {
        return testBeens;
    }

    public void setTestBeens(TestBean[] testBeens) {
        this.testBeens = testBeens;
    }

    public long[] getIds() {
        return ids;
    }

    public void setIds(long[] ids) {
        this.ids = ids;
    }

    public String getConditional() {
        return conditional;
    }

    public void setConditional(String conditional) {
        this.conditional = conditional;
    }

    public List<Integer> getEachRange() {
        return eachRange;
    }

    public void setEachRange(List<Integer> eachRange) {
        this.eachRange = eachRange;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getRanges() {
        return ranges;
    }

    public void setRanges(int ranges) {
        this.ranges = ranges;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatterns() {
        return patterns;
    }

    public void setPatterns(String patterns) {
        this.patterns = patterns;
    }

    public String getConditional2() {
        return conditional2;
    }

    public void setConditional2(String conditional2) {
        this.conditional2 = conditional2;
    }

    public String getIfConstraint() {
        return ifConstraint;
    }

    public void setIfConstraint(String ifConstraint) {
        this.ifConstraint = ifConstraint;
    }

    public String getIfConstraint2() {
        return ifConstraint2;
    }

    public void setIfConstraint2(String ifConstraint2) {
        this.ifConstraint2 = ifConstraint2;
    }

    public boolean isBoolean1() {
        return boolean1;
    }

    public void setBoolean1(boolean boolean1) {
        this.boolean1 = boolean1;
    }

    public boolean isBoolean2() {
        return boolean2;
    }

    public void setBoolean2(boolean boolean2) {
        this.boolean2 = boolean2;
    }

    @ValidateBean
    public static class InnerBean {

        @NotBlank
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @ValidateBean
    public static class InnerBean2 {

        @NotBlank
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
