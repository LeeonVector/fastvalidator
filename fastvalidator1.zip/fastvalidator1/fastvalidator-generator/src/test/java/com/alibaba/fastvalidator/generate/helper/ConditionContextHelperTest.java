package com.alibaba.fastvalidator.generate.helper;

import java.util.Set;

import org.junit.Assert;
import org.junit.Test;
import com.alibaba.fastvalidator.constraints.utils.ObjectUtils;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.utils.TypeUtils;

/**
 * class description
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public class ConditionContextHelperTest {

    @Test
    public void getShouldImportTypes() throws Exception {
        Set<String> imports = ConditionContextHelper.getShouldImportTypes("StringUtils.notBlank(bean.c(),bean.d(yy))");
        Assert.assertTrue(imports.size() == 1);
        Assert.assertTrue(imports.iterator().next().equals(StringUtils.class.getName()));

        imports = ConditionContextHelper.getShouldImportTypes("bean.c(),bean.d(yy))");
        Assert.assertTrue(imports.isEmpty());

        imports = ConditionContextHelper.getShouldImportTypes("TypeUtils.isAssignable(bean.c(),bean.d(yy))");
        Assert.assertTrue(imports.size() == 1);
        Assert.assertTrue(imports.iterator().next().equals(TypeUtils.class.getName()));

        imports = ConditionContextHelper.getShouldImportTypes("ObjectUtils.equals(StringUtils.trim(bean.getC()), bean.getD())");
        Assert.assertTrue(imports.size() == 2);
        Assert.assertTrue(imports.contains(ObjectUtils.class.getName()));
        Assert.assertTrue(imports.contains(StringUtils.class.getName()));
    }

}