package com.alibaba.fastvalidator.generate.group;

/**
 * group for update
 *
 * @author: jasen.zhangj
 * @date: 24/03/2017.
 */
public interface UpdateGroup {
}
