package com.alibaba.fastvalidator.generate;

import java.io.File;
import java.io.PrintWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.StandardLocation;
import javax.tools.ToolProvider;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import org.hibernate.validator.constraints.Range;
import org.junit.Ignore;
import org.junit.Test;
import com.alibaba.fastvalidator.constraints.validator.CompostedValidator;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationDescriptor;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationFactory;
import com.alibaba.fastvalidator.constraints.validator.bv.MaxValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.MinValidatorForNumber;


/**
 * generate source codes test
 *
 * @author: jasen.zhangj
 * @date: 17/1/3.
 */
public class ValidateBeanAnnotationProcessorTest {

    @Test
    @Ignore
    public void runAnnoationProcessor() throws Exception {
        String source = "/Users/jasenzhang/work/fastvalidator/fastvalidator-generator/src/test/java";

        Iterable<JavaFileObject> files = getSourceFiles(source);

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();

        JavaCompiler.CompilationTask task = compiler.getTask(new PrintWriter(System.out), null, null, null, null,
                                                             files);
        task.setProcessors(Arrays.asList(new ValidateBeanAnnotationProcessor()));

        task.call();
    }

    @Test
    @Ignore
    public void runAnnoationProcessor2() throws Exception {
        String source = "/Users/jasenzhang/work/fastvalidator2/fastvalidator-test/src/main/java";

        Iterable<JavaFileObject> files = getSourceFiles(source);

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();

        JavaCompiler.CompilationTask task = compiler.getTask(new PrintWriter(System.out), null, null, null, null,
                files);
        task.setProcessors(Arrays.asList(new ValidateBeanAnnotationProcessor()));

        task.call();
    }

    private Iterable<JavaFileObject> getSourceFiles(String p_path) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        StandardJavaFileManager files = compiler.getStandardFileManager(null, null, null);

        files.setLocation(StandardLocation.SOURCE_PATH, Arrays.asList(new File(p_path)));

        Set<JavaFileObject.Kind> fileKinds = Collections.singleton(JavaFileObject.Kind.SOURCE);
        return files.list(StandardLocation.SOURCE_PATH, "", fileKinds, true);
    }

    @Test
    @Ignore
    public void testOverrideAttribute() throws NoSuchFieldException {
        Field ageRange = TestBean.class.getDeclaredField("age");
        Annotation ageRange_Range = ageRange.getAnnotation(Range.class);
        CompostedValidator ageRange_Range_Validator = new CompostedValidator();

        Annotation ageRange_Min = ageRange_Range.annotationType().getAnnotation(Min.class);
        AnnotationDescriptor min = AnnotationDescriptor.getInstance(ageRange_Min);
        min.setValue("value", -1L);
        Annotation proxyMin = AnnotationFactory.create(min);

        ageRange_Range_Validator.addComposingConstraintValidator(proxyMin, new MinValidatorForNumber());
        Annotation ageRange_Max = ageRange_Range.annotationType().getAnnotation(Max.class);
        ageRange_Range_Validator.addComposingConstraintValidator(ageRange_Max, new MaxValidatorForNumber());

        ageRange_Range_Validator.initialize(null);


        Field ranges = TestBean.class.getDeclaredField("ranges");
        Range.List rangeList = ranges.getAnnotation(Range.List.class);
        Range range1 = rangeList.value()[0];

    }
}
