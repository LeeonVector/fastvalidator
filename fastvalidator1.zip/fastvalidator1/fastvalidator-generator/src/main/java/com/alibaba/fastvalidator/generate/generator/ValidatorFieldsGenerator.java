package com.alibaba.fastvalidator.generate.generator;

import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.FieldSpec;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;

/**
 * Validator fields source codes generator
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ValidatorFieldsGenerator extends DefaultGenerator {

    protected List<FieldSpec> fieldSpecList = new ArrayList<>();

    public void generateForConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                      ConstraintInfo constraintInfo,
                                      ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                      ConstraintProcessor processor) {
        super.generateForConstraint(validateBeanInfo, context, constraintInfo, fieldConstraintFlatInfo, processor);

        ClassName constraintValidatorClass = processor.getRootConstraintValidatorClass(constraintInfo);
        String validatorFieldName = processor.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo);
        FieldSpec fieldSpec = FieldSpec.builder(constraintValidatorClass,
                                                validatorFieldName).addModifiers(Modifier.PRIVATE, Modifier.FINAL).initializer("new $T()",
                                                                                                     constraintValidatorClass).build();
        fieldSpecList.add(fieldSpec);
    }

    public List<FieldSpec> getFieldSpecList() {
        return fieldSpecList;
    }
}
