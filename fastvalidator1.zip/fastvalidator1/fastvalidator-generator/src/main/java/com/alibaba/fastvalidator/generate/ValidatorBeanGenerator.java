package com.alibaba.fastvalidator.generate;

import java.io.IOException;
import java.util.List;

import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;

import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.generator.ValidatorTypeGenerator;
import com.alibaba.fastvalidator.generate.logging.Logger;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessorFactory;

/**
 * Validate bean generator
 *
 * @author Hannes Dorfmann
 */
class ValidatorBeanGenerator {

    private Elements elementUtils;
    private Filer    filer;
    private Types    typeUtils;

    ValidatorBeanGenerator(Types typeUtils, Elements elementUtils, Filer filer, Messager messager) {
        this.elementUtils = elementUtils;
        this.filer = filer;
        Logger.messager = messager;
        this.typeUtils = typeUtils;
    }

    void generateCode(ValidateBeanInfo validateBeanInfo) throws IOException, IllegalAccessException,
                                                         InstantiationException {

        if (validateBeanInfo.getAnnotatedFields().isEmpty()) {
            return;
        }

        try {
            ValidatorBeanGeneratorContext context = new ValidatorBeanGeneratorContext(elementUtils, typeUtils, filer);
            List<ValidateBeanInfo.FieldConstraintFlatInfo> fieldConstraintFlatInfos = validateBeanInfo.getSortedFieldFlatInfo(context);

            ValidatorTypeGenerator validatorTypeGenerator = getValidatorTypeGenerator(validateBeanInfo, context);

            // before generateForConstraint
            validatorTypeGenerator.beforeGenerate(validateBeanInfo, context);

            for (ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo : fieldConstraintFlatInfos) {
                String fieldName = fieldConstraintFlatInfo.getName();
                Object constraintObject = fieldConstraintFlatInfo.getConstraint();

                try {
                    ConstraintProcessor processor = ConstraintProcessorFactory.getConstraintProcessor(constraintObject);

                    ConstraintInfo constraintDescriptor = processor.getConstraintDescriptor(constraintObject);

                    if (constraintDescriptor == null) {
                        validatorTypeGenerator.generateForNonConstraint(validateBeanInfo, context,
                                                                        fieldConstraintFlatInfo);

                    } else {
                        context.setHasEffectiveConstraint(true);
                        constraintDescriptor.setListConstraint(fieldConstraintFlatInfo.getListAnnotation());
                        constraintDescriptor.setConstraintInListIndex(fieldConstraintFlatInfo.getConstraintInListIndex());

                        processor.setConstraintValidatorClass(constraintDescriptor, validateBeanInfo, fieldName,
                                                              context);
                        validatorTypeGenerator.generateForConstraint(validateBeanInfo, context, constraintDescriptor,
                                                                     fieldConstraintFlatInfo, processor);
                    }

                } catch (Throwable ex) {
                    String qualifiedClassName = validateBeanInfo.getQualifiedClassName();
                    String annotationClass = fieldConstraintFlatInfo.getConstraint() != null ? fieldConstraintFlatInfo.getConstraint().toString() : "unknown";

                    Logger.error(qualifiedClassName + "." + fieldName + "'s " + annotationClass
                                 + " analysis failed. Cause: " + ex.getClass().getName() + ")", ex,
                                 validateBeanInfo.getClassTypeElement());
                }
            }

            if (!context.isHasEffectiveConstraint()) {
                return;
            }

            // after generateForConstraint
            validatorTypeGenerator.afterGenerate(validateBeanInfo, context);

        } catch (Throwable ex) {
            String qualifiedClassName = validateBeanInfo.getQualifiedClassName();

            Logger.error("Generate validator source codes failed for : " + qualifiedClassName + " Cause: "
                         + ex.getClass().getName() + ")", ex, validateBeanInfo.getClassTypeElement());
        }
    }

    /***
     * generate validator type
     */
    protected ValidatorTypeGenerator getValidatorTypeGenerator(ValidateBeanInfo validateBeanInfo,
                                                               ValidatorBeanGeneratorContext context) {
        return new ValidatorTypeGenerator();
    }
}
