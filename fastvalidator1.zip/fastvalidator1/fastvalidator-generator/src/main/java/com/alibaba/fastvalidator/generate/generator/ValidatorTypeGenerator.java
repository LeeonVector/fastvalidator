package com.alibaba.fastvalidator.generate.generator;

import java.io.IOException;
import java.util.List;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.validation.ConstraintValidator;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.FieldSpec;
import com.alibaba.fastvalidator.generate.javapoet.JavaFile;
import com.alibaba.fastvalidator.generate.javapoet.ParameterizedTypeName;
import com.alibaba.fastvalidator.generate.javapoet.TypeSpec;
import com.alibaba.fastvalidator.generate.logging.Logger;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;

/**
 * Validator type source codes generator
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ValidatorTypeGenerator extends DefaultGenerator {

    protected TypeSpec.Builder validatorTypeBuilder;

    protected static final String SUFFIX = "Validator";

    protected ImportGenerator importGenerator = new ImportGenerator();
    protected ValidatorFieldsGenerator validatorFieldsGenerator = new ValidatorFieldsGenerator();
    protected ValidatorInitializeMethodGenerator initializeMethodGenerator = new ValidatorInitializeMethodGenerator();
    protected ValidatorIsValidMethodGenerator isValidMethodGenerator = new ValidatorIsValidMethodGenerator();

    public ValidatorTypeGenerator() {
        addChild(importGenerator);
        addChild(validatorFieldsGenerator);
        addChild(initializeMethodGenerator);
        addChild(isValidMethodGenerator);
    }

    @Override
    public void beforeGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        super.beforeGenerate(validateBeanInfo, context);

        TypeElement classTypeElement = validateBeanInfo.getClassTypeElement();
        String validatorClassName = classTypeElement.getSimpleName() + SUFFIX;
        validatorTypeBuilder = TypeSpec.classBuilder(validatorClassName).addModifiers(Modifier.PUBLIC);

        ClassName validateBeanAnnotation = ClassName.bestGuess(ValidateBean.class.getName());
        String qualifiedClassName = validateBeanInfo.getQualifiedClassName();
        ClassName beanClassName = ClassName.bestGuess(qualifiedClassName);

        ParameterizedTypeName superInterface = ParameterizedTypeName.get(ClassName.bestGuess(ConstraintValidator.class.getName()),
                validateBeanAnnotation, beanClassName);

        validatorTypeBuilder.addSuperinterface(superInterface);
    }

    @Override
    public void afterGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        super.afterGenerate(validateBeanInfo, context);

        List<FieldSpec> fieldSpecList = validatorFieldsGenerator.getFieldSpecList();

        // add fields
        TypeSpec.Builder validatorTypeBuilder = this.getValidatorTypeBuilder();
        for (FieldSpec fieldSpec : fieldSpecList) {
            validatorTypeBuilder.addField(fieldSpec);
        }

        // add initialize method
        validatorTypeBuilder.addMethod(initializeMethodGenerator.getInitializeMethodBuilder().build());

        // add isValid method
        validatorTypeBuilder.addMethods(isValidMethodGenerator.getAllMethodBuilders());
        TypeSpec typeSpec = validatorTypeBuilder.build();

        TypeElement classTypeElement = validateBeanInfo.getClassTypeElement();
        PackageElement pkg = context.getElementUtils().getPackageOf(classTypeElement);
        String packageName = pkg.isUnnamed() ? "validator" : pkg.getQualifiedName().toString() + ".validator";

        // Write source file
        JavaFile.Builder validatorBuild = JavaFile.builder(packageName, typeSpec);
        for (String importType : getShouldImportTypes()) {
            validatorBuild.adddImport(importType);
        }

        try {
            validatorBuild.build().writeTo(context.getFiler());
        } catch (IOException e) {
            String qualifiedClassName = validateBeanInfo.getQualifiedClassName();

            Logger.error("Write validator source file failed for : " + qualifiedClassName + " Cause: "
                    + e.getClass().getName() + ")", e, validateBeanInfo.getClassTypeElement());
        }
    }

    public TypeSpec.Builder getValidatorTypeBuilder() {
        return validatorTypeBuilder;
    }
}
