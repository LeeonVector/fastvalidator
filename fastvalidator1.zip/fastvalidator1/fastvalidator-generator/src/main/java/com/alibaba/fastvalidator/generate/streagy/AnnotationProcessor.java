package com.alibaba.fastvalidator.generate.streagy;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;

import com.alibaba.fastvalidator.constraints.validator.CompostedValidator;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationDescriptor;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationFactory;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageInterpolatorHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.MethodSpec;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;


/**
 * processor for annotation
 *
 * @author: jasen.zhangj
 * @date: 16/11/9.
 */
public class AnnotationProcessor extends ConstraintProcessor<Annotation> {

    @Override
    public ConstraintInfo getConstraintDescriptor(Annotation type) {
        return ConstraintInfo.build(type);
    }

    @Override
    public ClassName getConstraintClassName(ConstraintInfo constraintInfo) {
        return ClassName.bestGuess(constraintInfo.getConstraint().annotationType().getName());
    }

    @Override
    public ClassName getConstraintClassName(Annotation constraintList) {
        return ClassName.bestGuess(constraintList.annotationType().getName());
    }

    @Override
    public String getValidatorFieldName(ConstraintInfo constraintInfo, ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(fieldConstraintFlatInfo.getName()).append("_").append(constraintInfo.getConstraint().annotationType().getSimpleName()).append("_Validator");
        if (fieldConstraintFlatInfo.getConstraintInListIndex() != null) {
            stringBuilder.append("_").append(fieldConstraintFlatInfo.getConstraintInListIndex());
        }

        return stringBuilder.toString();
    }

    @Override
    public String interpolateMessage(ConstraintInfo constraintInfo) {
        String message = (String) constraintInfo.getAttribute("message");
        message = MessageInterpolatorHelper.interpolate(message, constraintInfo.getConstraint());

        return message;
    }

    @Override
    public void setConstraintValidatorClass(ConstraintInfo constraintInfo, ValidateBeanInfo validateBeanInfo,
                                            String fieldName, ValidatorBeanGeneratorContext context) {
        Annotation annotation = constraintInfo.getConstraint();
        Class<? extends Annotation> annotationClass = annotation.annotationType();
        List<? extends Class<? extends ConstraintValidator<?, ?>>> constraintValidatorClasses = constraintInfo.getDefaultValidatorClasses(annotationClass);
        if (constraintValidatorClasses == null || constraintValidatorClasses.size() == 0) {
            Constraint constraint = annotation.annotationType().getAnnotation(Constraint.class);
            if (constraint != null) {
                constraintValidatorClasses = Arrays.asList(constraint.validatedBy());
            }
        }

        setConstraintValidator0(constraintInfo, validateBeanInfo, fieldName, context, annotationClass,
                                constraintValidatorClasses);
    }

    @Override
    public boolean isEachCommonValidator(ConstraintInfo constraintInfo) {
        return constraintInfo.getConstraintValidator() != null
               && constraintInfo.getConstraintValidator().getName().equals(EACH_VALIDATOR);
    }

    @Override
    public ClassName getConstraintValidatorClass(ConstraintInfo constraintInfo) {
        Class<? extends ConstraintValidator> constraintValidatorClass = constraintInfo.getConstraintValidator();
        return constraintValidatorClass != null ? ClassName.bestGuess(constraintValidatorClass.getName()) : null;
    }

    @Override
    public ClassName getRootConstraintValidatorClass(ConstraintInfo constraintInfo) {
        Class<? extends ConstraintValidator> constraintValidatorClass = constraintInfo.isComposingConstratin() ? CompostedValidator.class : constraintInfo.getConstraintValidator();
        return ClassName.bestGuess(constraintValidatorClass.getName());
    }

    @Override
    public boolean hasOverrideAttributes(ConstraintInfo parentConstraintInfo) {
        return !parentConstraintInfo.getOverrideAttributes().isEmpty();
    }

    @Override
    public void generateOverrideAttribute(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo, MethodSpec.Builder initializeMethodBuilder, ConstraintInfo constraintInfo, String annotationFieldName, ConstraintInfo parentConstraintInfo) {
        List<AnnotationUtils.OverrideAttribute> overrideAttributes = parentConstraintInfo.getOverrideAttributes();
        String validatorFieldName = getValidatorFieldName(parentConstraintInfo, fieldConstraintFlatInfo);
        String proxyFieldName = getProxyFieldName(constraintInfo, fieldConstraintFlatInfo);
        String parrentAnnotationFieldName = getAnnotationFieldName(fieldConstraintFlatInfo, parentConstraintInfo);
        initializeMethodBuilder.addStatement("$T $L = AnnotationDescriptor.getInstance($L)", AnnotationDescriptor.class,
                                             proxyFieldName, annotationFieldName);

        for (AnnotationUtils.OverrideAttribute overrideAttribute : overrideAttributes) {
            if (overrideAttribute.getOverrideConstraint().getName().equals(constraintInfo.getConstraintClass())) {
                String overrideAttributeName = overrideAttribute.getOverrideAttributeName();
                initializeMethodBuilder.addStatement("$L.setValue($S, $T.readAttribute($L,$S))", proxyFieldName,
                                                     overrideAttributeName, AnnotationUtils.class,
                                                     parrentAnnotationFieldName, overrideAttribute.getMethodName());
            }
        }

        initializeMethodBuilder.addStatement("$L.addComposingConstraintValidator($T.create($L), new $T())",
                                             validatorFieldName, AnnotationFactory.class, proxyFieldName,
                                             getConstraintValidatorClass(constraintInfo));
    }

}
