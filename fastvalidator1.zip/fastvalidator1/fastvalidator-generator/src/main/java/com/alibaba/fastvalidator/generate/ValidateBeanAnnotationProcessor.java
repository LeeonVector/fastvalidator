/*
 * Copyright (C) 2015 Hannes Dorfmann Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions and limitations under the
 * License.
 */

package com.alibaba.fastvalidator.generate;

import java.lang.annotation.Annotation;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedOptions;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;
import javax.tools.Diagnostic;

import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.generate.exception.ProcessingException;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;


/**
 * Annotation Processor for the type with @ValidateBean annotation
 *
 * @author jasen.zhangj
 */
@SupportedOptions({ "debug", "verify" })
@SupportedAnnotationTypes({ "com.alibaba.fastvalidator.constraints.ValidateBean" })
public class ValidateBeanAnnotationProcessor extends AbstractProcessor {

    private Types                         typeUtils;
    private Elements                      elementUtils;
    private Filer                         filer;
    private Messager                      messager;

    private Map<String, TypeElement>      validateBeanClassMap = new ConcurrentHashMap<String, TypeElement>();
    private Map<String, ValidateBeanInfo> validateBeanInfoMap  = new ConcurrentHashMap<String, ValidateBeanInfo>();

    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        typeUtils = processingEnv.getTypeUtils();
        elementUtils = processingEnv.getElementUtils();
        filer = processingEnv.getFiler();
        messager = processingEnv.getMessager();
    }

    @Override
    public Set<String> getSupportedAnnotationTypes() {
        Set<String> annotations = new LinkedHashSet<>();
        annotations.add(ValidateBean.class.getCanonicalName());
        return annotations;
    }

    @Override
    public SourceVersion getSupportedSourceVersion() {
        return SourceVersion.latestSupported();
    }

    /**
     * Checks if the annotated element observes our rules
     */
    private void checkValidClass(TypeElement classElement) throws ProcessingException {

        // Cast to TypeElement, has more type specific methods
        if (classElement.getKind() != ElementKind.CLASS) {
            throw new ProcessingException(classElement, "The class %s should be a class.",
                                          classElement.getQualifiedName().toString());
        }

        // Check if an empty public constructor is given
        for (Element enclosed : classElement.getEnclosedElements()) {
            if (enclosed.getKind() == ElementKind.CONSTRUCTOR) {
                ExecutableElement constructorElement = (ExecutableElement) enclosed;
                if (constructorElement.getParameters().size() == 0
                    && constructorElement.getModifiers().contains(Modifier.PUBLIC)) {
                    // Found an empty constructor
                    return;
                }
            }
        }

        // No empty constructor found
        throw new ProcessingException(classElement, "The class %s must provide an public empty default constructor",
                                      classElement.getQualifiedName().toString());
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        try {
            if (roundEnv.processingOver()) {
                if (validateBeanInfoMap.size() == 0) {
                    return true;
                }

                ClassLoader currentContextClassLoader = null;
                try {

                    currentContextClassLoader = Thread.currentThread().getContextClassLoader();
                    Thread.currentThread().setContextClassLoader(ValidateBeanAnnotationProcessor.class.getClassLoader());

                    for (Map.Entry<String, ValidateBeanInfo> validateBeanInfoEntry : validateBeanInfoMap.entrySet()) {
                        String beanClassName = validateBeanInfoEntry.getKey();
                        ValidateBeanInfo validateBeanInfo = validateBeanInfoEntry.getValue();
                        TypeElement typeElement = validateBeanClassMap.get(beanClassName);
                        if (typeElement == null) {
                            continue;
                        }

                        ValidatorBeanGenerator validatorBeanGenerator = new ValidatorBeanGenerator(typeUtils,
                                                                                                   elementUtils, filer,
                                                                                                   messager);

                        try {

                            validatorBeanGenerator.generateCode(validateBeanInfo);
                        } catch (Exception e) {
                            error(null, e.getMessage());
                        }
                    }
                } finally {
                    Thread.currentThread().setContextClassLoader(currentContextClassLoader);
                    validateBeanInfoMap.clear();
                }

            } else {
                // Scan classes
                for (Element classAnnotatedElement : roundEnv.getElementsAnnotatedWith(ValidateBean.class)) {
                    // Check if a class has been annotated with @ValidateBean
                    if (classAnnotatedElement.getKind() != ElementKind.CLASS) {
                        continue;
                    }


                    // We can cast it, because we know that it of ElementKind.CLASS
                    TypeElement typeElement = (TypeElement) classAnnotatedElement;
                    checkValidClass(typeElement);
                    putValidateBeanInfo(typeElement);
                }

            }

        } catch (ProcessingException e) {
            error(e.getElement(), e.getMessage());
        }

        return true;
    }



    private void putValidateBeanInfo(TypeElement typeElement) {
        String className = typeElement.getQualifiedName().toString();
        if ("java.lang.Object".equals(className)){
            return;
        }

        if (validateBeanClassMap.containsKey(className)) {
            return;
        }else {
            validateBeanClassMap.put(className, typeElement);
        }

        List<? extends Element> elements = typeElement.getEnclosedElements();
        if (elements != null) {
            for (Element element : elements) {
                if (element.getKind() == ElementKind.FIELD) {
                    List<? extends AnnotationMirror> annotationMirrors = element.getAnnotationMirrors();
                    if (annotationMirrors != null && !annotationMirrors.isEmpty()) {
                        for (AnnotationMirror annotationMirror : annotationMirrors) {
                            if (!validateBeanInfoMap.containsKey(className)) {
                                ValidateBeanInfo validateBeanInfo = new ValidateBeanInfo(typeElement);
                                validateBeanInfoMap.put(className, validateBeanInfo);
                            }

                            String annotationClassName = annotationMirror.getAnnotationType().toString();
                            try {
                                Class<? extends Annotation> clazz = (Class<? extends Annotation>) Class.forName(annotationClassName);
                                Annotation annotation = element.getAnnotation(clazz);
                                validateBeanInfoMap.get(className).add(element, annotation);
                            } catch (ClassNotFoundException e) {
                                validateBeanInfoMap.get(className).add(element, annotationMirror);
                                // continue;
                                // error(classAnnotatedElement, "can't load class : " + annotationClassName
                                // + ", please put this a class in a compiled jar");
                            }
                        }
                    } else {
                        if (!validateBeanInfoMap.containsKey(className)) {
                            ValidateBeanInfo validateBeanInfo = new ValidateBeanInfo(typeElement);
                            validateBeanInfoMap.put(className, validateBeanInfo);
                        }

                        validateBeanInfoMap.get(className).addNonAnnotatedFieldElement(element);
                    }
                }
            }
        }

        TypeMirror superClass = typeElement.getSuperclass();
        if (superClass != null){
            Element superElement = typeUtils.asElement(superClass);
            putValidateBeanInfo((TypeElement) superElement);
        }

    }

    /**
     * Prints an error message
     *
     * @param e The element which has caused the error. Can be null
     * @param msg The error message
     */
    public void error(Element e, String msg) {
        messager.printMessage(Diagnostic.Kind.ERROR, msg, e);
    }

    public void error(Element e, String msg, Object... args) {
        error(e, String.format(msg, args));
    }
}
