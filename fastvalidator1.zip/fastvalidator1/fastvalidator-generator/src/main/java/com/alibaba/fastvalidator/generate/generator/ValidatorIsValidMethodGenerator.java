package com.alibaba.fastvalidator.generate.generator;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;

import javax.lang.model.element.Modifier;

import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageHelper;
import com.alibaba.fastvalidator.constraints.validator.metadata.SimpleConstraintDescriptor;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.helper.GroupStatementHelper;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.MethodSpec;
import com.alibaba.fastvalidator.generate.javapoet.ParameterizedTypeName;
import com.alibaba.fastvalidator.generate.javapoet.TypeName;
import com.alibaba.fastvalidator.generate.javapoet.WildcardTypeName;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;

/**
 * Validator's isValid method source codes generator
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ValidatorIsValidMethodGenerator extends DefaultGenerator {

    protected static final String  PARAMETER0_NAME      = "bean";
    protected static final String  PARAMETER1_NAME      = "context";

    private MethodSpec.Builder     isValidMethodBuilder;

    private MethodSpec.Builder     isValidFailFastDefaultGroupMethodBuilder;
    private MethodSpec.Builder     isValidFailFastNonDefaultGroupMethodBuilder;
    private MethodSpec.Builder     isValidNonFailFastDefaultGroupMethodBuilder;
    private MethodSpec.Builder     isValidNonFailFastNonDefaultGroupMethodBuilder;

    private MethodSpec.Builder     getSimpleConstraintDescriptorMethodBuilder;

    private List<IsValidMethodInfo> isValidMethodInfoList = new ArrayList<>();
    protected ConditionalGenerator conditionalGenerator = new ConditionalGenerator();

    public ValidatorIsValidMethodGenerator() {
        addChild(conditionalGenerator);
    }

    @Override
    public void beforeGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {

        super.beforeGenerate(validateBeanInfo, context);

        ClassName beanClassName = ClassName.bestGuess(validateBeanInfo.getQualifiedClassName());
        ClassName constraintValidatorContext = ClassName.bestGuess("javax.validation.ConstraintValidatorContext");
        //Increase the Override annotation while creating the isValid method
        isValidMethodBuilder = MethodSpec.methodBuilder("isValid").addModifiers(Modifier.PUBLIC).addParameter(beanClassName,
                                                                                                              PARAMETER0_NAME).addParameter(constraintValidatorContext,
                                                                                                                                            PARAMETER1_NAME).returns(getReturnType()).addAnnotation(Override.class);

        ClassName groupValidationContext = ClassName.bestGuess("com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext");
        isValidMethodBuilder.addStatement("boolean failFast = (($T)context).isFailFast()", groupValidationContext);
        isValidMethodBuilder.addCode("if (failFast) {" + "\n" +
                        "    return isValidInFailFast($L, $L);" + "\n" +
                        "} else { " +  "\n" +
                        "    return isValidInNonFailFast($L, $L);" + "\n" +
                        "} \n",
                           PARAMETER0_NAME, PARAMETER1_NAME, PARAMETER0_NAME, PARAMETER1_NAME);

        String isValidInFailFastInNonDefaultGroup = "isValidInFailFastInNonDefaultGroup";
        isValidFailFastDefaultGroupMethodBuilder = initialDefaultGroupMethod(beanClassName, constraintValidatorContext,"isValidInFailFast", isValidInFailFastInNonDefaultGroup);
        isValidFailFastNonDefaultGroupMethodBuilder = initialNonDefaultGroupMethod(beanClassName, constraintValidatorContext, isValidInFailFastInNonDefaultGroup);

        String isValidInNonFailFastInNonDefaultGroup = "isValidInNonFailFastInNonDefaultGroup";
        isValidNonFailFastDefaultGroupMethodBuilder = initialDefaultGroupMethod(beanClassName, constraintValidatorContext,"isValidInNonFailFast", isValidInNonFailFastInNonDefaultGroup);
        isValidNonFailFastNonDefaultGroupMethodBuilder = initialNonDefaultGroupMethod(beanClassName, constraintValidatorContext, isValidInNonFailFastInNonDefaultGroup);

        isValidMethodInfoList.add(new IsValidMethodInfo(isValidFailFastDefaultGroupMethodBuilder, isValidFailFastNonDefaultGroupMethodBuilder, true));
        isValidMethodInfoList.add(new IsValidMethodInfo(isValidNonFailFastDefaultGroupMethodBuilder, isValidNonFailFastNonDefaultGroupMethodBuilder, false));

        buildGetSimpleConstraintDescriptorMethod();
    }

    protected void buildGetSimpleConstraintDescriptorMethod() {
        String fieldName = "fieldName";
        String constraintType = "constraintType";
        String beanType = "beanType";

        ParameterizedTypeName constraintAnnotationType = ParameterizedTypeName.get(ClassName.bestGuess(Class.class.getName()), WildcardTypeName.subtypeOf(Annotation.class));

        getSimpleConstraintDescriptorMethodBuilder = MethodSpec.methodBuilder("getSimpleConstraintDescriptor").addModifiers(Modifier.PROTECTED).addParameter(String.class,
                fieldName).addParameter(constraintAnnotationType,
                constraintType).addParameter(Class.class,
                beanType).returns(SimpleConstraintDescriptor.class);
        getSimpleConstraintDescriptorMethodBuilder.addCode(
                "try {\n" +
                        "    Annotation annotation = beanType.getDeclaredField(fieldName).getAnnotation(constraintType);\n" +
                        "    return new SimpleConstraintDescriptor(annotation);\n" +
                        "} catch (Exception e) {\n" +
                        "    throw new com.alibaba.fastvalidator.constraints.exception.FastValidatorException(\"get annotation failed\", e);\n" +
                        "}\n");
    }

    public MethodSpec.Builder initialDefaultGroupMethod(ClassName beanClassName, ClassName constraintValidatorContext, String methodName, String nonGroupMethodName) {
        MethodSpec.Builder methodBuilder = MethodSpec.methodBuilder(methodName).addModifiers(Modifier.PUBLIC).addParameter(beanClassName,
                PARAMETER0_NAME).addParameter(constraintValidatorContext,
                PARAMETER1_NAME).returns(getReturnType());

        methodBuilder.addStatement("context.disableDefaultConstraintViolation()");
        methodBuilder.addStatement("boolean result = true");
        methodBuilder.addCode("if (!((FastValidatorBeanContext)context).isDefaultGroup()) { \n");
        methodBuilder.addCode("\t return " + nonGroupMethodName + "(" + PARAMETER0_NAME + ", " + PARAMETER1_NAME + "); \n");
        methodBuilder.addCode("} else { \n");

        return methodBuilder;
    }

    public MethodSpec.Builder initialNonDefaultGroupMethod(ClassName beanClassName, ClassName constraintValidatorContext, String methodName) {
        MethodSpec.Builder methodBuilder = MethodSpec.methodBuilder(methodName).addModifiers(Modifier.PUBLIC).addParameter(beanClassName,
                PARAMETER0_NAME).addParameter(constraintValidatorContext,
                PARAMETER1_NAME).returns(getReturnType());
        methodBuilder.addStatement("boolean result = true");

        return methodBuilder;
    }

    @Override
    public void generateForConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                      ConstraintInfo constraintInfo,
                                      ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                      ConstraintProcessor processor) {
        super.generateForConstraint(validateBeanInfo, context, constraintInfo, fieldConstraintFlatInfo, processor);
        for (IsValidMethodInfo isValidMethodInfo : isValidMethodInfoList) {
            addCode(validateBeanInfo, constraintInfo, fieldConstraintFlatInfo, processor,isValidMethodInfo);
        }
    }

    protected void addCode(ValidateBeanInfo validateBeanInfo, ConstraintInfo constraintInfo,
                           ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                           ConstraintProcessor processor, IsValidMethodInfo isValidMethodInfo) {
        String fieldName = fieldConstraintFlatInfo.getName();
        String code = fieldConstraintFlatInfo.getCode();
        String getMethodName = validateBeanInfo.getGetMethodName(fieldName);

        boolean isEachCommonValidator = processor.isEachCommonValidator(constraintInfo);
        String validatorFieldName = processor.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo);

        String message = processor.interpolateMessage(constraintInfo);
        message = MessageHelper.generateMessage(message, code);

        boolean containsDefaultGroup = GroupStatementHelper.isContainsDefaultGroup(constraintInfo.getAttributes());
        StringBuffer validMethodBody = new StringBuffer();
        if (containsDefaultGroup){
            validMethodBody.append(isValidMethodInfo.getIfStatement());
        }

        validMethodBody.append("(!$L.isValid($L.$L(), context)) {\n");
        if (!isEachCommonValidator) {
            validMethodBody.append("   ((FastValidatorBeanContext)context).setBeanPropertyConstraintDescriptor(getSimpleConstraintDescriptor($S, $T.class, $T.class));\n");
            validMethodBody.append("   context.buildConstraintViolationWithTemplate($S).addNode($S).addConstraintViolation();\n");
        }
        validMethodBody.append("   result = false;\n" + "}\n");

        List<Object> params = new ArrayList<>();
        params.add(validatorFieldName);
        params.add(PARAMETER0_NAME);
        params.add(getMethodName);

        if (!isEachCommonValidator) {
            // for getSimpleConstraintDescriptor method
            params.add(fieldName);
            ClassName constraintClassName;
            if (constraintInfo.isInList()) {
                constraintClassName = processor.getConstraintClassName(constraintInfo.getListConstraint());
            } else {
                constraintClassName = processor.getConstraintClassName(constraintInfo);
            }
            params.add(constraintClassName);
            ClassName beanClassName = ClassName.bestGuess(validateBeanInfo.getQualifiedClassName());
            params.add(beanClassName);

            params.add(message);
            params.add(fieldName);
        }


        if (containsDefaultGroup) {
            isValidMethodInfo.defaultGroupBuilder.addCode(validMethodBody.toString(), params.toArray());
        }

        // check the constraint's group is match to the current group.
        GroupStatementHelper.addGroupMatchStatement(constraintInfo, params, validMethodBody, isValidMethodInfo);
    }

    @Override
    public void afterGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        super.afterGenerate(validateBeanInfo, context);

        isValidFailFastDefaultGroupMethodBuilder.addStatement("return $L", "result");
        isValidFailFastDefaultGroupMethodBuilder.addCode("}\n");
        isValidFailFastNonDefaultGroupMethodBuilder.addStatement("return $L", "result");

        isValidNonFailFastDefaultGroupMethodBuilder.addStatement("return $L", "result");
        isValidNonFailFastDefaultGroupMethodBuilder.addCode("}\n");
        isValidNonFailFastNonDefaultGroupMethodBuilder.addStatement("return $L", "result");
    }

    protected TypeName getReturnType() {
        return TypeName.BOOLEAN;
    }

    public List<IsValidMethodInfo> getIsValidMethodInfoList() {
        return isValidMethodInfoList;
    }

    public List<MethodSpec> getAllMethodBuilders() {
        List<MethodSpec> list = new ArrayList();
        list.add(isValidMethodBuilder.build());

        list.add(isValidFailFastDefaultGroupMethodBuilder.build());
        list.add(isValidNonFailFastDefaultGroupMethodBuilder.build());
        list.add(isValidFailFastNonDefaultGroupMethodBuilder.build());
        list.add(isValidNonFailFastNonDefaultGroupMethodBuilder.build());

        list.add(getSimpleConstraintDescriptorMethodBuilder.build());

        return list;
    }

    public static class IsValidMethodInfo {

        MethodSpec.Builder defaultGroupBuilder;
        MethodSpec.Builder nonDefaultGroupBuilder;
        private boolean failFast;
        private int defaultGroupCount = 0;
        private int nonDefaultGroupCount = 0;

        public IsValidMethodInfo(MethodSpec.Builder defaultGroupBuilder, MethodSpec.Builder nonDefaultGroupBuilder, boolean failFast) {
            this.defaultGroupBuilder = defaultGroupBuilder;
            this.nonDefaultGroupBuilder = nonDefaultGroupBuilder;
            this.failFast = failFast;
        }

        public String getIfStatement() {
            if (failFast) {
                return defaultGroupCount++ == 0 ? "if " : "else if ";
            } else {
                return "if";
            }
        }

        public String getNonDefaultGroupIfStatement() {
            if (failFast) {
                return nonDefaultGroupCount++ == 0 ? "if " : "else if ";
            } else {
                return "if";
            }
        }

        public MethodSpec.Builder getNonDefaultGroupBuilder() {
            return nonDefaultGroupBuilder;
        }
    }
}
