package com.alibaba.fastvalidator.generate.helper;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.alibaba.fastvalidator.constraints.utils.ArrayUtils;
import com.alibaba.fastvalidator.constraints.utils.CharSequenceUtils;
import com.alibaba.fastvalidator.constraints.utils.ClassUtils;
import com.alibaba.fastvalidator.constraints.utils.ObjectUtils;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.utils.TypeUtils;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;

/**
 * Helper for {@link com.alibaba.fastvalidator.constraints.Conditional}
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ConditionContextHelper {

    private static final Pattern            CLASS_NAME_PATTERN = Pattern.compile("([\\w\\.]+\\()");
    private static final Map<String, Class> DEFAULT_VARIABLES;

    static {
        DEFAULT_VARIABLES = new HashMap<>();

        DEFAULT_VARIABLES.put("bean", null);
        registeDefaultVariable(DEFAULT_VARIABLES, StringUtils.class);
        registeDefaultVariable(DEFAULT_VARIABLES, ObjectUtils.class);
        registeDefaultVariable(DEFAULT_VARIABLES, ArrayUtils.class);
        registeDefaultVariable(DEFAULT_VARIABLES, CharSequenceUtils.class);
        registeDefaultVariable(DEFAULT_VARIABLES, ClassUtils.class);
        registeDefaultVariable(DEFAULT_VARIABLES, TypeUtils.class);
    }

    private static void registeDefaultVariable(Map<String, Class> utilsMap, Class<?> clazz) {
        utilsMap.put(clazz.getSimpleName(), clazz);
    }

    public static boolean isDefaultVariable(String utilsName) {
        return DEFAULT_VARIABLES.containsKey(utilsName);
    }

    public static Class<?> getVariableType(String utilsName) {
        return DEFAULT_VARIABLES.get(utilsName);
    }

    final static Pattern BEAN_METHOD_PATTERN = Pattern.compile("(bean\\.\\w+)");

    public static String getSourceCode(String sourceCode) {
        Matcher matcher = BEAN_METHOD_PATTERN.matcher(sourceCode);
        StringBuffer sb = new StringBuffer(64);
        while (matcher.find()) {
            String invokerInfo = matcher.group(1);
            if (StringUtils.isNotBlank(invokerInfo) && sourceCode.charAt(matcher.end()) != '(') {
                String[] arrs = StringUtils.split(invokerInfo, ".");
                matcher.appendReplacement(sb, arrs[0] + "." + "get" + StringUtils.capitalize(arrs[1]) + "()");
            } else if (StringUtils.isNotBlank(invokerInfo)) {
                matcher.appendReplacement(sb, invokerInfo);
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    public static String getSourceCode(String sourceCode, ValidateBeanInfo validateBeanInfo) {
        Matcher matcher = BEAN_METHOD_PATTERN.matcher(sourceCode);
        StringBuffer sb = new StringBuffer(64);
        while (matcher.find()) {
            String invokerInfo = matcher.group(1);
            if (StringUtils.isNotBlank(invokerInfo) && sourceCode.charAt(matcher.end()) != '(') {
                String[] arrays = StringUtils.split(invokerInfo, ".");
                matcher.appendReplacement(sb, arrays[0] + "." + validateBeanInfo.getGetMethodName(arrays[1]) + "()");
            } else if (StringUtils.isNotBlank(invokerInfo)) {
                matcher.appendReplacement(sb, invokerInfo);
            }
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    public static Set<String> getShouldImportTypes(String conditionSourceCode) {
        final Matcher matcher = CLASS_NAME_PATTERN.matcher(conditionSourceCode);
        Set<String> shouldImportsTypes = new HashSet();
        while (matcher.find()) {
            String invokerInfo = matcher.group(1);
            if (StringUtils.isNotBlank(invokerInfo)) {
                String[] invokerNameAndMethod = StringUtils.split(invokerInfo, ".");
                if (invokerNameAndMethod != null && invokerNameAndMethod.length > 0) {
                    if (isDefaultVariable(invokerNameAndMethod[0])) {
                        Class<?> importType = getVariableType(invokerNameAndMethod[0]);
                        if (importType != null) {
                            shouldImportsTypes.add(importType.getName());
                        }
                    }
                }
            }
        }

        return shouldImportsTypes;
    }

    public static void main(String[] args) {
        // String.copyValueOf ()
        String sourceCode = getSourceCode("bean.id == null");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("bean.getId() == null");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("StringUtils.isBlank(bean.getId())");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("StringUtils.isBlank(bean.id)");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("StringUtils.isBlank(bean.id, bean.name)");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("StringUtils.isBlank(bean.isName(), bean.getId())");
        System.out.println(sourceCode);

        sourceCode = getSourceCode("StringUtils.isBlank(bean.name, bean.getId())");
        System.out.println(sourceCode);

        sourceCode = getSourceCode("StringUtils.isBlank(bean.name, StringUtils.trim(bean.getId()))");
        System.out.println(sourceCode);
        sourceCode = getSourceCode("StringUtils.isBlank(bean.name(), StringUtils.trim(bean.id))");
        System.out.println(sourceCode);

        sourceCode = getSourceCode("StringUtils.isBlank(bean.name ())");
        System.out.println(sourceCode);
    }
}
