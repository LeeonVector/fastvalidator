package com.alibaba.fastvalidator.generate.meta;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.type.DeclaredType;
import javax.validation.ConstraintValidator;
import com.alibaba.fastvalidator.constraints.utils.ObjectUtils;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.generate.helper.AnnotationMirrorHelper;
import com.alibaba.fastvalidator.generate.logging.Logger;

import static com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils.OVERRIDE_ATTRIBUTES;

/**
 * constraint descriptor
 *
 * @author: jasen.zhangj
 * @date: 15/12/5.
 */
public class ConstraintInfo {

    public static final String GROUPS = "groups";
    public static final String MESSAGE = "message";

    /**
     * like @Range.List
     */
    private Object listConstraint;
    private Integer constraintInListIndex;

    /***
     * Constraint annotation
     */
    private Annotation                                     constraint;

    /***
     * annotation class name
     */
    private String                                         constraintClass;

    /***
     * Composed constraint
     */
    private ConstraintInfo                                 parent;

    /***
     * Constraint validator class
     */
    private Class<? extends ConstraintValidator>           constraintValidator;

    /***
     * Constraint validator class(String type)
     */
    private String                                         strConstraintValidator;

    /**
     * The constraint parameters as map. The key is the parameter name and the value the parameter value as specified in
     * the constraint.
     */
    private Map<String, Object>                            attributes               = new HashMap<>();

    /**
     * The composing constraints for this constraint.
     */
    private Set<ConstraintInfo>                            composingConstraints     = new HashSet<>();

    /***
     * Override attributes
     */
    private List<AnnotationUtils.OverrideAttribute>        overrideAttributes       = new ArrayList<>();

    /***
     * Override attribute mirror
     */
    private List<AnnotationMirrorHelper.OverrideAttribute> overrideAttributesMirror = new ArrayList<>();

    /***
     * Constraint helper
     */
    private static FastValidatorConstraintHelper           constraintHelper         = FastValidatorConstraintHelper.getInstance();

    public static ConstraintInfo build(Annotation annotation) {
        return build0(annotation, null);
    }

    public static ConstraintInfo build(AnnotationMirror annotationMirror) {
        return build0(annotationMirror, null);
    }

    private static ConstraintInfo build0(AnnotationMirror annotationMirror, ConstraintInfo parent) {
        DeclaredType annotationType = annotationMirror.getAnnotationType();
        String annotationClassName = annotationMirror.getAnnotationType().toString();
        Element element = annotationType.asElement();

        if (!AnnotationMirrorHelper.isConstraintAnnotation(element)) {
            return null;
        }

        ConstraintInfo constraintDescriptor = new ConstraintInfo();
        constraintDescriptor.constraintClass = annotationClassName;
        constraintDescriptor.attributes = AnnotationMirrorHelper.getAnnotationValue(annotationMirror);
        constraintDescriptor.setParent(parent);

        if (constraintDescriptor.attributes.containsKey(AnnotationMirrorHelper.OVERRIDE_ATTRIBUTES)) {
            constraintDescriptor.overrideAttributesMirror = (List<AnnotationMirrorHelper.OverrideAttribute>) constraintDescriptor.attributes.get(AnnotationMirrorHelper.OVERRIDE_ATTRIBUTES);
        }

        Map<? extends ExecutableElement, ? extends AnnotationValue> elementValues;
        List<? extends AnnotationMirror> annotationMirrors = element.getAnnotationMirrors();
        for (AnnotationMirror mirror : annotationMirrors) {
            String s = mirror.getAnnotationType().toString();
            if (s.startsWith("java.lang") || s.startsWith("javax.validation.Constraint")
                || s.startsWith("javax.validation.ReportAsSingleViolation")) {

                if (s.equals("javax.validation.Constraint")) {
                    elementValues = mirror.getElementValues();
                    if (elementValues != null) {
                        for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> entry : elementValues.entrySet()) {
                            ExecutableElement executableElement = entry.getKey();
                            String methodName = executableElement.getSimpleName().toString();
                            Object obj = entry.getValue().getValue();
                            if (methodName.equals("validatedBy") && ((List) obj).size() > 0) {
                                String validatorClass = ((List) obj).get(0).toString();
                                if (validatorClass.endsWith(".class")) {
                                    int i = validatorClass.lastIndexOf('.');
                                    constraintDescriptor.strConstraintValidator = validatorClass.substring(0, i);
                                }
                            }
                        }
                    }
                }

                continue;
            }

            ConstraintInfo annotationConstraintDescriptor = build0(mirror, constraintDescriptor);
            if (annotationConstraintDescriptor != null) {
                constraintDescriptor.addComposingConstraint(annotationConstraintDescriptor);
            }
        }

        return constraintDescriptor;
    }

    public static ConstraintInfo build0(Annotation annotation, ConstraintInfo parent) {
        boolean isConstraintAnnotation = constraintHelper.isConstraintAnnotation(annotation.annotationType());
        if (!isConstraintAnnotation) {
            return null;
        }

        Map<String, Object> attributes = getAnnotationParameterValues(annotation);
        ConstraintInfo current = new ConstraintInfo(annotation, attributes);
        if (attributes.containsKey(OVERRIDE_ATTRIBUTES)) {
            current.setOverrideAttributes((List<AnnotationUtils.OverrideAttribute>) attributes.get(OVERRIDE_ATTRIBUTES));
        }

        validateAttributes(annotation, attributes);
        current.setParent(parent);

        List<Annotation> composingAnnotations = constraintHelper.getComposingAnnotation(annotation);
        for (Annotation composingAnnotation : composingAnnotations) {
            ConstraintInfo constraintDescriptor = build0(composingAnnotation, current);
            if (constraintDescriptor != null) {
                current.addComposingConstraint(constraintDescriptor);
            }
        }

        return current;
    }

    private static void validateAttributes(Annotation annotation, Map<String, Object> attributes) {
        if (!attributes.containsKey(MESSAGE) || !attributes.containsKey(GROUPS)) {
            Logger.error(annotation.annotationType().getName() + " must have [message], [groups] attributes");
        }
    }

    public static Map<String, Object> getAnnotationParameterValues(Annotation annotation) {
        Map<String, Object> parameters = AnnotationUtils.getAnnotationParameterValues(annotation);
        return parameters;
    }

    private ConstraintInfo() {

    }

    private ConstraintInfo(Annotation constraint, Map<String, Object> attributes) {
        this.attributes = attributes;
        this.constraint = constraint;
        this.constraintClass = constraint.annotationType().getName();
    }

    public Annotation getConstraint() {
        return constraint;
    }

    public void setConstraint(Annotation constraint) {
        this.constraint = constraint;
    }

    public Map<String, Object> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    public Set<ConstraintInfo> getComposingConstraints() {
        return composingConstraints;
    }

    public void setComposingConstraints(Set<ConstraintInfo> composingConstraints) {
        this.composingConstraints = composingConstraints;
    }

    public void addComposingConstraint(ConstraintInfo constraintDescriptor) {
        composingConstraints.add(constraintDescriptor);
    }

    public Object getAttribute(String key) {
        return attributes.get(key);
    }

    public boolean isComposingConstratin() {
        return !composingConstraints.isEmpty();
    }

    public Class<? extends ConstraintValidator> getConstraintValidator() {
        return constraintValidator;
    }

    public void setConstraintValidator(Class<? extends ConstraintValidator> constraintValidator) {
        this.constraintValidator = constraintValidator;
        if (constraintValidator != null) {
            this.strConstraintValidator = constraintValidator.getName();
        }
    }

    public ConstraintInfo getParent() {
        return parent;
    }

    public void setParent(ConstraintInfo parent) {
        this.parent = parent;
    }

    public <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> getDefaultValidatorClasses(Class<A> annotationType) {
        return constraintHelper.getAllValidatorClasses(annotationType);
    }

    public <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> getDefaultValidatorClasses(String annotationType) {
        try {
            Class<A> aClass = (Class<A>) Class.forName(annotationType);
            return constraintHelper.getAllValidatorClasses(aClass);

        } catch (ClassNotFoundException e) {
            Logger.error("can't load class:" + annotationType, e);
            return null;
        }
    }

    public String getStrConstraintValidator() {
        return strConstraintValidator;
    }

    public String getConstraintClass() {
        return constraintClass;
    }

    public String getConstraintSimpleClass() {
        return StringUtils.isNotBlank(constraintClass) ? constraintClass.substring(constraintClass.lastIndexOf(".")
                                                                                   + 1) : null;
    }

    public List<AnnotationUtils.OverrideAttribute> getOverrideAttributes() {
        return overrideAttributes;
    }

    public void setOverrideAttributes(List<AnnotationUtils.OverrideAttribute> overrideAttributes) {
        this.overrideAttributes = overrideAttributes;
    }

    public List<AnnotationMirrorHelper.OverrideAttribute> getOverrideAttributesMirror() {
        return overrideAttributesMirror;
    }

    public Object getListConstraint() {
        return listConstraint;
    }

    public void setListConstraint(Object listConstraint) {
        this.listConstraint = listConstraint;
    }

    public boolean isInList(){
        return listConstraint != null;
    }

    public Integer getConstraintInListIndex() {
        return constraintInListIndex;
    }

    public void setConstraintInListIndex(Integer constraintInListIndex) {
        this.constraintInListIndex = constraintInListIndex;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ConstraintInfo that = (ConstraintInfo) o;

        if (strConstraintValidator == null && constraintValidator == null) {
            return false;
        }

        if (this.constraintClass != null && that.constraintClass != null) {
            return ObjectUtils.equals(this.attributes, that.attributes)
                   && ObjectUtils.equals(this.overrideAttributes, that.overrideAttributes)
                   && ObjectUtils.equals(this.overrideAttributesMirror, that.overrideAttributesMirror)
                    && ObjectUtils.equals(this.listConstraint, that.listConstraint)
                    && ObjectUtils.equals(this.constraintInListIndex, that.constraintInListIndex);
        }

        return false;
    }

    @Override
    public int hashCode() {
        int result = constraint != null ? constraint.hashCode() : 0;
        result = 31 * result + (constraintClass != null ? constraintClass.hashCode() : 0);
        result = 31 * result + (attributes != null ? attributes.hashCode() : 0);
        result = 31 * result + (overrideAttributes != null ? overrideAttributes.hashCode() : 0);
        result = 31 * result + (overrideAttributesMirror != null ? overrideAttributesMirror.hashCode() : 0);
        result = 31 * result + (strConstraintValidator != null ? strConstraintValidator.hashCode() : 0);
        result = 31 * result + (constraintValidator != null ? constraintValidator.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ConstraintInfo{");
        sb.append("constraintClass='").append(constraintClass).append('\'');
        sb.append(", strConstraintValidator='").append(strConstraintValidator).append('\'');
        sb.append(", attributes=").append(attributes);
        sb.append('}');
        return sb.toString();
    }
}
