package com.alibaba.fastvalidator.generate.generator;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.alibaba.fastvalidator.constraints.Conditional;
import com.alibaba.fastvalidator.constraints.If;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.helper.ConditionContextHelper;
import com.alibaba.fastvalidator.generate.helper.GroupStatementHelper;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;

/**
 * Generator for {@link com.alibaba.fastvalidator.constraints.Conditional} and {@link com.alibaba.fastvalidator.constraints.If}
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ConditionalGenerator extends DefaultGenerator {


    @Override
    public void generateForNonConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                         ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo) {
        super.generateForNonConstraint(validateBeanInfo, context, fieldConstraintFlatInfo);

        Object nonConstraint = fieldConstraintFlatInfo.getConstraint();
        if (nonConstraint instanceof Annotation) {
            addConditionalStatement(context, fieldConstraintFlatInfo, (Annotation) nonConstraint, validateBeanInfo);
        }
    }

    private void addConditionalStatement(ValidatorBeanGeneratorContext context,
                                         ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                         Annotation nonConstraint, ValidateBeanInfo validateBeanInfo) {
        if (nonConstraint.annotationType() == Conditional.class || nonConstraint.annotationType() == If.class) {
            String sourceCode = AnnotationUtils.readAttribute(nonConstraint, "sourceCode", String.class);
            sourceCode = ConditionContextHelper.getSourceCode(sourceCode, validateBeanInfo);

            ValidatorIsValidMethodGenerator isValidMethodGenerator = (ValidatorIsValidMethodGenerator) getParent();
            ClassName beanClassName = ClassName.bestGuess(validateBeanInfo.getQualifiedClassName());

            for (ValidatorIsValidMethodGenerator.IsValidMethodInfo isValidMethodInfo : isValidMethodGenerator.getIsValidMethodInfoList()) {
                StringBuffer validMethodBody = new StringBuffer();

                boolean containsDefaultGroup = GroupStatementHelper.isContainsDefaultGroup(AnnotationUtils.getAnnotationParameterValues(nonConstraint));
                if (containsDefaultGroup){
                    validMethodBody.append(isValidMethodInfo.getIfStatement());
                }

                validMethodBody.append("(" + sourceCode + ") {\n");
                validMethodBody.append("   ((FastValidatorBeanContext)context).setBeanPropertyConstraintDescriptor(getSimpleConstraintDescriptor($S, $T.class, $T.class));\n");
                validMethodBody.append("   context.buildConstraintViolationWithTemplate($S).addNode($S).addConstraintViolation();\n");
                validMethodBody.append("   result = false;\n" + "}\n");

                String message = AnnotationUtils.readAttribute(nonConstraint, "message", String.class);
                String code = fieldConstraintFlatInfo.getCode();
                message = MessageHelper.generateMessage(message, code);
                String fieldName = fieldConstraintFlatInfo.getName();

                List<Object> params = new ArrayList<>();
                // for getSimpleConstraintDescriptor method
                params.add(fieldName);
                ClassName constraintClassName = ClassName.bestGuess(nonConstraint.annotationType().getName());
                params.add(constraintClassName);
                params.add(beanClassName);

                params.add(message);
                params.add(fieldName);


                if (containsDefaultGroup) {
                    isValidMethodInfo.defaultGroupBuilder.addCode(validMethodBody.toString(), params.toArray());
                }

                // check the constraint's group is match to the current group.
                GroupStatementHelper.addGroupMatchStatement(nonConstraint, params, validMethodBody, isValidMethodInfo);

                context.setHasEffectiveConstraint(true);

                Set<String> shouldImports = ConditionContextHelper.getShouldImportTypes(sourceCode);
                if (shouldImports != null) {
                    addImports(shouldImports);
                }
            }
        }
    }
}
