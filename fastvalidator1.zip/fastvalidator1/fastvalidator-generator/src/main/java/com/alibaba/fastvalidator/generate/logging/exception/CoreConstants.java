package com.alibaba.fastvalidator.generate.logging.exception;

/**
 * Constants
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class CoreConstants {

    // Note that the line.separator property can be looked up even by
    // applets.
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");


    public static final String CAUSED_BY = "Caused by: ";
    public static final String SUPPRESSED = "Suppressed: ";
    public static final String WRAPPED_BY = "Wrapped by: ";

    public static final char TAB = '\t';


}
