package com.alibaba.fastvalidator.generate.context;

import javax.annotation.processing.Filer;
import javax.lang.model.util.Elements;
import javax.lang.model.util.Types;

import com.alibaba.fastvalidator.generate.helper.AnnotationMirrorHelper;

/**
 * Generator context for generate validator.
 *
 * @author: jasen.zhangj
 * @date: 17/1/3.
 */
public class ValidatorBeanGeneratorContext {

    private Elements               elementUtils;

    private Types                  typeUtils;

    private Filer                  filer;

    boolean                        hasEffectiveConstraint = false;
    private AnnotationMirrorHelper annotationMirrorHelper;

    public ValidatorBeanGeneratorContext(Elements elementUtils, Types typeUtils, Filer filer) {
        this.elementUtils = elementUtils;
        this.typeUtils = typeUtils;
        this.filer = filer;
        annotationMirrorHelper = new AnnotationMirrorHelper(elementUtils, typeUtils);
    }

    public Elements getElementUtils() {
        return elementUtils;
    }

    public Types getTypeUtils() {
        return typeUtils;
    }

    public Filer getFiler() {
        return filer;
    }

    public boolean isHasEffectiveConstraint() {
        return hasEffectiveConstraint;
    }

    public void setHasEffectiveConstraint(boolean hasEffectiveConstraint) {
        this.hasEffectiveConstraint = hasEffectiveConstraint;
    }

    public AnnotationMirrorHelper getAnnotationMirrorHelper() {
        return annotationMirrorHelper;
    }
}
