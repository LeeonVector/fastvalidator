package com.alibaba.fastvalidator.generate.generator;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.MethodSpec;
import com.alibaba.fastvalidator.generate.javapoet.TypeName;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;

import static com.alibaba.fastvalidator.generate.generator.ValidatorTypeGenerator.SUFFIX;

/**
 * Validator initialize method source codes generator.
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class ValidatorInitializeMethodGenerator extends DefaultGenerator {

    private MethodSpec.Builder   initializeMethodBuilder;
    private Map<String, Boolean> fieldInitialed = new HashMap<>();
    boolean                      hasInvokeFieldReflectMethod = false;

    public ValidatorInitializeMethodGenerator() {
        ClassName validateBeanAnnotation = ClassName.bestGuess(ValidateBean.class.getName());
        //Increase the Override annotation while creating the initialize method
        initializeMethodBuilder = MethodSpec.methodBuilder("initialize").addModifiers(Modifier.PUBLIC).addParameter(validateBeanAnnotation,
                                                                                                                    "constraintAnnotation").returns(TypeName.VOID).addAnnotation(Override.class);
    }

    @Override
    public void generateForConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                      ConstraintInfo constraintInfo,
                                      ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                      ConstraintProcessor processor) {
        super.generateForConstraint(validateBeanInfo, context, constraintInfo, fieldConstraintFlatInfo, processor);

        String fieldName = fieldConstraintFlatInfo.getName();
        String validatorFieldName = processor.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo);
        ClassName annotationClass = processor.getConstraintClassName(constraintInfo);
        boolean isEachCommonValidator = processor.isEachCommonValidator(constraintInfo);
        String code = fieldConstraintFlatInfo.getCode();

        if (fieldInitialed.get(fieldName) == null) {
            if (!hasInvokeFieldReflectMethod) {
                initializeMethodBuilder.addCode("try { \n\n");
                hasInvokeFieldReflectMethod = true;
            }

            String qualifiedClassName = validateBeanInfo.getQualifiedClassName();
            ClassName beanClassName = ClassName.bestGuess(qualifiedClassName);
            initializeMethodBuilder.addStatement("$T $L = $L.class.getDeclaredField($S)", Field.class, fieldName,
                                                 beanClassName, fieldName);
            fieldInitialed.put(fieldName, Boolean.TRUE);
        }

        if (!constraintInfo.isComposingConstratin()) {
            if (constraintInfo.isInList()){
                ClassName listClassType = processor.getConstraintClassName(constraintInfo.getListConstraint());
                String listAnnotationFieldName = getListAnnotationFieldName(fieldConstraintFlatInfo, constraintInfo,
                                                                            processor);
                String annotationStatement = "$T $L = $L.getAnnotation($T.class)";
                initializeMethodBuilder.addStatement(annotationStatement, listClassType, listAnnotationFieldName,
                                                     fieldName, listClassType);

                String annotationFieldName = processor.getAnnotationFieldName(fieldConstraintFlatInfo, constraintInfo);

                initializeMethodBuilder.addStatement("$T $L = $L.value()[$L]", annotationClass, annotationFieldName,
                                                     listAnnotationFieldName,
                                                     constraintInfo.getConstraintInListIndex());
                initializeMethodBuilder.addStatement("$L.initialize($L)", validatorFieldName, annotationFieldName);
            } else {
                initializeMethodBuilder.addStatement("$L.initialize($L.getAnnotation($T.class))", validatorFieldName,
                        fieldName, annotationClass);
            }

            if (isEachCommonValidator) {
                initializeMethodBuilder.addStatement("$L.setNodeName($S)", validatorFieldName, fieldName);
                if (StringUtils.isNotBlank(code)) {
                    initializeMethodBuilder.addStatement("$L.setCode($S)", validatorFieldName, code);
                }

            }
        } else {
            setComposingValidatorStatement(fieldConstraintFlatInfo, constraintInfo, processor);
        }
        initializeMethodBuilder.addCode("\n");
    }

    protected void setComposingValidatorStatement(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                                  ConstraintInfo constraintInfo, ConstraintProcessor processor) {
        addComposingConstraintValidator(fieldConstraintFlatInfo, constraintInfo, processor);

        for (ConstraintInfo childConstraintInfo : constraintInfo.getComposingConstraints()) {
            setComposingValidatorStatement0(fieldConstraintFlatInfo, childConstraintInfo, processor, 1, constraintInfo);
        }

        String validatorFieldName = processor.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo);
        initializeMethodBuilder.addStatement("$L.initialize(null)", validatorFieldName);
    }

    protected void addComposingConstraintValidator(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                                   ConstraintInfo constraintInfo, ConstraintProcessor processor) {
        String annotationStatement = "$T $L = $L.getAnnotation($T.class)";

        ClassName constraintClassName = processor.getConstraintClassName(constraintInfo);
        String fieldName = fieldConstraintFlatInfo.getName();
        String validatorFieldName = processor.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo);
        String annotationFieldName = processor.getAnnotationFieldName(fieldConstraintFlatInfo, constraintInfo);
        ClassName annotationClass = ClassName.bestGuess("java.lang.annotation.Annotation");

        ClassName rootConstraintValidatorClass = processor.getRootConstraintValidatorClass(constraintInfo);
        if (rootConstraintValidatorClass != null) {
            if (constraintInfo.isInList()){
                ClassName listClassType = processor.getConstraintClassName(constraintInfo.getListConstraint());
                String listAnnotationFieldName = getListAnnotationFieldName(fieldConstraintFlatInfo,constraintInfo,processor);
                initializeMethodBuilder.addStatement(annotationStatement, listClassType, listAnnotationFieldName, fieldName,
                                                     listClassType);
                initializeMethodBuilder.addStatement("$T $L = $L.value()[$L]", annotationClass, annotationFieldName, listAnnotationFieldName, constraintInfo.getConstraintInListIndex());
            } else {
                initializeMethodBuilder.addStatement(annotationStatement, annotationClass, annotationFieldName, fieldName,
                        constraintClassName);
            }

            ClassName constraintValidatorClass = processor.getConstraintValidatorClass(constraintInfo);
            if (constraintValidatorClass != null) {
                initializeMethodBuilder.addStatement("$L.addComposingConstraintValidator($L, new $T())",
                                                     validatorFieldName, annotationFieldName, constraintValidatorClass);
            }
        }
    }

    private Map<String, List<ConstraintInfo>> fieldGeneratedConstraints = new HashMap<>();

    private String generateKey(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                               ConstraintInfo constraintInfo, ConstraintProcessor processor, ClassName annotationType){
        StringBuilder stringBuilder = new StringBuilder(fieldConstraintFlatInfo.getName());
        stringBuilder.append("_").append(annotationType.reflectionName());

        ConstraintInfo parent = constraintInfo.getParent();
        while (parent != null){
            if (parent.isInList()){
                stringBuilder.append("_").append(parent.getConstraintInListIndex());
            }

            parent = parent.getParent();
        }

        return stringBuilder.toString();
    }

    protected void setComposingValidatorStatement0(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                                   ConstraintInfo constraintInfo, ConstraintProcessor processor,
                                                   int depth, ConstraintInfo parentConstraintInfo) {
        ClassName annotationType = processor.getConstraintClassName(constraintInfo);

        String key = generateKey(fieldConstraintFlatInfo, constraintInfo, processor, annotationType);

        List<ConstraintInfo> constraintInfoList = fieldGeneratedConstraints.get(key);
        if (constraintInfoList == null) {
            constraintInfoList = new ArrayList<>();
            constraintInfoList.add(constraintInfo);
            fieldGeneratedConstraints.put(key, constraintInfoList);
        } else {
            // unneed handle it if same constraint
            if (constraintInfoList.contains(constraintInfo)){
                return;
            }
        }

        // the root field's validator
        while (parentConstraintInfo.getParent() != null) {
            parentConstraintInfo = parentConstraintInfo.getParent();
        }

        String fieldConstraintValidatorName = processor.getValidatorFieldName(parentConstraintInfo,
                                                                              fieldConstraintFlatInfo);
        List<Object> args = new ArrayList<>();

        String annotationFieldName = processor.getAnnotationFieldName(fieldConstraintFlatInfo, constraintInfo);
        args.add(annotationFieldName);
        args.add(processor.getAnnotationFieldName(fieldConstraintFlatInfo, constraintInfo.getParent()));

        StringBuilder annotationStatement = new StringBuilder("Annotation $L = $L");
        for (int i = 0; i < depth; i++) {
            annotationStatement.append(".annotationType().getAnnotation($T.class)");
            args.add(annotationType);
        }

        initializeMethodBuilder.addStatement(annotationStatement.toString(), args.toArray());

        if (processor.hasOverrideAttributes(parentConstraintInfo)) {
            processor.generateOverrideAttribute(fieldConstraintFlatInfo, initializeMethodBuilder, constraintInfo,
                                                annotationFieldName, parentConstraintInfo);
        } else {
            ClassName constraintValidatorClass = processor.getConstraintValidatorClass(constraintInfo);
            if (constraintValidatorClass != null) {
                initializeMethodBuilder.addStatement("$L.addComposingConstraintValidator($L, new $T())",
                                                     fieldConstraintValidatorName, annotationFieldName,
                                                     constraintValidatorClass);
            }
        }

        for (ConstraintInfo childConstraintInfo : constraintInfo.getComposingConstraints()) {
            setComposingValidatorStatement0(fieldConstraintFlatInfo, childConstraintInfo, processor, 1, constraintInfo);
        }
    }

    @Override
    public void afterGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        super.afterGenerate(validateBeanInfo, context);

        if (hasInvokeFieldReflectMethod) {
            TypeElement classNameElement = validateBeanInfo.getClassTypeElement();
            String validatorClassName = classNameElement.getSimpleName() + SUFFIX;
            initializeMethodBuilder.addCode("} catch (NoSuchFieldException e) {\n"
                    + "   throw new com.alibaba.fastvalidator.constraints.exception.ValidatorInitialException(\"validator("
                    + validatorClassName + ") initialize failed\", e); \n" + "}");
        }
    }

    public MethodSpec.Builder getInitializeMethodBuilder() {
        return initializeMethodBuilder;
    }

    protected String getListAnnotationFieldName(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                            ConstraintInfo constraintInfo,
                                            ConstraintProcessor processor) {
        StringBuilder constraintName = new StringBuilder();
        // NotEmpty_NotNull
        while (constraintInfo.getParent() != null) {
            ClassName parentAnnotationType = processor.getConstraintClassName(constraintInfo.getParent());
            if (constraintName.length() > 0) {
                constraintName.insert(0, "_");
                constraintName.insert(0, parentAnnotationType.simpleName());
            } else {
                constraintName.append(parentAnnotationType.simpleName());
                constraintName.append("_");
            }

            constraintInfo = constraintInfo.getParent();
        }

        ClassName listClassType = processor.getConstraintClassName(constraintInfo.getListConstraint());
        String listClassTypeName = listClassType.name(-2);
        listClassTypeName = listClassTypeName.replaceAll("\\.","");
        constraintName.append(listClassTypeName);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(fieldConstraintFlatInfo.getName()).append("_").append(constraintName.toString());
        if (constraintInfo.getConstraintInListIndex() != null) {
            stringBuilder.append("_").append(constraintInfo.getConstraintInListIndex());
        }

        return stringBuilder.toString();
    }
}
