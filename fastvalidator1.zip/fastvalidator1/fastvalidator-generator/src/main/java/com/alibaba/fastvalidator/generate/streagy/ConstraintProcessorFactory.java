package com.alibaba.fastvalidator.generate.streagy;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;


/**
 * Constraint(Mirror or Annotation type) processor factory
 *
 * @author: jasen.zhangj
 * @date: 16/11/9.
 */
public class ConstraintProcessorFactory {

    private static final Map<Class, ConstraintProcessor> PROCESSOR_MAP = new HashMap<>();

    public static ConstraintProcessor getConstraintProcessor(Object object){
        Class<?> aClass = object.getClass();
        if (PROCESSOR_MAP.containsKey(aClass)){
            return PROCESSOR_MAP.get(aClass);
        }

        if (object instanceof Annotation){
            PROCESSOR_MAP.put(aClass, new AnnotationProcessor());
        } else {
            PROCESSOR_MAP.put(aClass, new AnnotationMirrorProcessor());
        }

        return PROCESSOR_MAP.get(aClass);
    }
}
