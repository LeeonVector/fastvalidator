package com.alibaba.fastvalidator.generate.meta;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.TypeElement;
import javax.lang.model.type.MirroredTypeException;

import com.alibaba.fastvalidator.constraints.ConstraintDesc;
import com.alibaba.fastvalidator.constraints.ConstraintDescList;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.logging.Logger;

/**
 * information of the Bean with {@link com.alibaba.fastvalidator.constraints.ValidateBean}
 *
 * @author: jasen.zhangj
 * @date: 15/11/3.
 */
public class ValidateBeanInfo {

    /***
     * Bean class type
     */
    private TypeElement               classTypeElement;

    /***
     * annotated fields
     */
    private List<Element>             annotatedFields  = new ArrayList();

    /***
     * unannotated fields
     */
    private List<Element>             unAnnotatedFields  = new ArrayList();

    /***
     * key: field name; value: field's annotations
     */
    private Map<String, List<Object>> fieldAnnotations = new HashMap();

    public ValidateBeanInfo(TypeElement typeElement) {
        classTypeElement = typeElement;
    }

    public void add(Element element, Object annotation) {
        String fieldName = element.getSimpleName().toString();
        if (fieldAnnotations.containsKey(fieldName)) {
            fieldAnnotations.get(fieldName).add(annotation);
        } else {
            annotatedFields.add(element);
            List<Object> fieldAnnotationList = new ArrayList();
            fieldAnnotationList.add(annotation);
            fieldAnnotations.put(fieldName, fieldAnnotationList);
        }
    }

    public void addNonAnnotatedFieldElement(Element element){
        unAnnotatedFields.add(element);
    }

    private static boolean isBooleanType(Element element) {
        return element.asType().toString().equals("boolean");
    }

    public String getGetMethodName(String fieldName) {
        Element element = getElement0(fieldName, annotatedFields);
        if (element == null) {
            element = getElement0(fieldName, unAnnotatedFields);
            if (element == null) {
                Logger.error(fieldName + " will not reach here");
            }
        }

        return isBooleanType(element) ? "is"
                + StringUtils.capitalize(fieldName) : "get"
                + StringUtils.capitalize(fieldName);
    }

    public String getQualifiedClassName() {
        return classTypeElement.getQualifiedName().toString();
    }

    public Element getElement(String fieldName) {
        return getElement0(fieldName, annotatedFields);
    }

    private Element getElement0(String fieldName, List<Element> list) {
        Element element = null;
        for (Element annotatedField : list) {
            if (annotatedField.getSimpleName().toString().equals(fieldName)) {
                element = annotatedField;
                break;
            }
        }

        return element;
    }

    public List<FieldConstraintFlatInfo> getSortedFieldFlatInfo(ValidatorBeanGeneratorContext context) {
        List result = new ArrayList();
        for (Map.Entry<String, List<Object>> stringListEntry : fieldAnnotations.entrySet()) {
            String fieldName = stringListEntry.getKey();
            List<Object> annotations = stringListEntry.getValue();
            Object constraintDesc;
            if ((constraintDesc = hasConstraintDescAnnotation(annotations)) != null) {
                Class<? extends Annotation> clazz = ((Annotation) constraintDesc).annotationType();
                if (clazz == ConstraintDesc.class) {
                    for (Object annotation : annotations) {
                        if (!hasConstraintDesc(annotation)) {
                            addAnnotation(result, fieldName, annotation, (ConstraintDesc) constraintDesc, context);
                        }
                    }
                } else if (clazz == ConstraintDescList.class) {
                    ConstraintDescList vList = (ConstraintDescList) constraintDesc;
                    ConstraintDesc[] validateDescs = vList.value();
                    for (Object annotation : annotations) {
                        if (hasConstraintDesc(annotation)) {
                            continue;
                        }

                        ConstraintDesc matchDesc = null;
                        for (ConstraintDesc desc : validateDescs) {
                            if (match(((Annotation) annotation).annotationType(), desc)) {
                                matchDesc = desc;
                                break;
                            } else {
                                continue;
                            }
                        }

                        if (matchDesc != null) {
                            addAnnotation(result, fieldName, annotation, matchDesc, context);
                        } else {
                            addAnnotation(result, fieldName, annotation, context);
                        }
                    }

                }
            } else {
                for (Object annotation : annotations) {
                    addAnnotation(result, fieldName, annotation, context);
                }
            }
        }

        Collections.sort(result);
        return result;
    }

    private void addAnnotation(List result, String fieldName, Object annotation,
                               ValidatorBeanGeneratorContext context) {
        addAnnotation(result, fieldName, annotation, null, context);
    }

    private void addAnnotation(List result, String fieldName, Object annotation, ConstraintDesc matchDesc,
                               ValidatorBeanGeneratorContext context) {
        if (matchDesc != null) {
            if (annotation instanceof AnnotationMirror) {
                List<? extends AnnotationValue> annotationArrayValue = context.getAnnotationMirrorHelper().getAnnotationArrayValue((AnnotationMirror) annotation,
                                                                                                                                   "value");
                // handle annotation annotationArrayValue value
                if (annotationArrayValue == null || annotationArrayValue.isEmpty()) {
                    result.add(new FieldConstraintFlatInfo(fieldName, annotation, matchDesc.order(), matchDesc.code()));
                } else {
                    int i = 0;
                    for (AnnotationValue annotationValue : annotationArrayValue) {
                        result.add(new FieldConstraintFlatInfo(fieldName, annotationValue, matchDesc.order(),
                                                               matchDesc.code(), i++, annotation));
                    }
                }
            } else {
                result.add(new FieldConstraintFlatInfo(fieldName, annotation, matchDesc.order(), matchDesc.code()));
            }
        } else {
            if (annotation instanceof AnnotationMirror) {
                List<? extends AnnotationValue> annotationArrayValue = context.getAnnotationMirrorHelper().getAnnotationArrayValue((AnnotationMirror) annotation,
                                                                                                                                   "value");
                // handle annotation annotationArrayValue value
                if (annotationArrayValue == null || annotationArrayValue.isEmpty()) {
                    result.add(new FieldConstraintFlatInfo(fieldName, annotation));
                } else {
                    int i = 0;
                    for (AnnotationValue annotationValue : annotationArrayValue) {
                        result.add(new FieldConstraintFlatInfo(fieldName, annotationValue, i++, annotation));
                    }
                }
            } else {
                result.add(new FieldConstraintFlatInfo(fieldName, annotation));
            }
        }
    }

    protected boolean match(Class<? extends Annotation> constraint, ConstraintDesc constraintDesc) {
        String constrainClassName = constraint.getName();
        String descConstrainClassName;
        try {
            descConstrainClassName = constraintDesc.constraint().getName();
        } catch (MirroredTypeException e) {
            descConstrainClassName = e.getTypeMirror().toString();
        }

        return constrainClassName.equals(descConstrainClassName);
    }

    protected Object hasConstraintDescAnnotation(List<Object> constraintList) {
        for (Object o : constraintList) {
            if (hasConstraintDesc(o)) {
                return o;
            }
        }

        return null;
    }

    protected boolean hasConstraintDesc(Object o) {
        if (o instanceof Annotation) {
            Class<? extends Annotation> clazz = ((Annotation) o).annotationType();
            return clazz == ConstraintDesc.class || clazz == ConstraintDescList.class;
        } else if (o instanceof AnnotationMirror) {
            // ((AnnotationMirror)o).getAnnotationType().toString().indexOf("ConstraintDesc.List");
            return false;
        } else {
            return false;
        }
    }

    public TypeElement getClassTypeElement() {
        return classTypeElement;
    }

    public List<Element> getAnnotatedFields() {
        return annotatedFields;
    }

    public Map<String, List<Object>> getFieldAnnotations() {
        return fieldAnnotations;
    }

    public static class FieldConstraintFlatInfo implements Comparable {

        String  name;
        Object  constraint;
        int     order = 0;
        String  code;
        Integer constraintInListIndex;
        Object listAnnotation;

        FieldConstraintFlatInfo(String name, Object constraint) {
            this(name, constraint, null, null);
        }

        FieldConstraintFlatInfo(String name, Object constraint, Integer constraintInListIndex, Object listAnnotation) {
            this.name = name;
            this.constraint = constraint;
            this.constraintInListIndex = constraintInListIndex;
            this.listAnnotation = listAnnotation;
        }

        FieldConstraintFlatInfo(String name, Object constraint, int order, String code) {
            this(name, constraint, order, code, null, null);
        }

        FieldConstraintFlatInfo(String name, Object constraint, int order, String code, Integer constraintInListIndex, Object listAnnotation) {
            this.name = name;
            this.constraint = constraint;
            this.order = order;
            this.code = code;
            this.constraintInListIndex = constraintInListIndex;
            this.listAnnotation = listAnnotation;
        }

        @Override
        public int compareTo(Object o) {
            if (!(o instanceof FieldConstraintFlatInfo)) {
                return -1;
            }
            FieldConstraintFlatInfo fieldConstraintFlatInfo = (FieldConstraintFlatInfo) o;
            if (((FieldConstraintFlatInfo) o).order == 0 && this.order == 0) {
                return this.name.compareTo(fieldConstraintFlatInfo.name);
            } else {
                return ((FieldConstraintFlatInfo) o).order > this.order ? 1 : -1;
            }
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Object getConstraint() {
            return constraint;
        }

        public void setConstraint(Object constraint) {
            this.constraint = constraint;
        }

        public int getOrder() {
            return order;
        }

        public void setOrder(int order) {
            this.order = order;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public Integer getConstraintInListIndex() {
            return constraintInListIndex;
        }

        @Override
        public String toString() {
            final StringBuffer sb = new StringBuffer("FieldConstraintFlatInfo{");
            sb.append("name='").append(name).append('\'');
            sb.append(", constraint=").append(constraint);
            sb.append(", order=").append(order);
            sb.append(", code='").append(code).append('\'');
            sb.append('}');
            return sb.toString();
        }

        public Object getListAnnotation() {
            return listAnnotation;
        }
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ValidateBeanInfo{");
        sb.append("classType=").append(classTypeElement);
        sb.append(", annotatedFields=").append(annotatedFields);
        sb.append(", fieldAnnotations=").append(fieldAnnotations);
        sb.append('}');
        return sb.toString();
    }
}
