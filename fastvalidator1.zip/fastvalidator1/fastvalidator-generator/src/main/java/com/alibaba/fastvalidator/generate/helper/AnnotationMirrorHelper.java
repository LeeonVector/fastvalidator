package com.alibaba.fastvalidator.generate.helper;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ElementVisitor;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.ArrayType;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.TypeKind;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Elements;
import javax.lang.model.util.SimpleAnnotationValueVisitor6;
import javax.lang.model.util.SimpleElementVisitor6;
import javax.lang.model.util.SimpleTypeVisitor6;
import javax.lang.model.util.Types;
import javax.validation.OverridesAttribute;

import com.alibaba.fastvalidator.generate.logging.Logger;

/**
 * A helper class providing some useful methods to work with types from the JSR-269-API.
 *
 * @author jasen.zhangj
 */
public class AnnotationMirrorHelper {

    private Elements                        elementUtils;

    private Types                           typeUtils;

    private final Map<Class<?>, TypeMirror> primitiveMirrors;

    private static final Map<String, Class> primitiveTypeMap    = new HashMap<String, Class>(8);

    public static final String              OVERRIDE_ATTRIBUTES = "OVERRIDE_ATTRIBUTES";

    public AnnotationMirrorHelper(Elements elementUtils, Types typeUtils) {

        this.elementUtils = elementUtils;
        this.typeUtils = typeUtils;

        Map<Class<?>, TypeMirror> tempPrimitiveMirrors = new HashMap<Class<?>, TypeMirror>();

        tempPrimitiveMirrors.put(Boolean.TYPE, typeUtils.getPrimitiveType(TypeKind.BOOLEAN));
        tempPrimitiveMirrors.put(Character.TYPE, typeUtils.getPrimitiveType(TypeKind.CHAR));
        tempPrimitiveMirrors.put(Byte.TYPE, typeUtils.getPrimitiveType(TypeKind.BYTE));
        tempPrimitiveMirrors.put(Short.TYPE, typeUtils.getPrimitiveType(TypeKind.SHORT));
        tempPrimitiveMirrors.put(Integer.TYPE, typeUtils.getPrimitiveType(TypeKind.INT));
        tempPrimitiveMirrors.put(Long.TYPE, typeUtils.getPrimitiveType(TypeKind.LONG));
        tempPrimitiveMirrors.put(Float.TYPE, typeUtils.getPrimitiveType(TypeKind.FLOAT));
        tempPrimitiveMirrors.put(Double.TYPE, typeUtils.getPrimitiveType(TypeKind.DOUBLE));

        primitiveMirrors = Collections.unmodifiableMap(tempPrimitiveMirrors);

        primitiveTypeMap.put(boolean.class.getSimpleName(), boolean.class);
        primitiveTypeMap.put(byte.class.getSimpleName(), byte.class);
        primitiveTypeMap.put(char.class.getSimpleName(), char.class);
        primitiveTypeMap.put(double.class.getSimpleName(), double.class);
        primitiveTypeMap.put(float.class.getSimpleName(), float.class);
        primitiveTypeMap.put(int.class.getSimpleName(), int.class);
        primitiveTypeMap.put(long.class.getSimpleName(), long.class);
        primitiveTypeMap.put(short.class.getSimpleName(), short.class);
    }

    private static final ElementVisitor<TypeElement, Void> TYPE_ELEMENT_VISITOR = new SimpleElementVisitor6<TypeElement, Void>() {

        @Override
        protected TypeElement defaultAction(Element e, Void p) {
            throw new IllegalArgumentException();
        }

        @Override
        public TypeElement visitType(TypeElement e, Void p) {
            return e;
        }
    };

    /**
     * Returns the given {@link Element} instance as {@link TypeElement}.
     * <p>
     * This method is functionally equivalent to an {@code instanceof} check and a cast, but should always be used over
     * that idiom as instructed in the documentation for {@link Element}.
     *
     * @throws NullPointerException if {@code element} is {@code null}
     * @throws IllegalArgumentException if {@code element} isn't a {@link TypeElement}.
     */
    public static TypeElement asType(Element element) {
        return element.accept(TYPE_ELEMENT_VISITOR, null);
    }

    private static final ElementVisitor<VariableElement, Void> VARIABLE_ELEMENT_VISITOR = new SimpleElementVisitor6<VariableElement, Void>() {

        @Override
        protected VariableElement defaultAction(Element e, Void p) {
            throw new IllegalArgumentException();
        }

        @Override
        public VariableElement visitVariable(VariableElement e, Void p) {
            return e;
        }
    };

    /**
     * Returns the given {@link Element} instance as {@link VariableElement}.
     * <p>
     * This method is functionally equivalent to an {@code instanceof} check and a cast, but should always be used over
     * that idiom as instructed in the documentation for {@link Element}.
     *
     * @throws NullPointerException if {@code element} is {@code null}
     * @throws IllegalArgumentException if {@code element} isn't a {@link VariableElement}.
     */
    public static VariableElement asVariable(Element element) {
        return element.accept(VARIABLE_ELEMENT_VISITOR, null);
    }

    /**
     * Returns a list containing those annotation mirrors from the input list, which are of type
     * <code>annotationType</code>. The input collection remains untouched.
     *
     * @param annotationMirrors A list of annotation mirrors.
     * @param annotationType The type to be compared against.
     * @return A list with those annotation mirrors from the input list, which are of type <code>annotationType</code>.
     * May be empty but never null.
     */
    public List<AnnotationMirror> filterByType(List<? extends AnnotationMirror> annotationMirrors,
                                               TypeMirror annotationType) {

        List<AnnotationMirror> theValue = new ArrayList<AnnotationMirror>();

        if (annotationMirrors == null || annotationType == null) {
            return theValue;
        }

        for (AnnotationMirror oneAnnotationMirror : annotationMirrors) {

            if (typeUtils.isSameType(oneAnnotationMirror.getAnnotationType(), annotationType)) {
                theValue.add(oneAnnotationMirror);
            }
        }

        return theValue;
    }

    /**
     * Returns that mirror from the given list of annotation mirrors that represents the annotation type specified by
     * the given class.
     *
     * @param annotationMirrors A list of annotation mirrors.
     * @param annotationClazz The class of the annotation of interest.
     * @return The mirror from the given list that represents the specified annotation or null, if the given list
     * doesn't contain such a mirror.
     */
    public AnnotationMirror getMirror(List<? extends AnnotationMirror> annotationMirrors,
                                      Class<? extends Annotation> annotationClazz) {

        return getMirror(annotationMirrors, annotationClazz.getCanonicalName());
    }

    /**
     * Returns that mirror from the given list of annotation mirrors that represents the annotation type specified by
     * the given class.
     *
     * @param annotationMirrors A list of annotation mirrors.
     * @param annotationTypeName The FQN of the annotation of interest.
     * @return The mirror from the given list that represents the specified annotation or null, if the given list
     * doesn't contain such a mirror.
     */
    public AnnotationMirror getMirror(List<? extends AnnotationMirror> annotationMirrors, String annotationTypeName) {

        if (annotationMirrors == null || annotationTypeName == null) {
            return null;
        }

        TypeElement typeElement = elementUtils.getTypeElement(annotationTypeName);

        if (typeElement == null) {
            return null;
        }

        for (AnnotationMirror oneAnnotationMirror : annotationMirrors) {

            if (typeUtils.isSameType(oneAnnotationMirror.getAnnotationType(), typeElement.asType())) {
                return oneAnnotationMirror;
            }
        }

        return null;
    }

    /**
     * Returns a TypeMirror for the given class.
     *
     * @param clazz The class of interest.
     * @return A TypeMirror for the given class.
     */
    public TypeMirror getMirrorForType(Class<?> clazz) {

        if (clazz.isArray()) {
            return typeUtils.getArrayType(getMirrorForNonArrayType(clazz.getComponentType()));
        } else {
            return getMirrorForNonArrayType(clazz);
        }
    }

    private TypeMirror getMirrorForNonArrayType(Class<?> clazz) {

        TypeMirror theValue = null;

        if (clazz.isPrimitive()) {
            theValue = primitiveMirrors.get(clazz);
        } else {
            theValue = getDeclaredTypeByName(clazz.getCanonicalName());
        }

        if (theValue != null) {
            return theValue;
        } else {
            throw new AssertionError("Couldn't find a type mirror for class " + clazz);
        }
    }

    /**
     * Returns the {@link DeclaredType} for the given class name.
     *
     * @param className A fully qualified class name, e.g. "java.lang.String".
     * @return A {@link DeclaredType} representing the type with the given name, or null, if no such type exists.
     */
    public DeclaredType getDeclaredTypeByName(String className) {

        TypeElement typeElement = elementUtils.getTypeElement(className);

        return typeElement != null ? typeUtils.getDeclaredType(typeElement) : null;
    }

    /**
     * Returns the annotation value of the given annotation mirror with the given name.
     *
     * @param annotationMirror An annotation mirror.
     * @param name The name of the annotation value of interest.
     * @return The annotation value with the given name or null, if one of the input values is null or if no value with
     * the given name exists within the given annotation mirror.
     */
    public static AnnotationValue getAnnotationValue(AnnotationMirror annotationMirror, String name) {

        if (annotationMirror == null || name == null) {
            return null;
        }

        Map<? extends ExecutableElement, ? extends AnnotationValue> elementValues = annotationMirror.getElementValues();

        for (Entry<? extends ExecutableElement, ? extends AnnotationValue> oneElementValue : elementValues.entrySet()) {

            if (oneElementValue.getKey().getSimpleName().contentEquals(name)) {

                return oneElementValue.getValue();
            }
        }

        return null;
    }

    /**
     * Returns the annotation value of the given annotation mirror with the given name.
     *
     * @param annotationMirror An annotation mirror.
     * @return The annotation value with the given name or null, if one of the input values is null or if no value with
     * the given name exists within the given annotation mirror.
     */
    public static Map<String, Object> getAnnotationValue(AnnotationMirror annotationMirror) {
        if (annotationMirror == null) {
            return Collections.emptyMap();
        }

        DeclaredType annotationType = annotationMirror.getAnnotationType();
        Map<String, Object> result = new HashMap<>();

        List<OverrideAttribute> overrideAttributeList = new ArrayList<>();

        // default attribute
        List<? extends Element> annotationTypeEnclosedElements = annotationType.asElement().getEnclosedElements();
        if (annotationTypeEnclosedElements != null) {
            for (Element annotationTypeEnclosedElement : annotationTypeEnclosedElements) {
                if (annotationTypeEnclosedElement instanceof ExecutableElement) {
                    String methodName = annotationTypeEnclosedElement.getSimpleName().toString();
                    AnnotationValue defaultAnnotationValue = ((ExecutableElement) annotationTypeEnclosedElement).getDefaultValue();
                    if (defaultAnnotationValue != null) {
                        Object defaultValue = defaultAnnotationValue.getValue();
                        result.put(methodName, defaultValue);
                    }

                    List<? extends AnnotationMirror> annotationMirrors = annotationTypeEnclosedElement.getAnnotationMirrors();
                    if (annotationMirrors != null) {
                        for (AnnotationMirror mirror : annotationMirrors) {
                            String annotationClass = mirror.getAnnotationType().toString();
                            if (annotationClass.equals(OverridesAttribute.class.getName())) {
                                AnnotationValue overrideConstraint = AnnotationMirrorHelper.getAnnotationValue(mirror,
                                                                                                               "constraint");
                                AnnotationValue overrideAttributeName = AnnotationMirrorHelper.getAnnotationValue(mirror,
                                                                                                                  "name");
                                AnnotationValue index = AnnotationMirrorHelper.getAnnotationValue(mirror,
                                                                                                  "constraintIndex");

                                OverrideAttribute overrideAttribute = new OverrideAttribute();
                                overrideAttribute.setOverrideConstraint(overrideConstraint);
                                overrideAttribute.setOverrideAttributeName(overrideAttributeName);
                                overrideAttribute.setIndex(index);
                                overrideAttribute.setMethodName(methodName);

                                overrideAttributeList.add(overrideAttribute);
                            }
                        }
                    }
                }
            }
        }

        // actual attribute value
        Map<? extends ExecutableElement, ? extends AnnotationValue> elementValues = annotationMirror.getElementValues();
        if (elementValues != null) {
            for (Map.Entry<? extends ExecutableElement, ? extends AnnotationValue> entry : elementValues.entrySet()) {
                ExecutableElement executableElement = entry.getKey();
                String methodName = executableElement.getSimpleName().toString();
                AnnotationValue annotationValue = entry.getValue();
                if (annotationValue != null) {
                    Object obj = annotationValue.getValue();
                    result.put(methodName, obj);

                    if (!overrideAttributeList.isEmpty()) {
                        setOverrideAttributes(methodName, obj, overrideAttributeList);
                    }
                }
            }
        }

        if (!overrideAttributeList.isEmpty()) {
            result.put(OVERRIDE_ATTRIBUTES, overrideAttributeList);
        }

        return result;
    }

    private static void setOverrideAttributes(String methodName, Object value,
                                              List<OverrideAttribute> overrideAttributes) {
        if (overrideAttributes != null) {
            for (OverrideAttribute overrideAttribute : overrideAttributes) {
                if (overrideAttribute.getMethodName().equals(methodName)) {
                    overrideAttribute.setValue(value);
                }
            }
        }
    }

    /**
     * Returns the given annotation mirror's array-typed annotation value with the given name.
     *
     * @param annotationMirror An annotation mirror.
     * @param name The name of the annotation value of interest.
     * @return The annotation value with the given name or an empty list, if no such value exists within the given
     * annotation mirror or such a value exists but is not an array-typed one.
     */
    public List<? extends AnnotationValue> getAnnotationArrayValue(AnnotationMirror annotationMirror, String name) {

        AnnotationValue annotationValue = getAnnotationValue(annotationMirror, name);

        if (annotationValue == null) {
            return Collections.emptyList();
        }

        List<? extends AnnotationValue> theValue = annotationValue.accept(new SimpleAnnotationValueVisitor6<List<? extends AnnotationValue>, Void>() {

            @Override
            public List<? extends AnnotationValue> visitArray(List<? extends AnnotationValue> values, Void p) {
                return values;
            }

        }, null);

        return theValue != null ? theValue : Collections.<AnnotationValue> emptyList();
    }

    /**
     * <p>
     * Returns a set containing the "lowest" type per hierarchy contained in the input set. The following examples shall
     * demonstrate the behavior.
     * </p>
     * <ul>
     * <li>Input: <code>String</code>; Output: <code>String</code></li>
     * <li>Input: <code>Object</code>, <code>String</code>; Output: <code>String</code></li>
     * <li>Input: <code>Object</code>, <code>Collection</code>, <code>List</code>; Output: <code>List</code></li>
     * <li>Input: <code>Collection</code>, <code>Set</code>, <code>List</code>; Output: <code>List</code>,
     * <code>Set</code></li>
     * </ul>
     *
     * @param types A set of type mirrors.
     * @return A set with the lowest types per hierarchy or null, if the input set was null.
     */
    public Set<TypeMirror> keepLowestTypePerHierarchy(Set<TypeMirror> types) {

        if (types == null) {
            return null;
        }

        Set<TypeMirror> theValue = new HashSet<TypeMirror>();

        for (TypeMirror typeMirror1 : types) {
            boolean foundSubType = false;
            for (TypeMirror typeMirror2 : types) {
                if (!typeUtils.isSameType(typeMirror2, typeMirror1)
                    && typeUtils.isAssignable(typeMirror2, typeMirror1)) {
                    foundSubType = true;
                    continue;
                }
            }
            if (!foundSubType) {
                theValue.add(typeMirror1);
            }
        }

        return theValue;
    }

    public boolean isAssignable(Element filedElement, Class clazz, boolean checkOnlyArray) {
        TypeMirror typeMirror = filedElement.asType();
        String subClass = getFieldType(filedElement);
        if (typeMirror.getKind().isPrimitive() && primitiveTypeMap.containsKey(subClass)) {
            TypeMirror t2 = getMirrorForType(clazz);
            TypeMirror t1 = getMirrorForType(primitiveTypeMap.get(subClass));
            return typeUtils.isAssignable(t1, t2);
        } else {
            TypeMirror t1;
            TypeMirror t2;
            if (typeMirror.getKind() == TypeKind.ARRAY) {
                if (clazz.isArray()) {
                    t2 = getMirrorForType(clazz);
                } else {
                    if (checkOnlyArray) {
                        return false;
                    } else {
                        t2 = getMirrorForType(clazz);
                    }
                }

                TypeMirror tt = typeMirror.accept(new SimpleTypeVisitor6<TypeMirror, Object>() {

                    @Override
                    public TypeMirror visitArray(ArrayType t, Object o) {
                        return t.getComponentType();
                    }
                }, null);

                if (tt.getKind().isPrimitive()) {
                    t1 = typeUtils.getArrayType(getMirrorForType(primitiveTypeMap.get(tt.toString())));
                } else {
                    t1 = typeUtils.getArrayType(getDeclaredTypeByName(tt.toString()));
                }
            } else {
                t1 = getDeclaredTypeByName(subClass);
                t2 = getMirrorForType(clazz);
            }

            if (t1 == null) {
                Logger.error("can't find TypeMirror for " + subClass);
            }

            return typeUtils.isAssignable(t1, t2);
        }
    }

    /***
     * check whether the element is constraint annotation.
     *
     * @param element
     * @return true if it is.
     */
    public static boolean isConstraintAnnotation(Element element) {
        List<? extends AnnotationMirror> annotationMirrors = element.getAnnotationMirrors();
        boolean hasConstraintAnnotation = false;
        if (annotationMirrors != null) {
            for (AnnotationMirror mirror : annotationMirrors) {
                if ("javax.validation.Constraint".equals(mirror.getAnnotationType().toString())) {
                    hasConstraintAnnotation = true;
                    break;
                }
            }
        }

        TypeElement typeElement = (TypeElement) element;
        List<? extends Element> annotationMethods = typeElement.getEnclosedElements();
        boolean hasConstraintMethods = hasConstraintMethod(annotationMethods, "message")
                                       && hasConstraintMethod(annotationMethods, "groups")
                                       && hasConstraintMethod(annotationMethods, "payload");

        if (hasConstraintAnnotation && hasConstraintMethods) {
            return true;
        }

        return false;
    }

    private static boolean hasConstraintMethod(List<? extends Element> annotationMethods, String methodName) {
        if (annotationMethods != null) {
            for (Element annotationMethod : annotationMethods) {
                if (annotationMethod.getKind() == ElementKind.METHOD) {
                    ExecutableElement executableElement = (ExecutableElement) annotationMethod;
                    if (executableElement.getSimpleName().toString().equals(methodName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public String getFieldType(Element filedElement) {
        TypeMirror typeMirror = filedElement.asType();
        //typeMirror = typeUtils.capture(typeMirror);
        return typeUtils.erasure(typeMirror).toString();
    }

    public Elements getElementUtils() {
        return elementUtils;
    }

    public Types getTypeUtils() {
        return typeUtils;
    }

    /***
     * @see {@link javax.validation.OverridesAttribute}
     */
    public static class OverrideAttribute {

        AnnotationValue overrideConstraint;
        AnnotationValue overrideAttributeName;
        AnnotationValue index;
        Object          value;
        String          methodName;

        public String getMethodName() {
            return methodName;
        }

        public void setMethodName(String methodName) {
            this.methodName = methodName;
        }

        public Object getValue() {
            return value;
        }

        public void setValue(Object value) {
            this.value = value;
        }

        public AnnotationValue getOverrideConstraint() {
            return overrideConstraint;
        }

        public void setOverrideConstraint(AnnotationValue overrideConstraint) {
            this.overrideConstraint = overrideConstraint;
        }

        public AnnotationValue getOverrideAttributeName() {
            return overrideAttributeName;
        }

        public void setOverrideAttributeName(AnnotationValue overrideAttributeName) {
            this.overrideAttributeName = overrideAttributeName;
        }

        public AnnotationValue getIndex() {
            return index;
        }

        public void setIndex(AnnotationValue index) {
            this.index = index;
        }
    }
}
