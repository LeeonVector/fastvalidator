package com.alibaba.fastvalidator.generate.helper;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.groups.Default;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.generate.generator.ValidatorIsValidMethodGenerator;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;

/**
 * Helper for generate group check statement.
 *
 * @author: jasen.zhangj
 * @date: 24/03/2017.
 */
public class GroupStatementHelper {

    public static final String GROUPS = "groups";
    private static final String DEFAULT_GROUP = Default.class.getName();
    public static final ClassName CHECK_GROUP_UTILS_CLASS = ClassName.bestGuess("com.alibaba.fastvalidator.constraints.utils.ArrayUtils");

    /***
     * The statements like below:
     * <pre>
     *      if (ArrayUtils.contains(new String[]{"GroupA","GroupB",..., context.currentGroup()}) && ...)
     * </pre>
     */
    public static void addGroupMatchStatement(ConstraintInfo constraintInfo, List<Object> params, StringBuffer validMethodBody, ValidatorIsValidMethodGenerator.IsValidMethodInfo isValidMethodInfo) {
        addGroupMatchStatement0(constraintInfo.getAttributes(), params, validMethodBody, isValidMethodInfo);
    }

    /***
     * The statements like below:
     * <pre>
     *     if (ArrayUtils.contains(new String[]{"GroupA","GroupB",..., context.currentGroup()}) && ...)
     * </pre>
     */
    public static void addGroupMatchStatement(Annotation annotation, List<Object> params, StringBuffer validMethodBody, ValidatorIsValidMethodGenerator.IsValidMethodInfo isValidMethodInfo) {
        Map<String, Object> attributes = AnnotationUtils.getAnnotationParameterValues(annotation);
        addGroupMatchStatement0(attributes, params, validMethodBody, isValidMethodInfo);
    }

    public static void addGroupMatchStatement0(Map<String, Object> attributes, List<Object> params, StringBuffer validMethodBody, ValidatorIsValidMethodGenerator.IsValidMethodInfo isValidMethodInfo) {
        if (!isContainsDefaultGroup(attributes)) {
            String inGroupStatement = getGroupMatchStatement(attributes);
            if (inGroupStatement != null) {
                List newParams = new ArrayList(params);
                newParams.add(0, GroupStatementHelper.CHECK_GROUP_UTILS_CLASS);
                StringBuffer groupCheckStatement = new StringBuffer(validMethodBody);
                int bracketsIndex = groupCheckStatement.indexOf("(");
                String ifStatement = isValidMethodInfo.getNonDefaultGroupIfStatement();
                groupCheckStatement = groupCheckStatement.delete(0, bracketsIndex + 1);
                groupCheckStatement.insert(0, ifStatement + "(" + inGroupStatement + " && ");
                isValidMethodInfo.getNonDefaultGroupBuilder().addCode(groupCheckStatement.toString(), newParams.toArray());
            }
        }

    }

    private static String getGroupStatement(List<String> groups) {
        StringBuffer inGroupStatement = new StringBuffer("$T.contains(new String[]{");
        for (String group : groups) {
            inGroupStatement.append("\"").append(group).append("\"").append(",");
        }
        inGroupStatement.setLength(inGroupStatement.length() - 1);

        inGroupStatement.append("}, ").append("((FastValidatorBeanContext)context).currentGroup()").append(")");

        return inGroupStatement.toString();
    }

    /***
     * The statements like below:
     * <pre>
     *     ArrayUtils.contains(new String[]{"GroupA","GroupB",..., context.currentGroup()})
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public static String getGroupMatchStatement(Map<String, Object> attributes) {
        if (!isContainsDefaultGroup(attributes)) {
            Object groupObject = attributes.get(ConstraintInfo.GROUPS);
            List<String> groups = (List<String>) groupObject;
            return getGroupStatement(groups);
        } else {
            return null;
        }
    }

    public static boolean isContainsDefaultGroup(Map<String, Object> attrbutes) {
        Object o = attrbutes.get(GROUPS);
        if (o != null && o instanceof List) {
            return ((List) o).isEmpty() || ((List) o).contains(DEFAULT_GROUP);
        }

        return true;
    }
}
