package com.alibaba.fastvalidator.generate.generator;

import java.util.Set;

import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;

/**
 * <pre>
 * Generator template class:
 * 1. beforeGenerate
 * 2. if the annotation is constraint(eg: {@link org.hibernate.validator.constraints.NotBlank}), then invoke generateForConstraint method
 * 3. if the annotation is non constraint(eg: {@link com.alibaba.fastvalidator.constraints.Conditional}), then invoke generateForNonConstraint method
 * 4. afterGenerate
 * </pre>
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public interface Generator {

    /***
     * before generate
     *
     * @param validateBeanInfo {@link ValidateBeanInfo}
     * @param context {@link ValidatorBeanGeneratorContext}
     */
    void beforeGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context);

    /***
     * generate source code for the specify {@link ConstraintInfo}
     *
     * @param validateBeanInfo {@link ValidateBeanInfo}
     * @param context {@link ValidatorBeanGeneratorContext}
     * @param constraintInfo {@link ConstraintInfo}
     * @param fieldConstraintFlatInfo {@link com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo.FieldConstraintFlatInfo}
     * @param processor {@link ConstraintProcessor}
     */
    void generateForConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                               ConstraintInfo constraintInfo,
                               ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                               ConstraintProcessor processor);

    /***
     * generate source code for the specify {@link ValidateBeanInfo.FieldConstraintFlatInfo}
     *
     * @param validateBeanInfo {@link ValidateBeanInfo}
     * @param context {@link ValidatorBeanGeneratorContext}
     * @param fieldConstraintFlatInfo {@link com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo.FieldConstraintFlatInfo}
     */
    void generateForNonConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                  ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo);

    /***
     * after generate
     *
     * @param validateBeanInfo {@link ValidateBeanInfo}
     * @param context {@link ValidatorBeanGeneratorContext}
     */
    void afterGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context);

    /***
     * set parent generator
     *
     * @param parent parent generator
     * @return current generator
     */
    Generator setParent(Generator parent);

    Generator getParent();

    Generator addChild(Generator parent);

    Set<String> getShouldImportTypes();
}
