package com.alibaba.fastvalidator.generate.utils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * Utils for generic type.
 *
 * @author: jasen.zhangj
 * @date: 15/11/6.
 */
public class GenericUtils {

    public static Type getSuperclassTypeParameter(Class<?> subclass, int index){
        Type[] superInterfaceClasses = subclass.getGenericInterfaces();
        if (superInterfaceClasses == null || superInterfaceClasses.length == 0){
            throw new RuntimeException("Missing interface variable type parameter.");
        }

        ParameterizedType parameterized = (ParameterizedType) superInterfaceClasses[0];
        Type result = parameterized.getActualTypeArguments()[index];
        if (result instanceof  ParameterizedType){
            result = ((ParameterizedType)result).getRawType();
        }

        return result;
    }

    public static Type getSuperclassSecendTypeParameter(Class<?> subclass){
        return getSuperclassTypeParameter(subclass, 1);
    }

    public static void main(String[] args) throws ClassNotFoundException {
        String name = String[].class.getName();
        System.out.println(name);
        System.out.println(Class.forName(name));

        name = String[][].class.getName();
        System.out.println(name);
        System.out.println(Class.forName(name));
        System.out.println(getArrayDimension("String[][]"));
    }

    private static int getArrayDimension(String arrayStr){
        int dimension = 0;
        int index = -1;
        while ((index = arrayStr.indexOf("[",index+1)) >= 0){
            dimension++;
        }

        return dimension;
    }
}
