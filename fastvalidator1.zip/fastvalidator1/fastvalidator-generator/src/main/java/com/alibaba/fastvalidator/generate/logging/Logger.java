package com.alibaba.fastvalidator.generate.logging;

import javax.annotation.processing.Messager;
import javax.lang.model.element.Element;
import javax.tools.Diagnostic;
import com.alibaba.fastvalidator.generate.logging.exception.CoreConstants;
import com.alibaba.fastvalidator.generate.logging.exception.IThrowableProxy;
import com.alibaba.fastvalidator.generate.logging.exception.ThrowableProxy;
import com.alibaba.fastvalidator.generate.logging.exception.ThrowableProxyUtil;

import static com.alibaba.fastvalidator.generate.logging.exception.ThrowableProxyUtil.subjoinSTEPArray;

/**
 * This 'logger' will throw an error when compile source codes.
 *
 * @author: jasen.zhangj
 * @date: 15/12/5.
 */
public class Logger {

    public static Messager messager;

    public static void info(String msg, Object... args) {
        messager.printMessage(Diagnostic.Kind.NOTE, String.format(msg, args));
    }

    public static void error(String msg, Object... args) {
        messager.printMessage(Diagnostic.Kind.ERROR, String.format(msg, args));
    }

    public static void error(String msg, Element e, Object... args) {
        messager.printMessage(Diagnostic.Kind.ERROR, String.format(msg, args), e);
    }

    public static void error(String msg, Throwable throwable) {
        messager.printMessage(Diagnostic.Kind.ERROR, msg + " -> " + getFormateThrowableMessage(throwable));
    }

    public static void error(String msg, Throwable throwable, Element e) {
        messager.printMessage(Diagnostic.Kind.ERROR, msg + " -> " + getFormateThrowableMessage(throwable), e);
    }

    private static String getFormateThrowableMessage(Throwable throwable) {
        ThrowableProxy throwableProxy = new ThrowableProxy(throwable);
        throwableProxy.calculatePackagingData();
        return throwableProxyToString(throwableProxy);
    }

    protected static String throwableProxyToString(IThrowableProxy tp) {
        StringBuilder sb = new StringBuilder(1024);

        recursiveAppend(sb, null, ThrowableProxyUtil.REGULAR_EXCEPTION_INDENT, tp);
        return sb.toString();
    }

    private static void recursiveAppend(StringBuilder sb, String prefix, int indent, IThrowableProxy tp) {
        if (tp == null) return;
        subjoinFirstLine(sb, prefix, indent, tp);
        sb.append(CoreConstants.LINE_SEPARATOR);
        subjoinSTEPArray(sb, indent, tp);
        IThrowableProxy[] suppressed = tp.getSuppressed();
        if (suppressed != null) {
            for (IThrowableProxy current : suppressed) {
                recursiveAppend(sb, CoreConstants.SUPPRESSED, indent + ThrowableProxyUtil.SUPPRESSED_EXCEPTION_INDENT,
                                current);
            }
        }
        recursiveAppend(sb, CoreConstants.CAUSED_BY, indent, tp.getCause());
    }

    private static void subjoinFirstLine(StringBuilder buf, String prefix, int indent, IThrowableProxy tp) {
        ThrowableProxyUtil.indent(buf, indent - 1);
        if (prefix != null) {
            buf.append(prefix);
        }
        subjoinExceptionMessage(buf, tp);
    }

    private static void subjoinExceptionMessage(StringBuilder buf, IThrowableProxy tp) {
        buf.append(tp.getClassName()).append(": ").append(tp.getMessage());
    }

}
