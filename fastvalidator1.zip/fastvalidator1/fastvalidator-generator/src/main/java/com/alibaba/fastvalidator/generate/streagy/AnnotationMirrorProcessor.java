package com.alibaba.fastvalidator.generate.streagy;

import java.lang.annotation.Annotation;
import java.util.List;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;
import javax.validation.ConstraintValidator;

import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.CompostedValidator;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationDescriptor;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationFactory;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageInterpolatorHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.helper.AnnotationMirrorHelper;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.MethodSpec;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;

/**
 * processor for annotation mirror.
 *
 * @author: jasen.zhangj
 * @date: 16/11/9.
 */
public class AnnotationMirrorProcessor extends ConstraintProcessor<AnnotationMirror> {

    @Override
    public ConstraintInfo getConstraintDescriptor(AnnotationMirror type) {
        return ConstraintInfo.build(type);
    }

    @Override
    public ClassName getConstraintClassName(ConstraintInfo constraintInfo) {
        return ClassName.bestGuess(constraintInfo.getConstraintClass());
    }

    @Override
    public ClassName getConstraintClassName(AnnotationMirror constraintList) {
        return ClassName.bestGuess(constraintList.getAnnotationType().toString());
    }

    @Override
    public String getValidatorFieldName(ConstraintInfo constraintInfo,
                                        ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(fieldConstraintFlatInfo.getName()).append("_").append(constraintInfo.getConstraintSimpleClass()).append("_Validator");
        if (fieldConstraintFlatInfo.getConstraintInListIndex() != null) {
            stringBuilder.append("_").append(fieldConstraintFlatInfo.getConstraintInListIndex());
        }
        return stringBuilder.toString();
    }

    @Override
    public String interpolateMessage(ConstraintInfo constraintInfo) {
        String message = (String) constraintInfo.getAttribute("message");
        message = MessageInterpolatorHelper.interpolate(message, constraintInfo.getAttributes());

        return message;
    }

    @Override
    public void setConstraintValidatorClass(ConstraintInfo constraintInfo, ValidateBeanInfo validateBeanInfo,
                                            String fieldName, ValidatorBeanGeneratorContext context) {
        if (StringUtils.isNotBlank(constraintInfo.getStrConstraintValidator())) {
            for (ConstraintInfo descriptor : constraintInfo.getComposingConstraints()) {
                setConstraintValidatorClass(descriptor, validateBeanInfo, fieldName, context);
            }
            return;
        }

        String annotationClass = constraintInfo.getConstraintClass();
        List<Class<? extends ConstraintValidator<Annotation, ?>>> constraintValidatorClasses = constraintInfo.getDefaultValidatorClasses(annotationClass);

        setConstraintValidator0(constraintInfo, validateBeanInfo, fieldName, context, annotationClass, constraintValidatorClasses);
    }



    @Override
    public boolean isEachCommonValidator(ConstraintInfo constraintInfo) {
        return constraintInfo.getStrConstraintValidator() != null
               && constraintInfo.getStrConstraintValidator().equals(EACH_VALIDATOR);
    }

    @Override
    public ClassName getConstraintValidatorClass(ConstraintInfo constraintInfo) {
        String constraintValidatorClass = constraintInfo.getStrConstraintValidator();
        return constraintValidatorClass != null ? ClassName.bestGuess(constraintValidatorClass) : null;
    }

    @Override
    public ClassName getRootConstraintValidatorClass(ConstraintInfo constraintInfo) {
        String constraintValidatorClass = constraintInfo.isComposingConstratin() ? CompostedValidator.class.getName() : constraintInfo.getStrConstraintValidator();
        return ClassName.bestGuess(constraintValidatorClass);
    }

    @Override
    public boolean hasOverrideAttributes(ConstraintInfo parentConstraintInfo) {
        return !parentConstraintInfo.getOverrideAttributesMirror().isEmpty();
    }

    @Override
    public void generateOverrideAttribute(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                          MethodSpec.Builder initializeMethodBuilder, ConstraintInfo constraintInfo,
                                          String annotationFieldName, ConstraintInfo parentConstraintInfo) {
        String validatorFieldName = getValidatorFieldName(parentConstraintInfo, fieldConstraintFlatInfo);
        List<AnnotationMirrorHelper.OverrideAttribute> overrideAttributes = parentConstraintInfo.getOverrideAttributesMirror();
        String proxyFieldName = getProxyFieldName(constraintInfo, fieldConstraintFlatInfo);
        String parrentAnnotationFieldName = getAnnotationFieldName(fieldConstraintFlatInfo, parentConstraintInfo);
        initializeMethodBuilder.addStatement("$T $L = AnnotationDescriptor.getInstance($L)",
                AnnotationDescriptor.class, proxyFieldName, annotationFieldName);

        for (AnnotationMirrorHelper.OverrideAttribute overrideAttribute : overrideAttributes) {
            AnnotationValue annotationValue = overrideAttribute.getOverrideConstraint();
            if (annotationValue != null
                && annotationValue.getValue().toString().equals(constraintInfo.getConstraintClass())) {
                String overrideAttributeName= overrideAttribute.getOverrideAttributeName().getValue().toString();

                initializeMethodBuilder.addStatement("$L.setValue($S, $T.readAttribute($L,$S))", proxyFieldName,
                        overrideAttributeName, AnnotationUtils.class, parrentAnnotationFieldName,
                        overrideAttribute.getMethodName());

            }

        }

        initializeMethodBuilder.addStatement("$L.addComposingConstraintValidator($T.create($L), new $T())",
                validatorFieldName, AnnotationFactory.class, proxyFieldName,
                getConstraintValidatorClass(constraintInfo));
    }
}
