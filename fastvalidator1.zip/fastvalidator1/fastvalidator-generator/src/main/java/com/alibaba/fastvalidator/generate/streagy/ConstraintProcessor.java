package com.alibaba.fastvalidator.generate.streagy;

import java.util.List;
import javax.lang.model.element.Element;
import javax.validation.ConstraintValidator;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.helper.AnnotationMirrorHelper;
import com.alibaba.fastvalidator.generate.javapoet.ClassName;
import com.alibaba.fastvalidator.generate.javapoet.MethodSpec;
import com.alibaba.fastvalidator.generate.logging.Logger;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.utils.GenericUtils;

/**
 * abstract process for common validate bean generator.
 *
 * @author: jasen.zhangj
 * @date: 16/11/9.
 */
public abstract class ConstraintProcessor<T> {

    protected static final String EACH_VALIDATOR = CommonEachValidator.class.getName();

    /***
     * Get the constraint information by annotation type or annotation mirror.
     * 
     * @param type annotation type or annotation mirror.
     * @return {@link ConstraintInfo}
     */
    public abstract ConstraintInfo getConstraintDescriptor(T type);

    /***
     * Get constraint class name.
     * 
     * @param constraintInfo {@link ConstraintInfo}
     * @return constraint class name.
     */
    public abstract ClassName getConstraintClassName(ConstraintInfo constraintInfo);

    /***
     * Get constraint class name for constraint list.
     *
     * @param constraintList {@link ConstraintInfo}
     * @return constraint class name.
     */
    public abstract ClassName getConstraintClassName(T constraintList);


    /***
     * get field's name in validator source codes.
     *
     * @param constraintInfo {@link ConstraintInfo}
     * @param fieldConstraintFlatInfo field constraint information
     * @return field's validator name
     */
    public abstract String getValidatorFieldName(ConstraintInfo constraintInfo,
                                                 ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo);

    /***
     * interpolate message in constraint annotation.
     *
     * @param constraintInfo {@link ConstraintInfo}
     * @return interpolated message
     */
    public abstract String interpolateMessage(ConstraintInfo constraintInfo);

    /***
     * lookup constraint validator class and set it for {@link ConstraintInfo}
     *
     * @param constraintInfo {@link ConstraintInfo}
     * @param validateBeanInfo validating java bean information
     * @param fieldName filed name
     * @param context {@link ValidatorBeanGeneratorContext}
     */
    public abstract void setConstraintValidatorClass(ConstraintInfo constraintInfo, ValidateBeanInfo validateBeanInfo,
                                                     String fieldName, ValidatorBeanGeneratorContext context);

    /***
     * check whether it is a {@link CommonEachValidator}
     *
     * @param constraintInfo {@link ConstraintInfo}
     * @return true if it is
     */
    public abstract boolean isEachCommonValidator(ConstraintInfo constraintInfo);

    /***
     * get constraint validator class name to generate source codes.
     * 
     * @param constraintInfo {@link ConstraintInfo}
     * @return constraint validator class name
     */
    public abstract ClassName getConstraintValidatorClass(ConstraintInfo constraintInfo);

    /***
     * get constraint validator class name. May be is a
     * {@link com.alibaba.fastvalidator.constraints.validator.CompostedValidator}
     * 
     * @param constraintInfo {@link ConstraintInfo}
     * @return constraint validator class name
     */
    public abstract ClassName getRootConstraintValidatorClass(ConstraintInfo constraintInfo);

    /***
     * check whether the parent constraint has {@link javax.validation.OverridesAttribute}
     * 
     * @param parentConstraintInfo parent constraint
     * @return true if it has
     */
    public abstract boolean hasOverrideAttributes(ConstraintInfo parentConstraintInfo);

    /***
     * generate override attribute statement.
     * 
     * @param fieldConstraintFlatInfo
     * @param initializeMethodBuilder
     * @param constraintInfo
     * @param annotationFieldName
     * @param parentConstraintInfo
     */
    public abstract void generateOverrideAttribute(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                                   MethodSpec.Builder initializeMethodBuilder,
                                                   ConstraintInfo constraintInfo, String annotationFieldName,
                                                   ConstraintInfo parentConstraintInfo);

    /***
     * Get filed name for a specifi annotation
     * @param fieldConstraintFlatInfo
     * @param constraintInfo
     * @return
     */
    public String getAnnotationFieldName(ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                            ConstraintInfo constraintInfo) {
        StringBuilder constraintName = new StringBuilder();
        ConstraintInfo currentConstraintInfo = constraintInfo;

        // NotEmpty_NotNull
        while (constraintInfo.getParent() != null) {
            ClassName parentAnnotationType = getConstraintClassName(constraintInfo.getParent());
            if (constraintName.length() > 0) {
                constraintName.insert(0, "_");
                constraintName.insert(0, parentAnnotationType.simpleName());
            } else {
                constraintName.append(parentAnnotationType.simpleName());
                constraintName.append("_");
            }

            constraintInfo = constraintInfo.getParent();
        }

        ClassName annotationType = getConstraintClassName(currentConstraintInfo);
        constraintName.append(annotationType.simpleName());

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(fieldConstraintFlatInfo.getName()).append("_").append(constraintName.toString());
        if (constraintInfo.getConstraintInListIndex() != null) {
            stringBuilder.append("_").append(constraintInfo.getConstraintInListIndex());
        }

        return stringBuilder.toString();
    }

    protected String getProxyFieldName(ConstraintInfo constraintInfo,
                                       ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getValidatorFieldName(constraintInfo, fieldConstraintFlatInfo)).append("_Proxy");
        if (fieldConstraintFlatInfo.getConstraintInListIndex() != null) {
            stringBuilder.append("_").append(fieldConstraintFlatInfo.getConstraintInListIndex());
        }
        return stringBuilder.toString();
    }

    protected Class<? extends ConstraintValidator> getConstrainValidatorClass(Element filedElement,
                                                                            List<? extends Class<? extends ConstraintValidator<?, ?>>> validatorClasses,
                                                                            Object annotationClass,
                                                                            AnnotationMirrorHelper annotationApiUtil) {
        Class validatorClass = null;
        // exact match
        for (Class clazz : validatorClasses) {
            Class validatorType = (Class) GenericUtils.getSuperclassSecendTypeParameter(clazz);
            if (annotationApiUtil.isAssignable(filedElement, validatorType, false)) {
                validatorClass = clazz;
                break;
            }
        }

        // fuzzy match
        if (validatorClass == null) {
            for (Class clazz : validatorClasses) {
                Class validatorType = (Class) GenericUtils.getSuperclassSecendTypeParameter(clazz);
                if (annotationApiUtil.isAssignable(filedElement, validatorType, true)) {
                    validatorClass = clazz;
                    break;
                }
            }
        }

        if (validatorClass == null) {
            String className = filedElement.getEnclosingElement().asType().toString();
            Logger.error(" can't find constraint validator for " + annotationClass + " for field " + className + "."
                    + filedElement.getSimpleName().toString());
        }

        return validatorClass;
    }

    protected void setConstraintValidator0(ConstraintInfo constraintInfo, ValidateBeanInfo validateBeanInfo, String fieldName, ValidatorBeanGeneratorContext context, Object annotationClass, List<? extends Class<? extends ConstraintValidator<?, ?>>> constraintValidatorClasses) {
        if (constraintValidatorClasses == null && !constraintInfo.isComposingConstratin()) {
            Logger.error("the annotation(%s) is not valid, it must annotation with @Constraint and must has a validator.",
                    annotationClass);
        }

        Class<? extends ConstraintValidator> constraintValidatorClass = null;
        AnnotationMirrorHelper annotationMirrorHelper = context.getAnnotationMirrorHelper();
        Element element = validateBeanInfo.getElement(fieldName);
        if (constraintValidatorClasses != null && constraintValidatorClasses.size() > 1) {
            constraintValidatorClass = getConstrainValidatorClass(element, constraintValidatorClasses, annotationClass,
                                                                  annotationMirrorHelper);
        } else {
            if (constraintValidatorClasses != null && constraintValidatorClasses.size() == 1) {
                constraintValidatorClass = constraintValidatorClasses.get(0);
                Class validatorType = (Class) GenericUtils.getSuperclassSecendTypeParameter(constraintValidatorClass);
                if (validatorType == null){
                    Logger.error("the ConstraintValidator: %s  must be ConstraintValidator<SomeAnnotation, SomeObject> type", constraintValidatorClass);
                }

                if (!annotationMirrorHelper.isAssignable(element, validatorType, false)) {
                    Logger.error("the annotation(%s) can't apply to the field:%s with type %s of %s",
                            annotationClass, fieldName, element.asType().toString(), validateBeanInfo.getQualifiedClassName());
                }
            }
        }

        constraintInfo.setConstraintValidator(constraintValidatorClass);

        if (constraintInfo.isComposingConstratin()) {
            for (ConstraintInfo descriptor : constraintInfo.getComposingConstraints()) {
                setConstraintValidatorClass(descriptor, validateBeanInfo, fieldName, context);
            }
        } else if (constraintValidatorClass == null) {
            if (constraintValidatorClasses.isEmpty()) {
                Logger.error("the annotation(%s) is not valid, it must annotation with @Constraint and must has a validator or annotated with another annotation with @Constraint.",
                        annotationClass);
            } else {
                Logger.error("the annotation(%s) can't apply to the field:%s with type %s of %s",
                        annotationClass, fieldName, element.asType().toString(), validateBeanInfo.getQualifiedClassName());
            }
        }
    }
}
