package com.alibaba.fastvalidator.generate.logging.exception;

/**
 * Throwable proxy
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public interface IThrowableProxy {

    String getMessage();

    String getClassName();

    StackTraceElementProxy[] getStackTraceElementProxyArray();

    int getCommonFrames();

    IThrowableProxy getCause();

    IThrowableProxy[] getSuppressed();

}
