package com.alibaba.fastvalidator.generate.generator;

import java.util.List;

import javax.lang.model.element.AnnotationMirror;
import javax.lang.model.element.AnnotationValue;

import com.alibaba.fastvalidator.constraints.Import;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;

/**
 * Generator for {@link com.alibaba.fastvalidator.constraints.Import} and
 * {@link com.alibaba.fastvalidator.constraints.Import.List}
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public class ImportGenerator extends DefaultGenerator {

    public static final String IMPORT_LIST_CLASS_NAME = StringUtils.replace(Import.List.class.getName(), "$", ".");

    @Override
    public void beforeGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        super.beforeGenerate(validateBeanInfo, context);

        List<? extends AnnotationMirror> annotationMirrorList = validateBeanInfo.getClassTypeElement().getAnnotationMirrors();
        if (annotationMirrorList != null) {
            for (AnnotationMirror annotationMirror : annotationMirrorList) {
                if (isImport(annotationMirror) || isImportList(annotationMirror)) {
                    if (isImportList(annotationMirror)) {
                        List<? extends AnnotationValue> importList = context.getAnnotationMirrorHelper().getAnnotationArrayValue(annotationMirror,
                                                                                                                                 "value");
                        if (importList != null) {
                            for (AnnotationValue annotationValue : importList) {
                                addImport(context, (AnnotationMirror) annotationValue.getValue());
                            }
                        }
                    } else {
                        addImport(context, annotationMirror);
                    }
                }
            }
        }
    }

    protected void addImport(ValidatorBeanGeneratorContext context, AnnotationMirror annotationMirror) {
        if (isImport(annotationMirror)) {
            AnnotationValue annotationValue = context.getAnnotationMirrorHelper().getAnnotationValue(annotationMirror,
                                                                                                     "value");
            if (annotationMirror != null) {
                String importStatement = annotationValue.getValue().toString();
                addImport(importStatement);
            }
        }
    }

    protected boolean isImport(AnnotationMirror annotationMirror) {
        return annotationMirror != null
               && annotationMirror.getAnnotationType().toString().equals(Import.class.getName());
    }

    protected boolean isImportList(AnnotationMirror annotationMirror) {
        return annotationMirror != null
               && annotationMirror.getAnnotationType().toString().equals(IMPORT_LIST_CLASS_NAME);
    }
}
