package com.alibaba.fastvalidator.generate.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.alibaba.fastvalidator.generate.context.ValidatorBeanGeneratorContext;
import com.alibaba.fastvalidator.generate.meta.ConstraintInfo;
import com.alibaba.fastvalidator.generate.meta.ValidateBeanInfo;
import com.alibaba.fastvalidator.generate.streagy.ConstraintProcessor;

/**
 * Default generator for constraint
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
public class DefaultGenerator implements Generator {

    private Generator parent;

    private List<Generator> children = new ArrayList<>();

    private Set<String> shouldImportTypes = new HashSet<>();

    @Override
    public void beforeGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        for (Generator child : children) {
            child.beforeGenerate(validateBeanInfo, context);
        }
    }

    @Override
    public void generateForConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                      ConstraintInfo constraintInfo,
                                      ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo,
                                      ConstraintProcessor processor) {
        for (Generator child : children) {
            child.generateForConstraint(validateBeanInfo, context, constraintInfo, fieldConstraintFlatInfo,
                    processor);
        }
    }

    @Override
    public void generateForNonConstraint(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context,
                                         ValidateBeanInfo.FieldConstraintFlatInfo fieldConstraintFlatInfo) {
        for (Generator child : children) {
            child.generateForNonConstraint(validateBeanInfo, context, fieldConstraintFlatInfo);
        }
    }

    @Override
    public void afterGenerate(ValidateBeanInfo validateBeanInfo, ValidatorBeanGeneratorContext context) {
        for (Generator child : children) {
            child.afterGenerate(validateBeanInfo, context);
        }
    }

    public Generator getParent() {
        return parent;
    }

    public Generator setParent(Generator parent) {
        this.parent = parent;
        return this;
    }

    public Generator addChild(Generator child) {
        children.add(child);
        child.setParent(this);
        return this;
    }

    public Set<String> getShouldImportTypes() {
        Set<String> allImportTypes = new HashSet<>(shouldImportTypes);
        for (Generator child : children) {
            allImportTypes.addAll(child.getShouldImportTypes());
        }

        return allImportTypes;
    }

    protected void addImports(Collection<String> importTypes) {
        if (importTypes == null) {
            return;
        }

        for (String importType : importTypes) {
            addImport(importType);
        }
    }

    protected void addImport(String importType) {
        if (importType.endsWith(";")) {
            importType = importType.substring(0, importType.length() - 1);
        }

        shouldImportTypes.add(importType);
    }
}
