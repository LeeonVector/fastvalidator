package com.alibaba.fastvalidator.constraints.exception;

/**
 * Bean validator initial exception
 *
 * @author: jasen.zhangj
 * @date: 16/9/1.
 */
public class ValidatorInitialException extends FastValidatorException{

    private static final long serialVersionUID = 3790602420608390523L;

    public ValidatorInitialException(Throwable cause) {
        super(cause);
    }

    public ValidatorInitialException(String message, Throwable cause) {
        super(message, cause);
    }
}
