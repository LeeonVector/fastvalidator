package com.alibaba.fastvalidator.constraints.validator.messageinterpolation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.prompt.FastValidatorLogger;

/**
 * <pre>
 * Message Helper.
 *
 * Message format: message?{arg0}{arg1}...{argn}|code
 * </pre>
 * 
 * @author: jasen.zhangj
 * @date: 2017-05-12
 */
public class MessageHelper {

    private static final Pattern messageParameterPattern = Pattern.compile("(\\{.+?\\})");

    /***
     * <pre>
     * Generate final message by message and code.
     * final message format: message?{arg0}{arg1}...{argn}|code
     * </pre>
     * 
     * @param message message
     * @param code code
     * @return final message
     */
    public static String generateMessage(String message, String code) {
        if (StringUtils.isBlank(code)) {
            return message;
        }

        return message + "|" + code;
    }

    /***
     * <pre>
     * Parse the message to the {@link ConstraintMessage} object.
     * </pre>
     * 
     * @param message message
     * @return {@link ConstraintMessage}
     */
    public static ConstraintMessage getConstraintMessage(String message) {
        ConstraintMessage constraintMessage = new ConstraintMessage();
        if (StringUtils.isBlank(message)) {
            constraintMessage.setMessage(message);
        } else {
            int index = message.indexOf("|");
            if (index >= 0) {
                String[] messageInfo = StringUtils.splitPreserveAllTokens(message, "|");
                if (messageInfo.length >= 2) {
                    setMessageAndMessageArgs(constraintMessage, messageInfo[0]);
                    constraintMessage.setCode(messageInfo[1]);
                }
            } else {
                setMessageAndMessageArgs(constraintMessage, message);
            }
        }

        return constraintMessage;
    }

    private static void setMessageAndMessageArgs(ConstraintMessage constraintMessage, String message) {
        int parameterIndex = message.indexOf("?");
        if (parameterIndex > 0) {
            constraintMessage.setMessage(message.substring(0, parameterIndex));
            String parameters = message.substring(parameterIndex + 1);
            constraintMessage.setMessageArgs(resolveMessageArguments(parameters));
        } else {
            constraintMessage.setMessage(message);
        }
    }

    protected static List<String> resolveMessageArguments(String parameters) {
        List<String> resolvedParameterValue = new ArrayList<>(4);
        try {
            final Matcher matcher = messageParameterPattern.matcher(parameters);
            while (matcher.find()) {
                String parameter = matcher.group(1);
                resolvedParameterValue.add(parameter.substring(1, parameter.length() - 1));
            }
        } catch (Exception ex) {
            FastValidatorLogger.getFastValidatLog().error("MESSAGE_RESOLVE", "message resolved failed : " + parameters,
                                                          ex);
        }

        return resolvedParameterValue;
    }

}
