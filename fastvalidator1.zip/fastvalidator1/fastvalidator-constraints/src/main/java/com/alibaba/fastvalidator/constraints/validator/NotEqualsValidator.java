package com.alibaba.fastvalidator.constraints.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.alibaba.fastvalidator.constraints.NotEquals;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;

/**
 * Validator for constraint {@link NotEquals}
 *
 * @author: jasen.zhangj
 * @date: 27/04/2017.
 */
public class NotEqualsValidator implements ConstraintValidator<NotEquals, CharSequence> {

    private boolean ignoreCase;
    private String  specifiedValue;

    @Override
    public void initialize(NotEquals constraintAnnotation) {
        this.specifiedValue = constraintAnnotation.value();
        this.ignoreCase = constraintAnnotation.ignoreCase();
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        if (value == null){
            return true;
        }

        return  ignoreCase ? !StringUtils.equalsIgnoreCase(specifiedValue, value): !StringUtils.equals(specifiedValue, value);
    }
}
