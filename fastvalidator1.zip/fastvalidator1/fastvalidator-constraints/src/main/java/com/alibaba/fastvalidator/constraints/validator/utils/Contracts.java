/*
 * Hibernate Validator, declare and validate application constraints License: Apache License, Version 2.0 See the
 * license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.utils;

/**
 * Assert utils
 *
 * @author: jasen.zhangj
 * @date: 17/1/2.
 */
public final class Contracts {

    private Contracts() {
    }

    public static void assertNotNull(Object o) {
        assertNotNull(o, "the object must not be null");
    }

    /**
     * Asserts that the given object is not {@code null}.
     *
     * @param o The object to check.
     * @param message A message text which will be used as message of the resulting exception if the given object is
     * {@code null}.
     * @throws IllegalArgumentException In case the given object is {@code null}.
     */
    public static <T> T assertNotNull(T o, String message) {
        if (o == null) {
            throw new IllegalArgumentException(message);
        }

        return o;
    }

    public static <T> T assertNotNull(final T object, final String message, final Object... values) {
        return assertNotNull(object, String.format(message, values));
    }

    /**
     * Asserts that the given object is not {@code null}.
     *
     * @param o The object to check.
     * @param name The name of the value to check. A message of the form "&lt;name&gt; must not be null" will be used as
     * message of the resulting exception if the given object is {@code null}.
     * @throws IllegalArgumentException In case the given object is {@code null}.
     */
    public static void assertValueNotNull(Object o, String name) {
        if (o == null) {
            throw new IllegalArgumentException("the " + name + " must not be null");
        }
    }

    public static void assertTrue(boolean condition, String message) {
        if (!condition) {
            throw new IllegalArgumentException(message);
        }
    }

    public static void assertTrue(final boolean expression, final String message, final Object... values) {
        assertTrue(expression, String.format(message, values));
    }

    public static void assertNotEmpty(String s, String message) {
        if (s.length() == 0) {
            throw new IllegalArgumentException(message);
        }
    }
}
