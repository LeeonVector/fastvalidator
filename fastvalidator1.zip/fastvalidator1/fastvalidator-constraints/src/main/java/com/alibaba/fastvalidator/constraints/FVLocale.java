package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * FastValidator will interpolate the message by the specifal {@link java.util.Locale} local which maybe form the Java
 * Bean's field or method annotated by {@link FVLocale}
 *
 * @author: jasen.zhangj
 * @date: 2017-05-10
 */
@Target({ ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface FVLocale {
}
