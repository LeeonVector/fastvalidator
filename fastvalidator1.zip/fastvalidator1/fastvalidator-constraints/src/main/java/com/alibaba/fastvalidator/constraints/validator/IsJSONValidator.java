package com.alibaba.fastvalidator.constraints.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastvalidator.constraints.IsJSON;
import com.alibaba.fastvalidator.constraints.utils.ClassUtils;
import com.alibaba.fastvalidator.constraints.validator.prompt.MessageFormatter;

/**
 * Validator for {@link com.alibaba.fastvalidator.constraints.IsJSON}
 *
 * @author: jasen.zhangj
 * @date: 17/1/10.
 */
public class IsJSONValidator implements ConstraintValidator<IsJSON, String> {


    @Override
    public void initialize(IsJSON constraintAnnotation) {
        try {
            ClassUtils.getClass("com.alibaba.fastjson.JSON");
        } catch (ClassNotFoundException e) {
            throw MessageFormatter.getUnableToFindFastJSONException();
        }
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null){
            return true;
        }

        try {
            JSON.parse(value);
            return true;
        } catch (JSONException ex) {
            return false;
        }
    }
}
