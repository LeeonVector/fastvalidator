package com.alibaba.fastvalidator.constraints.validator.messageinterpolation;

import java.lang.annotation.Annotation;
import java.util.Locale;
import java.util.Map;
import javax.validation.MessageInterpolator;
import javax.validation.metadata.ConstraintDescriptor;
import com.alibaba.fastvalidator.constraints.validator.metadata.FastValidatorConstraintDescriptorImpl;

/**
 * Message interpolator helper in compile stage
 *
 * @author: jasen.zhangj
 * @date: 16/10/24.
 */
public class MessageInterpolatorHelper {

    private static MessageInterpolator messageInterpolator = new FastValidatorMessageInterpolator();

    public static String interpolate(String message, Annotation annotation) {
        ConstraintDescriptor constraintDescriptor = new FastValidatorConstraintDescriptorImpl(annotation);
        MessageInterpolatorContext messageInterpolatorContext = new MessageInterpolatorContext(constraintDescriptor,
                                                                                               null);

        return interpolate(message, messageInterpolatorContext);
    }

    public static String interpolate(String message, Map<String, Object> attributes) {
        ConstraintDescriptor constraintDescriptor = new FastValidatorConstraintDescriptorImpl(attributes);
        MessageInterpolatorContext messageInterpolatorContext = new MessageInterpolatorContext(constraintDescriptor,
                                                                                               null);

        return interpolate(message, messageInterpolatorContext);
    }

    private static String interpolate(String message, MessageInterpolator.Context context) {
        return messageInterpolator.interpolate(message, context, Locale.US);
    }
}
