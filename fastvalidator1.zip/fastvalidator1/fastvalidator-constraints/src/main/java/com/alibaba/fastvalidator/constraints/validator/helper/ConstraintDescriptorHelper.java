package com.alibaba.fastvalidator.constraints.validator.helper;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintTarget;
import javax.validation.Payload;
import javax.validation.groups.Default;

/**
 * Helper for constraint descriptor
 *
 * @author: jasen.zhangj
 * @date: 2017-10-11
 */
public class ConstraintDescriptorHelper {

    public static String getMessageTemplate(Map<String, Object> attributes){
        return (String) attributes.get("message");
    }

    public static Set<Class<?>> getGroups(Map<String, Object> attributes) {
        Set<Class<?>> groupSet = new HashSet<>();
        Class<?>[] groups = (Class<?>[]) attributes.get("groups");
        ;
        if (groups.length == 0) {
            groupSet.add(Default.class);
        } else {
            groupSet.addAll(Arrays.asList(groups));
        }

        return Collections.unmodifiableSet(groupSet);
    }

    public static Set<Class<? extends Payload>> getPayload(Map<String, Object> attributes) {
        Set<Class<? extends Payload>> payloadSet = new HashSet<>();

        Class<? extends Payload>[] payloads = (Class<? extends Payload>[]) attributes.get("payload");
        ;
        if (payloads != null && payloads.length > 0) {
            payloadSet.addAll(Arrays.asList(payloads));
        }

        return Collections.unmodifiableSet(payloadSet);
    }

    public static ConstraintTarget getValidationAppliesTo(Map<String, Object> attributes) {
        return (ConstraintTarget) attributes.get(FastValidatorConstraintHelper.VALIDATION_APPLIES_TO);
    }

}
