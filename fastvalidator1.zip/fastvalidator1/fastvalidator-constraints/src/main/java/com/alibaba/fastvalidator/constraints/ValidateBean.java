package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import com.alibaba.fastvalidator.constraints.validator.ValidateBeanValidator;

/**
 * Basic constraint on POJO type.
 *
 * @author: jasen.zhangj
 * @created: 2014-08-20
 */
@Target({ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = {ValidateBeanValidator.class})
public @interface ValidateBean {

    String message() default "";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
