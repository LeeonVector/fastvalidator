/*
 * Hibernate Validator, declare and validate application constraints
 *
 * License: Apache License, Version 2.0
 * See the license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.hv;

import java.util.HashMap;
import java.util.Map;
import javax.script.ScriptException;
import com.alibaba.fastvalidator.constraints.validator.prompt.MessageFormatter;
import com.alibaba.fastvalidator.constraints.validator.scriptengine.ScriptEvaluator;
import com.alibaba.fastvalidator.constraints.validator.scriptengine.ScriptEvaluatorFactory;


/**
 * Context used by validator implementations dealing with script expressions. Instances are thread-safe and can be re-used
 * several times to evaluate different bindings against one given given script expression.
 *
 * @author Gunnar Morling
 */
class ScriptAssertContext {

	private final String script;
	private final ScriptEvaluator scriptEvaluator;

	public ScriptAssertContext(String languageName, String script) {
		this.script = script;
		this.scriptEvaluator = getScriptEvaluator( languageName );
	}

	public boolean evaluateScriptAssertExpression(Object object, String alias) {
		Map<String, Object> bindings = new HashMap<>();
		bindings.put( alias, object );

		return evaluateScriptAssertExpression( bindings );
	}

	public boolean evaluateScriptAssertExpression(Map<String, Object> bindings) {
		Object result;

		try {
			result = scriptEvaluator.evaluate( script, bindings );
		}
		catch (ScriptException e) {
			throw MessageFormatter.getErrorDuringScriptExecutionException( script, e );
		}

		return handleResult( result );
	}

	private ScriptEvaluator getScriptEvaluator(String languageName) {
		try {
			ScriptEvaluatorFactory evaluatorFactory = ScriptEvaluatorFactory.getInstance();
			return evaluatorFactory.getScriptEvaluatorByLanguageName( languageName );
		}
		catch (ScriptException e) {
			throw MessageFormatter.getCreationOfScriptExecutorFailedException( languageName, e );
		}
	}

	private boolean handleResult(Object evaluationResult) {
		if ( evaluationResult == null ) {
			throw MessageFormatter.getScriptMustReturnTrueOrFalseException( script );
		}

		if ( !( evaluationResult instanceof Boolean ) ) {
			throw MessageFormatter.getScriptMustReturnTrueOrFalseException(
					script,
					evaluationResult,
					evaluationResult.getClass().getCanonicalName()
			);
		}

		return Boolean.TRUE.equals( evaluationResult );
	}
}
