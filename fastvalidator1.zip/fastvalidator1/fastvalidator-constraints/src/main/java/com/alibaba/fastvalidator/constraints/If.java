package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Payload;

/**
 * Conditional constraint. Is equivalent: <em>if(sourceCode){ return message}</em>
 *
 * <pre>
 * class A {
 *
 *     &#64;If(sourceCode = "!StringUtils.equals(bean.password, bean.repassword)")
 *     private String password;
 *
 *     &#64;If(sourceCode = "!StringUtils.equals(bean.getPassword(), bean.getRepassword())")
 *     private String repassword;
 * }
 * </pre>
 *
 * @see com.alibaba.fastvalidator.constraints.utils.StringUtils
 * @see com.alibaba.fastvalidator.constraints.utils.NumberUtils
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface If {

    /***
     * source codes in "if" statement.
     */
    String sourceCode();

    String message();

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
