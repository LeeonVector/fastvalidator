package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

import com.alibaba.fastvalidator.constraints.validator.IsDateValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Check whether String is date format
 *
 * @author: jasen.zhangj
 * @date: 17/1/10.
 */
@Documented
@Constraint(validatedBy = {IsDateValidator.class})
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@ReportAsSingleViolation
public @interface IsDate {

    /***
     * @see {@link java.text.SimpleDateFormat}
     */
    String dateFormat();

    String message() default "should be {dateFormat} format";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
