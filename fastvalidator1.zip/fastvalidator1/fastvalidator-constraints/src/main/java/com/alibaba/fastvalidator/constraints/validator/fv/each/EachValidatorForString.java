package com.alibaba.fastvalidator.constraints.validator.fv.each;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.alibaba.fastvalidator.constraints.EachValidate;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;

/**
 * Validate all elements in string with spefic separator.
 *
 * @author: jasen.zhangj
 * @date: 2017-08-07
 */
public class EachValidatorForString extends EachValidatorBase<String> implements ConstraintValidator<EachValidate, String> {

    private String  separator;

    private boolean preserveAllTokens;

    @Override
    public void initialize(EachValidate constraintAnnotation) {
        separator = constraintAnnotation.separator();
        preserveAllTokens = constraintAnnotation.preserveAllTokens();
        super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        String[] values = preserveAllTokens ? StringUtils.splitPreserveAllTokens(value,
                                                                                 separator) : StringUtils.split(value,
                                                                                                                separator);

        for (String element : values) {
            if (!descriptor.isValid(element, context)) {
                return false;
            }
        }

        return true;
    }
}
