package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created by jipengfei on 17/2/21.
 */
public class ContainsValidatorForArraysOfByte implements ConstraintValidator<Contains, byte[]> {

    private byte containsValue;

    @Override
    public void initialize(Contains constraintAnnotation) {
        containsValue = Byte.parseByte(constraintAnnotation.value());
    }

    @Override
    public boolean isValid(byte[] value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        boolean result = false;
        for (int i = 0; i < value.length; i++) {
            if (containsValue == value[i]) {
                result = true;
                break;
            }
        }
        return result;
    }
}
