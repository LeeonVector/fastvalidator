package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

import com.alibaba.fastvalidator.constraints.validator.IsEnumValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Check whether it ({@link java.lang.String}) is enum
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
@Documented
@Constraint(validatedBy = {IsEnumValidator.class})
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@ReportAsSingleViolation
public @interface IsEnum {

    /***
     * @return enum type
     */
    Class<? extends Enum<?>> enumType();

    String message() default "should be {enumType} type";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

}
