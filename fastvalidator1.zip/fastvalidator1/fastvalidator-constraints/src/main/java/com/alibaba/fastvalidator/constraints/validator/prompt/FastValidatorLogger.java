package com.alibaba.fastvalidator.constraints.validator.prompt;

import com.alibaba.fastvalidator.logger.Level;
import com.alibaba.fastvalidator.logger.Logger;
import com.alibaba.fastvalidator.logger.LoggerFactory;

/**
 * Logger in fastvalidator
 *
 * @author: jasen.zhangj
 * @date: 17/1/2.
 */
public class FastValidatorLogger {

    private static Logger FASTVALIDATOR_LOGGER = LoggerFactory.getLogger("fastvalidator");
    private static Logger VALIDATE_RESULT_LOGGER = LoggerFactory.getLogger("fastvalidator_result");
    private static String EMPTY = "";

    static {
       initialize();
    }

    public static void showVersion(String sversion) {
        FASTVALIDATOR_LOGGER.info(EMPTY, MessageFormatter.getVersion(sversion));
    }

    public static Logger getFastValidatLog() {
        return FASTVALIDATOR_LOGGER;
    }

    public static Logger getValidateResultLogger() {
        return VALIDATE_RESULT_LOGGER;
    }

    private static void initialize(){
        FASTVALIDATOR_LOGGER.activateAppender("fastvalidator", "fastvalidator.log", "UTF-8");
        FASTVALIDATOR_LOGGER.setLevel(Level.INFO);
        FASTVALIDATOR_LOGGER.setAdditivity(false);

        VALIDATE_RESULT_LOGGER.activateAppender("fastvalidator", "fastvalidator_result.log", "UTF-8");
        VALIDATE_RESULT_LOGGER.setLevel(Level.INFO);
        VALIDATE_RESULT_LOGGER.setAdditivity(false);
    }

    public static void reinitialize(){
        initialize();
    }
}
