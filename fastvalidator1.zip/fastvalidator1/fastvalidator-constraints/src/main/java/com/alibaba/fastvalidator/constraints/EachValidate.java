package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Validate each element in collection or characters.
 *
 * @author: jasen.zhangj
 * @date: 2017-08-07
 */
@Documented
@Constraint(validatedBy = {})
@Target({ METHOD, FIELD, CONSTRUCTOR, PARAMETER })
@Retention(RUNTIME)
@ReportAsSingleViolation
public @interface EachValidate {

    String message() default "each element may not violate the constraint: {constraint} with property {constraintProperties}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};


    /***
     * @return whether or not preserve all tokens
     *
     * @see  {@link com.alibaba.fastvalidator.constraints.utils.StringUtils#splitPreserveAllTokens(String, String)}
     */
    boolean preserveAllTokens() default false;

    /***
     * @return the characters used as the delimiters.
     * @see  {@link com.alibaba.fastvalidator.constraints.utils.StringUtils#split(String, String)}
     */
    String separator() default ",";

    /***
     * @return constraint type.
     */
    Class<? extends Annotation> constraint();

    /***
     * @return constraint properties.
     */
    ConstraintProperty[] constraintProperties() default {};

    public @interface ConstraintProperty {

        /***
         * @return constraint property name
         */
        String name();

        /***
         * @return constraint property value(String type)
         */
        String value();

    }
}
