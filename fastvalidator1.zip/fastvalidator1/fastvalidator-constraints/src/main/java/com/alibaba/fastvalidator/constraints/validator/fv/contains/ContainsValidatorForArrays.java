package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created by jipengfei on 17/2/21.
 */
public class ContainsValidatorForArrays extends ContainsValidatorBase
    implements ConstraintValidator<Contains, Object[]> {

    @Override
    public boolean isValid(Object[] value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        boolean result = false;
        for (int i = 0; i < value.length; i++) {
            if (containsValue==null || containsValue.equals(value[i])) {
                result = true;
                break;
            }
        }
        return result;
    }
}
