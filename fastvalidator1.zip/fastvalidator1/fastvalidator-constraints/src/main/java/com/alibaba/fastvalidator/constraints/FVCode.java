package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * FastValidator will set the code value to the Java Bean's method or field which annotated the {@link FVCode}.
 *
 * @author: jasen.zhangj
 * @date: 16/12/14.
 */
@Target({ ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface FVCode {
}
