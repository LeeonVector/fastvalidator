/*
 * The MIT License Copyright 2013-2014 Jakub Jirutka <jakub@jirutka.cz>. Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the
 * Software without restriction, including without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions: The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
 * ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.alibaba.fastvalidator.constraints.validator.collection;

import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.MessageInterpolator;
import javax.validation.MessageInterpolator.Context;
import javax.validation.metadata.ConstraintDescriptor;

import com.alibaba.fastvalidator.constraints.collection.EachConstraint;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageHelper;
import com.alibaba.fastvalidator.constraints.validator.messageinterpolation.MessageInterpolatorContext;
import com.alibaba.fastvalidator.constraints.validator.metadata.FastValidatorConstraintDescriptorImpl;
import com.alibaba.fastvalidator.constraints.validator.metadata.SimpleConstraintDescriptor;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;

/**
 * Common validator for collection constraints that validates each element of the given collection.
 */
@SuppressWarnings("unchecked")
public class CommonEachValidator implements ConstraintValidator<Annotation, Collection<?>> {

    private FastValidatorConstraintDescriptorImpl descriptor;

    private String                                nodeName;
    private String                                code;
    private String                                message;
    private Annotation                            annotation;

    @Override
    public void initialize(Annotation eachAnnotation) {
        this.annotation = eachAnnotation;
        Class<? extends Annotation> eachAType = eachAnnotation.annotationType();

        if (eachAType.isAnnotationPresent(EachConstraint.class)) {
            Class constraintClass = eachAType.getAnnotation(EachConstraint.class).validateAs();

            Annotation constraint = createConstraintAndCopyAttributes(constraintClass, eachAnnotation);
            descriptor = createConstraintDescriptor(constraint);

        } else {
            throw new IllegalArgumentException(String.format("%s is not annotated with @EachConstraint",
                                                             eachAType.getName()));
        }
    }

    @Override
    public boolean isValid(Collection<?> collection, ConstraintValidatorContext context) {
        if (collection == null || collection.isEmpty()) {
            return true;
        }

        context.disableDefaultConstraintViolation(); // do not add wrapper's message

        int index = 0;
        for (Iterator<?> it = collection.iterator(); it.hasNext(); index++) {
            Object element = it.next();

            if (!descriptor.isValid(element, context)) {
                MessageInterpolator messageInterpolator = context.unwrap(FastValidatorBeanContext.class).getMessageInterpolator();
                String message = this.message == null ? createMessage(messageInterpolator, descriptor,
                                                                      element) : this.message;

                message = MessageHelper.generateMessage(message, code);

                addConstraintViolationInIterable(context, message, nodeName, index);
                return false;
            }
        }
        return true;
    }

    protected FastValidatorConstraintDescriptorImpl createConstraintDescriptor(Annotation constraint) {
        return new FastValidatorConstraintDescriptorImpl(constraint);
    }

    /**
     * Builds and adds a constraint violation inside an iterable value to the given {@code ConstraintValidatorContext}.
     * If running with Hibernate Validator 5.x, then it also registers index of the violated value.
     *
     * @param context The Constraint validator context.
     * @param message The interpolated error message.
     * @param index Index of the invalid value inside a list (ignored on HV 4.x).
     */
    protected void addConstraintViolationInIterable(ConstraintValidatorContext context, String message, String nodeName,
                                                    int index) {
        ConstraintValidatorContext.ConstraintViolationBuilder constraintViolationBuilder = context.buildConstraintViolationWithTemplate(message);
        if (StringUtils.isNotEmpty(nodeName)) {
            constraintViolationBuilder.addPropertyNode(nodeName).addConstraintViolation();
        } else {
            constraintViolationBuilder.addConstraintViolation();
        }

        if (context instanceof FastValidatorBeanContext){
            ((FastValidatorBeanContext)context).setBeanPropertyConstraintDescriptor(new SimpleConstraintDescriptor(annotation));
        }
    }

    /**
     * Reads and interpolates an error message for the given constraint and value.
     *
     * @param messageInterpolator {@link MessageInterpolator}
     * @param descriptor Descriptor of the constraint that the value violated.
     * @param value The validated value.
     * @return An interpolated message.
     */
    protected String createMessage(MessageInterpolator messageInterpolator, ConstraintDescriptor descriptor,
                                   Object value) {
        Context context = new MessageInterpolatorContext(descriptor, value);

        Annotation constraint = descriptor.getAnnotation();
        String template = AnnotationUtils.readAttribute(constraint, "message", String.class);

        return messageInterpolator.interpolate(template, context);
    }

    /**
     * Instantiates constraint of the specified type and copies values of all the common attributes from the given
     * source constraint (of any type) to it.
     * <p>
     * If the source constraint's {@code message} is empty, then it will <b>not</b> copy it (so the default
     * {@code message} of the target constraint will be preserved).
     * </p>
     * 
     * @param constraintType Type of the constraint to create.
     * @param source Any annotation to copy attribute values from.
     * @return An instance of the specified constraint.
     */
    protected <T extends Annotation> T createConstraintAndCopyAttributes(Class<T> constraintType, Annotation source) {
        Map<String, Object> attributes = AnnotationUtils.readAllAttributesAndOverrideAttribute(source);

        // if message is not set, keep message from original constraint instead
        if (StringUtils.isEmpty((String) attributes.get("message"))) {
            attributes.remove("message");
        }

        return AnnotationUtils.createAnnotation(constraintType, attributes);
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
