/*
 * Hibernate Validator, declare and validate application constraints
 *
 * License: Apache License, Version 2.0
 * See the license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.hv;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.hibernate.validator.constraints.Length;

/**
 * Check that the character sequence length is between min and max.
 *
 * @author Emmanuel Bernard
 * @author Gavin King
 */
public class LengthValidator implements ConstraintValidator<Length, CharSequence> {

	private int min;
	private int max;

	public void initialize(Length parameters) {
		min = parameters.min();
		max = parameters.max();
		validateParameters();
	}

	public boolean isValid(CharSequence value, ConstraintValidatorContext constraintValidatorContext) {
		if ( value == null ) {
			return true;
		}
		int length = value.length();
		return length >= min && length <= max;
	}

	private void validateParameters() {
		if ( min < 0 ) {
            throw new IllegalArgumentException("min can't be negative:"+min);
		}
		if ( max < 0 ) {
            throw new IllegalArgumentException("max can't be negative:"+max);
		}
		if ( max < min ) {
            throw new IllegalArgumentException("max can't be less than min:" + max + ", " + min);
		}
	}
}
