package com.alibaba.fastvalidator.constraints.exception;

/**
 * Fast validator basic exception and it used when validate bean failed
 *
 * @author: jasen.zhangj
 * @date: 16/11/23.
 */
public class FastValidatorException extends RuntimeException {

    private static final long serialVersionUID = -6295178512617654099L;

    private String code;

    public FastValidatorException() {
    }

    public FastValidatorException(String message) {
        super(message);
    }

    public FastValidatorException(String message, Throwable cause) {
        super(message, cause);
    }

    public FastValidatorException(Throwable cause) {
        super(cause);
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
