/*
 * Hibernate Validator, declare and validate application constraints License: Apache License, Version 2.0 See the
 * license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.hv;

import java.util.HashMap;
import java.util.Map;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;
import org.hibernate.validator.constraints.ParameterScriptAssert;
import com.alibaba.fastvalidator.constraints.validator.prompt.MessageFormatter;
import com.alibaba.fastvalidator.constraints.validator.utils.Contracts;

/**
 * Validator for the {@link ParameterScriptAssert} constraint annotation.
 *
 * @author Gunnar Morling
 */
@SupportedValidationTarget(ValidationTarget.PARAMETERS)
public class ParameterScriptAssertValidator implements ConstraintValidator<ParameterScriptAssert, Object[]> {

    private ScriptAssertContext scriptAssertContext;

    private static final String ARG = "arg";

    @Override
    public void initialize(ParameterScriptAssert constraintAnnotation) {
        validateParameters(constraintAnnotation);
        this.scriptAssertContext = new ScriptAssertContext(constraintAnnotation.lang(), constraintAnnotation.script());
    }

    @Override
    public boolean isValid(Object[] arguments, ConstraintValidatorContext constraintValidatorContext) {
        Map<String, Object> bindings = getBindings(arguments);

        return scriptAssertContext.evaluateScriptAssertExpression(bindings);
    }

    private Map<String, Object> getBindings(Object[] arguments) {
        Map<String, Object> bindings = new HashMap<>();

        for (int i = 0; i < arguments.length; i++) {
            bindings.put(ARG + i, arguments[i]);
        }

        return bindings;
    }

    private void validateParameters(ParameterScriptAssert constraintAnnotation) {
        Contracts.assertNotEmpty(constraintAnnotation.script(), MessageFormatter.parameterMustNotBeEmpty("script"));
        Contracts.assertNotEmpty(constraintAnnotation.lang(), MessageFormatter.parameterMustNotBeEmpty("lang"));
    }
}
