package com.alibaba.fastvalidator.constraints.collection;


import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import org.hibernate.validator.constraints.EAN;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;


/**
 * @see EAN
 *
 * @author: jasen.zhangj
 * @date: 17/1/3.
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({METHOD, FIELD, ANNOTATION_TYPE})
@EachConstraint(validateAs = EAN.class)
@Constraint(validatedBy = {CommonEachValidator.class})
public @interface EachEAN {

    String message() default "";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    EAN.Type type() default EAN.Type.EAN13;
}
