/*
 * Hibernate Validator, declare and validate application constraints
 *
 * License: Apache License, Version 2.0
 * See the license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.bv.size;

import javax.validation.constraints.Size;


/**
 * Check that the length of an array is between <i>min</i> and <i>max</i>
 *
 * @author Hardy Ferentschik
 */
public abstract class SizeValidatorForArraysOfPrimitives {

	protected int min;
	protected int max;

	public void initialize(Size parameters) {
		min = parameters.min();
		max = parameters.max();
		validateParameters();
	}

	private void validateParameters() {
        if ( min < 0 ) {
            throw new IllegalArgumentException("min is <0");
        }
        if ( max < 0 ) {
            throw new IllegalArgumentException("max is <0");
        }
        if ( max < min ) {
            throw new IllegalArgumentException("max is <min");
        }
	}
}
