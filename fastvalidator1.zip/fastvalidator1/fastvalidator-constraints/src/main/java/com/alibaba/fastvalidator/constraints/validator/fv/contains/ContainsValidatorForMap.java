package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Map;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public class ContainsValidatorForMap extends ContainsValidatorBase implements ConstraintValidator<Contains, Map<?, ?>> {

    @Override
    public boolean isValid(Map<?, ?> value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        return value.containsKey(containsValue);
    }
}
