package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 条件约束
 *
 * <pre>
 *     @Import(xxxx.xxUtils.class)
 *     class A {
 *
 *         &#64;Conditional(rawCode="xxUtils.xxmethod(bean.getPassword())")
 *         private String password;
 *
           &#64;Conditional(rawCode="xxUtils.xxmethod(bean.getPassword())")
 *         private String repassword;
 *     }
 * </pre>
 *
 * @author: jasen.zhangj
 * @date: 17/1/5.
 */
@Target({ ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Import {

    /***
     * import class type(name).
     */
    Class value();

    /**
     * Defines several {@code @Length} annotations on the same element.
     */
    @Target({ ElementType.TYPE })
    @Retention(RetentionPolicy.RUNTIME)
    @Documented
    public @interface List {

        Import[] value();
    }
}
