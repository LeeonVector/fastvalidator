/*
 * Hibernate Validator, declare and validate application constraints License: Apache License, Version 2.0 See the
 * license.txt file in the root directory or <http://www.apache.org/licenses/LICENSE-2.0>.
 */
package com.alibaba.fastvalidator.constraints.validator.annotation;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;

/**
 * Creates live annotations (actually {@link AnnotationProxy} instances) from {@code AnnotationDescriptor}s.
 *
 * @author Paolo Perrotta
 * @author Davide Marchignoli
 * @author Hardy Ferentschik
 * @see AnnotationProxy
 */
public class AnnotationFactory {

    private AnnotationFactory() {
    }

    public static <T extends Annotation> T create(AnnotationDescriptor<T> descriptor) {
        @SuppressWarnings("unchecked")
        Class<T> proxyClass = (Class<T>) Proxy.getProxyClass(descriptor.type().getClassLoader(), descriptor.type());
        InvocationHandler handler = new AnnotationProxy(descriptor);
        try {
            return getProxyInstance(proxyClass, handler);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static <T extends Annotation> T create(AnnotationDescriptor<T> descriptor, boolean autoConvertValueType) {
        @SuppressWarnings("unchecked")
        Class<T> proxyClass = (Class<T>) Proxy.getProxyClass(descriptor.type().getClassLoader(), descriptor.type());
        InvocationHandler handler = new AnnotationProxy(descriptor, autoConvertValueType);
        try {
            return getProxyInstance(proxyClass, handler);
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static <T extends Annotation> T getProxyInstance(Class<T> proxyClass,
                                                             InvocationHandler handler) throws SecurityException,
                                                                                        NoSuchMethodException,
                                                                                        IllegalArgumentException,
                                                                                        InstantiationException,
                                                                                        IllegalAccessException,
                                                                                        InvocationTargetException {
        final Constructor<T> constructor = proxyClass.getDeclaredConstructor(InvocationHandler.class);

        return constructor.newInstance(handler);
    }
}
