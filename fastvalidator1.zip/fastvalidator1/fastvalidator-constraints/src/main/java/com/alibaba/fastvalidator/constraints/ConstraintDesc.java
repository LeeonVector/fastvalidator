package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 对验证现有协议的补充
 *
 * @author: jasen.zhangj
 * @created: 2016-12-13
 */
@Target({ ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE, ElementType.CONSTRUCTOR, ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ConstraintDesc {

    /***
     * 验证顺序: 值越大, 验证越靠前
     */
    int order() default 0;

    /***
     * 验证code
     */
    String code() default "";

    /***
     * 对应的约束
     */
    Class<? extends Annotation> constraint() default Annotation.class;
}
