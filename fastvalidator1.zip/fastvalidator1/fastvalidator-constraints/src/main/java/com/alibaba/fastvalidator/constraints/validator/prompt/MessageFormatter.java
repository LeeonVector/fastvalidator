package com.alibaba.fastvalidator.constraints.validator.prompt;

import java.util.Arrays;
import java.util.Set;

import javax.validation.ConstraintDeclarationException;
import javax.validation.ConstraintDefinitionException;
import javax.validation.ValidationException;

import com.alibaba.fastvalidator.constraints.utils.ClassUtils;
import com.alibaba.fastvalidator.constraints.validator.utils.builder.JSONStringBuilder;
import com.alibaba.fastvalidator.constraints.validator.utils.builder.ToStringBuilder;
import com.alibaba.fastvalidator.logger.Logger;


/**
 * Default message formatter.
 *
 * @author: jasen.zhangj
 * @date: 17/1/3.
 */
public class MessageFormatter {

    private static final String EMPTY = "";

    private static final String version = "FV000001:  fastvalidator %s";
    private static final String getErrorDuringScriptExecutionException = "FV000023: Error during execution of script \"%s\" occurred.";
    private static final String getUnableToRetrieveAnnotationParameterValueException = "FV000059: Unable to retrieve annotation parameter value.";
    private static final String getConstraintParametersCannotStartWithValidException = "FV000073: Parameters starting with \'valid\' are not allowed in a constraint.";
    private static final String getConstraintWithoutMandatoryParameterException = "FV000074: %2$s contains Constraint annotation, but does not contain a %1$s parameter.";
    private static final String getWrongDefaultValueForPayloadParameterException = "FV000075: %s contains Constraint annotation, but the payload parameter default value is not the empty array.";
    private static final String getWrongDefaultValueForGroupsParameterException = "FV000077: %s contains Constraint annotation, but the groups parameter default value is not the empty array.";
    private static final String getWrongTypeForGroupsParameterException = "FV000078: %s contains Constraint annotation, but the groups parameter is of wrong type.";
    private static final String getWrongTypeForMessageParameterException = "FV000079: %s contains Constraint annotation, but the message parameter is not of type java.lang.String.";
    private static final String getWrongParameterTypeException = "FV000082: Wrong parameter type. Expected: %1$s Actual: %2$s.";
    private static final String getUnableToFindAnnotationParameterException = "FV000083: The specified annotation defines no parameter \'%s\'.";
    private static final String getUnableToGetAnnotationParameterException = "FV000084: Unable to get \'%1$s\' from %2$s.";
    private static final String getNoValueProvidedForAnnotationParameterException = "FV000085: No value provided for parameter \'%1$s\' of annotation @%2$s.";
    private static final String getTryingToInstantiateAnnotationWithUnknownParametersException = "FV000086: Trying to instantiate %1$s with unknown parameter(s): %2$s.";
    private static final String getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException = "FV000156: Constraints with generic as well as cross-parameter validators must define an attribute validationAppliesTo(), but constraint %s doesn\'t.";
    private static final String getCreationOfScriptExecutorFailedException = "FV000170: No JSR-223 scripting engine could be bootstrapped for language \"%s\".";
    private static final String getUnableToFindFastJSONException = "FV000193: Couldn\'t find class: com.alibaba.fastjson.JSON";

    private static final Logger FASTVALIDATOR_LOGGER = FastValidatorLogger.getFastValidatLog();

    private static boolean hasFastJson = false;
    static {
        try {
            ClassUtils.getClass("com.alibaba.fastjson.JSON");
            hasFastJson = true;
        } catch (ClassNotFoundException e) {
            // do nothing
        }
    }

    public static String getVersion(String sversion) {
        return String.format(version,
                new Object[]{sversion});
    }

    public static String toString(Object object){
        if (object == null){
            return null;
        }

        if (hasFastJson){
            return JSONStringBuilder.toString(object);
        } else {
            return ToStringBuilder.reflectionToString(object);
        }
    }

    public static final ConstraintDefinitionException getConstraintWithoutMandatoryParameterException(String parameterName,
                                                                                                      String constraintName) {
        String message = String.format(getConstraintWithoutMandatoryParameterException,
                new Object[]{parameterName,
                        constraintName});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FastValidatorLogger.getFastValidatLog().error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getWrongTypeForMessageParameterException(String constraintName) {
        ConstraintDefinitionException result = new ConstraintDefinitionException(String.format(getWrongTypeForMessageParameterException,
                new Object[]{constraintName}));
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final ConstraintDefinitionException getWrongDefaultValueForGroupsParameterException(String constraintName) {
        String message = String.format(getWrongDefaultValueForGroupsParameterException,
                new Object[]{constraintName});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getWrongTypeForGroupsParameterException(String constraintName,
                                                                                              ClassCastException e) {
        String message = String.format(getWrongTypeForGroupsParameterException,
                new Object[]{constraintName});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message,
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getWrongDefaultValueForPayloadParameterException(String constraintName) {
        String message = String.format(getWrongDefaultValueForPayloadParameterException,
                new Object[]{constraintName});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getWrongTypeForPayloadParameterException(String constraintName,
                                                                                               ClassCastException e) {
        String message = String.format(getWrongDefaultValueForPayloadParameterException,
                new Object[]{constraintName});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message,
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException(String constraint) {
        String message = String.format(getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException,
                new Object[]{constraint});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException(String constraint) {
        String message = String.format(getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException,
                new Object[]{constraint});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getValidationAppliesToParameterMustHaveDefaultValueImplicitException(String constraint) {
        String message = String.format(getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException,
                new Object[]{constraint});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException(String constraint) {
        String message = String.format(getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException,
                new Object[]{constraint});
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDefinitionException getConstraintParametersCannotStartWithValidException() {
        String message = String.format(getConstraintParametersCannotStartWithValidException,
                new Object[0]);
        ConstraintDefinitionException result = new ConstraintDefinitionException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final IllegalArgumentException getNoValueProvidedForAnnotationParameterException(String parameterName,
                                                                                                   String annotation) {
        String message = String.format(getNoValueProvidedForAnnotationParameterException,
                new Object[]{parameterName,
                        annotation});
        IllegalArgumentException result = new IllegalArgumentException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final RuntimeException getTryingToInstantiateAnnotationWithUnknownParametersException(Class annotationType,
                                                                                                        Set unknownParameters) {
        String message = String.format(getTryingToInstantiateAnnotationWithUnknownParametersException,
                new Object[]{annotationType,
                        unknownParameters});
        RuntimeException result = new RuntimeException(message);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ValidationException getUnableToRetrieveAnnotationParameterValueException(Exception e) {
        String message = String.format(getUnableToRetrieveAnnotationParameterValueException,
                new Object[0]);
        ValidationException result = new ValidationException(message,
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDeclarationException getErrorDuringScriptExecutionException(String script,
                                                                                              Exception e) {
        String message = String.format(getErrorDuringScriptExecutionException,
                new Object[]{script});
        ConstraintDeclarationException result = new ConstraintDeclarationException(message,
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));

        FASTVALIDATOR_LOGGER.error(EMPTY, message, st);
        return result;
    }

    public static final ConstraintDeclarationException getCreationOfScriptExecutorFailedException(String languageName,
                                                                                                  Exception e) {
        ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getCreationOfScriptExecutorFailedException,
                new Object[]{languageName}),
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace(Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final ConstraintDeclarationException getScriptMustReturnTrueOrFalseException(String script) {
        ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getScriptMustReturnTrueOrFalseException1$str(),
                new Object[]{script}));
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    protected static String getScriptMustReturnTrueOrFalseException1$str() {
        return "FV000024: Script \"%s\" returned null, but must return either true or false.";
    }

    public static final ConstraintDeclarationException getScriptMustReturnTrueOrFalseException(String script,
                                                                                               Object executionResult,
                                                                                               String type) {
        ConstraintDeclarationException result = new ConstraintDeclarationException(String.format(getScriptMustReturnTrueOrFalseException3$str(),
                new Object[]{script,
                        executionResult, type}));
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    protected static String getScriptMustReturnTrueOrFalseException3$str() {
        return "FV000025: Script \"%1$s\" returned %2$s (of type %3$s), but must return either true or false.";
    }

    public static final ValidationException getWrongParameterTypeException(String expectedType, String currentType) {
        ValidationException result = new ValidationException(String.format(getWrongParameterTypeException,
                new Object[]{expectedType, currentType}));
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final ValidationException getUnableToFindAnnotationParameterException(String parameterName,
                                                                                        NoSuchMethodException e) {
        ValidationException result = new ValidationException(String.format(getUnableToFindAnnotationParameterException,
                new Object[]{parameterName}),
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final ValidationException getUnableToGetAnnotationParameterException(String parameterName,
                                                                                       String annotationName,
                                                                                       Exception e) {
        ValidationException result = new ValidationException(String.format(getUnableToGetAnnotationParameterException,
                new Object[]{parameterName,
                        annotationName}),
                e);
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final ValidationException getUnableToFindFastJSONException() {
        ValidationException result = new ValidationException(String.format(getUnableToFindFastJSONException));
        StackTraceElement[] st = result.getStackTrace();
        result.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(st, 1, st.length));
        return result;
    }

    public static final String parameterMustNotBeEmpty(String parameterName) {
        String result = String.format("The parameter \"%s\" must not be empty.", new Object[] { parameterName });
        return result;
    }

    public static final String unableToFindScriptEngine(String languageName) {
        String result = String.format( "No JSR 223 script engine found for language \"%s\".", new Object[]{languageName});
        return result;
    }
}
