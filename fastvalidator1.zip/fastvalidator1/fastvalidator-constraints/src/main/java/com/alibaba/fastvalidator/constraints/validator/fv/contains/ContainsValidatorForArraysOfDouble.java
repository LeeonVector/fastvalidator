package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public class ContainsValidatorForArraysOfDouble implements ConstraintValidator<Contains, double[]> {

    private double containsValue;

    @Override
    public void initialize(Contains constraintAnnotation) {
        containsValue = Double.parseDouble(constraintAnnotation.value());
    }

    @Override
    public boolean isValid(double[] value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        boolean result = false;
        for (int i = 0; i < value.length; i++) {
            if (containsValue == value[i]) {
                result = true;
                break;
            }
        }
        return result;
    }
}
