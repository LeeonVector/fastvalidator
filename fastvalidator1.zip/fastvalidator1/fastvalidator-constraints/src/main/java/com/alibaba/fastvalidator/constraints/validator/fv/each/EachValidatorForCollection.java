package com.alibaba.fastvalidator.constraints.validator.fv.each;

import java.util.Collection;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.alibaba.fastvalidator.constraints.EachValidate;

/**
 * Validate all elements in string with spefic separator.
 *
 * @author: jasen.zhangj
 * @date: 2017-08-07
 */
public class EachValidatorForCollection extends EachValidatorBase<Collection> implements ConstraintValidator<EachValidate, Collection> {

    @Override
    public boolean isValid(Collection value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        for (Object element : value) {
            if (!descriptor.isValid(element, context)) {
                return false;
            }
        }

        return true;
    }
}
