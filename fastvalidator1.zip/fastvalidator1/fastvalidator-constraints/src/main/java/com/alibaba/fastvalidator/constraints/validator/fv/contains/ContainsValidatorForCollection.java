package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Collection;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public class ContainsValidatorForCollection extends ContainsValidatorBase
    implements ConstraintValidator<Contains, Collection<?>> {


    @Override
    public boolean isValid(Collection<?> value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        return value.contains(containsValue);
    }
}
