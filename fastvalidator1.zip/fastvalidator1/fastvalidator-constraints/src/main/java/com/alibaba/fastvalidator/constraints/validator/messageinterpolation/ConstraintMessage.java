package com.alibaba.fastvalidator.constraints.validator.messageinterpolation;

import java.util.List;

/**
 * message and code of constraint
 *
 * @author: jasen.zhangj
 * @date: 16/12/14.
 */
public class ConstraintMessage {

    private static final String SEPARATOR = "|";

    private String              message;

    private List<String>        messageArgs;

    private String              code;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<String> getMessageArgs() {
        return messageArgs;
    }

    public void setMessageArgs(List<String> messageArgs) {
        this.messageArgs = messageArgs;
    }

    public boolean hasMessageArgs(){
        return messageArgs != null && !messageArgs.isEmpty();
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ConstraintMessage{");
        sb.append("message='").append(message).append('\'');
        sb.append(", code='").append(code).append('\'');
        sb.append(", messageArgs='").append(messageArgs).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public String combine() {
        if (code == null) {
            return message;
        } else {
            return message == null ? SEPARATOR + code : message + SEPARATOR + code;
        }
    }

    public String combine(String resolvedMessage) {
        return code == null ? resolvedMessage : resolvedMessage + SEPARATOR + code;
    }
}
