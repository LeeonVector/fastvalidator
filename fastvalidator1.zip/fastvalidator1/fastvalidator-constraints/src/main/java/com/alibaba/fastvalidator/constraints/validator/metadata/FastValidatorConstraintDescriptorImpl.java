package com.alibaba.fastvalidator.constraints.validator.metadata;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.ValidationException;
import javax.validation.metadata.ConstraintDescriptor;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.utils.ClassUtils;
import com.alibaba.fastvalidator.constraints.utils.TypeUtils;
import com.alibaba.fastvalidator.constraints.validator.helper.ConstraintDescriptorHelper;
import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.prompt.FastValidatorLogger;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;
import com.alibaba.fastvalidator.logger.Logger;

/**
 * Describes a single constraint (including it's composing constraints).
 *
 * @author jasen.zhangj
 */
public class FastValidatorConstraintDescriptorImpl<T extends Annotation> implements ConstraintDescriptor<T>, ConstraintValidator, Serializable {

    private static final long serialVersionUID = -8022584803152042203L;

    private T                                                      annotation;
    private Map<String, Object>                                    attributes;
    private boolean                                                isReportAsSingleInvalidConstraint;
    private final List<Class<? extends ConstraintValidator<T, ?>>> constraintValidatorClasses;
    private static final FastValidatorConstraintHelper             constraintHelper  = FastValidatorConstraintHelper.getInstance();
    private final Set<ConstraintDescriptor<?>>                     composingConstraints;
    private static final Logger                                    LOG = FastValidatorLogger.getFastValidatLog();

    private ConstraintValidator                                    constraintValidator;

    private static ConstraintValidator                             DEFAULT_VALIDATOR = new ConstraintValidator() {

                                                                                         @Override
                                                                                         public void initialize(Annotation constraintAnnotation) {

                                                                                         }

                                                                                         @Override
                                                                                         public boolean isValid(Object value,
                                                                                                                ConstraintValidatorContext context) {
                                                                                             return true;
                                                                                         }
                                                                                     };

    public FastValidatorConstraintDescriptorImpl(T annotation) {
        this(annotation, null);
    }

    public FastValidatorConstraintDescriptorImpl(Map<String, Object> attributes) {
        this.attributes = attributes;
        constraintValidatorClasses = new ArrayList<>();
        this.composingConstraints = new HashSet<>();
    }

    public FastValidatorConstraintDescriptorImpl(Class<?> targetClass) {
        attributes = new HashMap<>(1);
        this.composingConstraints = new HashSet<>();

        constraintValidatorClasses = new ArrayList<>();
    }

    public FastValidatorConstraintDescriptorImpl(T annotation, Class<?> targetClass) {
        this.annotation = annotation;
        Class<T> aClass = (Class<T>) annotation.annotationType();

        attributes = AnnotationUtils.getAnnotationParameterValues(annotation);

        this.isReportAsSingleInvalidConstraint = aClass.isAnnotationPresent(ReportAsSingleViolation.class);
        this.composingConstraints = new HashSet<>();

        if (aClass == ValidateBean.class && targetClass != null) {
            constraintValidatorClasses = new ArrayList<>();
            Class<ConstraintValidator<T, ?>> constraintValidator = null;

            try {
                constraintValidator = (Class<ConstraintValidator<T, ?>>) Class.forName(targetClass.getPackage().getName()
                                                                                       + ".validator."
                                                                                       + targetClass.getSimpleName()
                                                                                       + "Validator");
            } catch (Exception e) {
                LOG.warn("", "CAN_NOT_LOAD_VALIDATOR_CLASS", "the class:" + targetClass.getName()
                                       + " has bean announced the @ValidateBean, but have no effective constraints.");
            }

            if (constraintValidator != null) {
                constraintValidatorClasses.add(constraintValidator);
            }
        } else {
            this.constraintValidatorClasses = constraintHelper.getAllValidatorClasses(aClass);

            List<Annotation> composedAnnotations = constraintHelper.getComposingAnnotation(annotation);
            if (composedAnnotations != null && !composedAnnotations.isEmpty()) {
                List<AnnotationUtils.OverrideAttribute> overrideAttributeList = (List<AnnotationUtils.OverrideAttribute>) attributes.get(AnnotationUtils.OVERRIDE_ATTRIBUTES);
                for (Annotation composedAnnotation : composedAnnotations) {
                    Map<String, Object> overrideAttributeValues = new HashMap<>(4);
                    if (overrideAttributeList != null && !overrideAttributeList.isEmpty()) {
                        for (AnnotationUtils.OverrideAttribute overrideAttribute : overrideAttributeList) {
                            if (overrideAttribute.getOverrideConstraint() == composedAnnotation.annotationType()) {
                                overrideAttributeValues.put(overrideAttribute.getOverrideAttributeName(),
                                                            overrideAttribute.getValue());
                            }
                        }
                    }

                    composedAnnotation = AnnotationUtils.createAnnotation(composedAnnotation, overrideAttributeValues);
                    FastValidatorConstraintDescriptorImpl<Annotation> composedConstraintDescriptor = new FastValidatorConstraintDescriptorImpl<>(composedAnnotation);

                    composingConstraints.add(composedConstraintDescriptor);
                }
            }
        }
    }

    @Override
    public T getAnnotation() {
        return annotation;
    }

    @Override
    public String getMessageTemplate() {
        return ConstraintDescriptorHelper.getMessageTemplate(attributes);
    }

    @Override
    public Set<Class<?>> getGroups() {
        return ConstraintDescriptorHelper.getGroups(attributes);
    }

    @Override
    public Set<Class<? extends Payload>> getPayload() {
        return ConstraintDescriptorHelper.getPayload(attributes);
    }

    @Override
    public ConstraintTarget getValidationAppliesTo() {
        return ConstraintDescriptorHelper.getValidationAppliesTo(attributes);
    }

    @Override
    public List<Class<? extends ConstraintValidator<T, ?>>> getConstraintValidatorClasses() {
        return constraintValidatorClasses;
    }

    @Override
    public Map<String, Object> getAttributes() {
        return attributes;
    }

    @Override
    public Set<ConstraintDescriptor<?>> getComposingConstraints() {
        return composingConstraints;
    }

    @Override
    public boolean isReportAsSingleViolation() {
        return isReportAsSingleInvalidConstraint;
    }

    @Override
    public void initialize(Annotation constraintAnnotation) {

    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        return validate(value, context, this);
    }

    protected boolean validate(Object object, ConstraintValidatorContext context,
                               ConstraintDescriptor constraintDescriptor) {
        Class elementType = object == null ? Object.class : object.getClass();
        if (constraintValidator == null) {
            constraintValidator = findAndInitializeValidator(elementType, constraintDescriptor);
            if (constraintValidator != null) {
                constraintValidator.initialize(annotation);
            }
        }

        Set<ConstraintDescriptor> composedConstraintValidators = constraintDescriptor.getComposingConstraints();
        if (composedConstraintValidators != null && !composedConstraintValidators.isEmpty()) {
            for (ConstraintDescriptor composedConstraintValidator : composedConstraintValidators) {
                if (composedConstraintValidator instanceof FastValidatorConstraintDescriptorImpl) {
                    boolean result = ((FastValidatorConstraintDescriptorImpl) composedConstraintValidator).validate(object,
                                                                                                                    context,
                                                                                                                    composedConstraintValidator);
                    if (!result) {
                        return result;
                    }
                }
            }
        }

        return constraintValidator.isValid(object, context);
    }

    protected ConstraintValidator findAndInitializeValidator(Class<?> type, ConstraintDescriptor constraintDescriptor) {
        List<Class<? extends ConstraintValidator>> constraintValidatorClass = constraintDescriptor.getConstraintValidatorClasses();
        if (constraintValidatorClass == null || constraintValidatorClass.isEmpty()) {
            return DEFAULT_VALIDATOR;
        }

        Map<Type, Collection<Class<? extends ConstraintValidator>>> map = getValidatorsTypes(constraintValidatorClass);
        List<Type> types = new ArrayList<>();
        fillAssignableTypes(type, map.keySet(), types);
        reduceAssignableTypes(types);

        if (types.isEmpty()) {
            throw new IllegalArgumentException("No validator found for type: " + type.getName());
        } else if (types.size() > 1) {
            throw new IllegalArgumentException("More than one validator found for type: " + type.getName());
        }

        ConstraintValidator validator = ClassUtils.instantiate(map.get(types.get(0)).iterator().next());

        return validator;

    }

    private static void fillAssignableTypes(Type type, Set<Type> validatorsTypes, List<Type> suitableTypes) {
        for (final Type validatorType : validatorsTypes) {
            if (TypeUtils.isAssignable(type, validatorType) && !suitableTypes.contains(validatorType)) {
                suitableTypes.add(validatorType);
            }
        }
    }

    /**
     * Tries to reduce all assignable classes down to a single class.
     *
     * @param assignableTypes The set of all classes which are assignable to the class of the value to be validated and
     * which are handled by at least one of the validators for the specified constraint.
     */
    private static void reduceAssignableTypes(List<Type> assignableTypes) {
        if (assignableTypes.size() <= 1) {
            return; // no need to reduce
        }
        boolean removed = false;
        do {
            final Type type = assignableTypes.get(0);
            for (int i = 1; i < assignableTypes.size(); i++) {
                final Type nextType = assignableTypes.get(i);
                if (TypeUtils.isAssignable(nextType, type)) {
                    assignableTypes.remove(0);
                    i--;
                    removed = true;
                } else if (TypeUtils.isAssignable(type, nextType)) {
                    assignableTypes.remove(i--);
                    removed = true;
                }
            }
        } while (removed && assignableTypes.size() > 1);
    }

    private static Map<Type, Collection<Class<? extends ConstraintValidator>>> getValidatorsTypes(List<Class<? extends ConstraintValidator>> constraintValidatorClasses) {
        final Map<Type, Collection<Class<? extends ConstraintValidator>>> validatorsTypes = new HashMap<>();
        for (Class<? extends ConstraintValidator> validatorType : constraintValidatorClasses) {
            Type validatedType = TypeUtils.getTypeArguments(validatorType,
                                                            ConstraintValidator.class).get(ConstraintValidator.class.getTypeParameters()[1]);
            if (validatedType == null) {
                throw new ValidationException(String.format("Could not detect validated type for %s", validatorType));
            }
            if (validatedType instanceof GenericArrayType) {
                final Type componentType = TypeUtils.getArrayComponentType(validatedType);
                if (componentType instanceof Class<?>) {
                    validatedType = Array.newInstance((Class<?>) componentType, 0).getClass();
                }
            }
            if (!validatorsTypes.containsKey(validatedType)) {
                validatorsTypes.put(validatedType, new ArrayList<Class<? extends ConstraintValidator>>());
            }
            validatorsTypes.get(validatedType).add(validatorType);
        }
        return validatorsTypes;
    }

}
