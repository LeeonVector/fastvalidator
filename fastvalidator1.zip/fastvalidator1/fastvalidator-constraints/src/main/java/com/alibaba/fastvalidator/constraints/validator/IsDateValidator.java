package com.alibaba.fastvalidator.constraints.validator;

import java.text.SimpleDateFormat;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.alibaba.fastvalidator.constraints.IsDate;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;

/**
 * Validator for {@link IsDate}
 *
 * @author: jasen.zhangj
 * @date: 17/1/10.
 */
public class IsDateValidator implements ConstraintValidator<IsDate, String> {

    private String dateFormat;

    @Override
    public void initialize(IsDate constraintAnnotation) {
        this.dateFormat = constraintAnnotation.dateFormat();
        validateParameters();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
            simpleDateFormat.parse(value);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    protected void validateParameters() {
        if (StringUtils.isBlank(dateFormat)) {
            throw new IllegalArgumentException("dateFormat should not be blank");
        }
    }
}
