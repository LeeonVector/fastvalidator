package com.alibaba.fastvalidator.constraints.validator.helper;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import javax.validation.Constraint;
import javax.validation.ConstraintTarget;
import javax.validation.ConstraintValidator;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.AssertFalse;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.validation.constraintvalidation.SupportedValidationTarget;
import javax.validation.constraintvalidation.ValidationTarget;
import org.hibernate.validator.constraints.ConstraintComposition;
import org.hibernate.validator.constraints.EAN;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.LuhnCheck;
import org.hibernate.validator.constraints.Mod10Check;
import org.hibernate.validator.constraints.Mod11Check;
import org.hibernate.validator.constraints.ModCheck;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.ParameterScriptAssert;
import org.hibernate.validator.constraints.ScriptAssert;
import org.hibernate.validator.constraints.URL;
import org.hibernate.validator.constraints.br.CNPJ;
import org.hibernate.validator.constraints.br.CPF;
import com.alibaba.fastvalidator.constraints.Contains;
import com.alibaba.fastvalidator.constraints.EachValidate;
import com.alibaba.fastvalidator.constraints.IsDate;
import com.alibaba.fastvalidator.constraints.IsEnum;
import com.alibaba.fastvalidator.constraints.IsJSON;
import com.alibaba.fastvalidator.constraints.NotEquals;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.collection.EachAssertFalse;
import com.alibaba.fastvalidator.constraints.collection.EachAssertTrue;
import com.alibaba.fastvalidator.constraints.collection.EachCreditCardNumber;
import com.alibaba.fastvalidator.constraints.collection.EachDecimalMax;
import com.alibaba.fastvalidator.constraints.collection.EachDecimalMin;
import com.alibaba.fastvalidator.constraints.collection.EachDigits;
import com.alibaba.fastvalidator.constraints.collection.EachEAN;
import com.alibaba.fastvalidator.constraints.collection.EachEmail;
import com.alibaba.fastvalidator.constraints.collection.EachFuture;
import com.alibaba.fastvalidator.constraints.collection.EachIsDate;
import com.alibaba.fastvalidator.constraints.collection.EachIsEnum;
import com.alibaba.fastvalidator.constraints.collection.EachIsJSON;
import com.alibaba.fastvalidator.constraints.collection.EachLength;
import com.alibaba.fastvalidator.constraints.collection.EachMax;
import com.alibaba.fastvalidator.constraints.collection.EachMin;
import com.alibaba.fastvalidator.constraints.collection.EachNotBlank;
import com.alibaba.fastvalidator.constraints.collection.EachNotEmpty;
import com.alibaba.fastvalidator.constraints.collection.EachNotNull;
import com.alibaba.fastvalidator.constraints.collection.EachParameterScriptAssert;
import com.alibaba.fastvalidator.constraints.collection.EachPast;
import com.alibaba.fastvalidator.constraints.collection.EachPattern;
import com.alibaba.fastvalidator.constraints.collection.EachRange;
import com.alibaba.fastvalidator.constraints.collection.EachScriptAssert;
import com.alibaba.fastvalidator.constraints.collection.EachSize;
import com.alibaba.fastvalidator.constraints.collection.EachURL;
import com.alibaba.fastvalidator.constraints.validator.IsDateValidator;
import com.alibaba.fastvalidator.constraints.validator.IsEnumValidator;
import com.alibaba.fastvalidator.constraints.validator.IsJSONValidator;
import com.alibaba.fastvalidator.constraints.validator.NotEqualsValidator;
import com.alibaba.fastvalidator.constraints.validator.ValidateBeanValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.AssertFalseValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.AssertTrueValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.DecimalMaxValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.DecimalMaxValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.DecimalMinValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.DecimalMinValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.DigitsValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.DigitsValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.MaxValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.MaxValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.MinValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.MinValidatorForNumber;
import com.alibaba.fastvalidator.constraints.validator.bv.NotNullValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.NullValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.PatternValidator;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArray;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfBoolean;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfByte;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfChar;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfDouble;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfFloat;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfInt;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForArraysOfLong;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForCollection;
import com.alibaba.fastvalidator.constraints.validator.bv.size.SizeValidatorForMap;
import com.alibaba.fastvalidator.constraints.validator.bv.time.future.FutureValidatorForCalendar;
import com.alibaba.fastvalidator.constraints.validator.bv.time.future.FutureValidatorForDate;
import com.alibaba.fastvalidator.constraints.validator.bv.time.past.PastValidatorForCalendar;
import com.alibaba.fastvalidator.constraints.validator.bv.time.past.PastValidatorForDate;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArrays;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfBoolean;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfByte;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfChar;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfDouble;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfFloat;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfInt;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfLong;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForArraysOfShort;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForCharSequence;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForCollection;
import com.alibaba.fastvalidator.constraints.validator.fv.contains.ContainsValidatorForMap;
import com.alibaba.fastvalidator.constraints.validator.fv.each.EachValidatorForCollection;
import com.alibaba.fastvalidator.constraints.validator.fv.each.EachValidatorForString;
import com.alibaba.fastvalidator.constraints.validator.hv.EANValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.EmailValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.LengthValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.LuhnCheckValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.Mod10CheckValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.Mod11CheckValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.ModCheckValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.NotBlankValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.ParameterScriptAssertValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.ScriptAssertValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.URLValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.br.CNPJValidator;
import com.alibaba.fastvalidator.constraints.validator.hv.br.CPFValidator;
import com.alibaba.fastvalidator.constraints.validator.prompt.MessageFormatter;
import com.alibaba.fastvalidator.constraints.validator.utils.Contracts;

/**
 * constraint helper
 *
 * @author: jasen.zhangj
 * @date: 16/9/13.
 */
public class FastValidatorConstraintHelper {

    private static final FastValidatorConstraintHelper                       INSTANCE                             = new FastValidatorConstraintHelper();

    private static final List<String>                                        NON_COMPOSING_CONSTRAINT_ANNOTATIONS = new ArrayList<>();

    // immutable
    private final Map<Class<? extends Annotation>, List<? extends Class<?>>> builtinConstraints;

    private final ValidatorClassMap                                          validatorClasses                     = new ValidatorClassMap();

    public static final String                                               GROUPS                               = "groups";
    public static final String                                               PAYLOAD                              = "payload";
    public static final String                                               MESSAGE                              = "message";
    public static final String                                               VALIDATION_APPLIES_TO                = "validationAppliesTo";

    static {
        NON_COMPOSING_CONSTRAINT_ANNOTATIONS.add(Documented.class.getName());
        NON_COMPOSING_CONSTRAINT_ANNOTATIONS.add(Retention.class.getName());
        NON_COMPOSING_CONSTRAINT_ANNOTATIONS.add(Target.class.getName());
        NON_COMPOSING_CONSTRAINT_ANNOTATIONS.add(Constraint.class.getName());
        NON_COMPOSING_CONSTRAINT_ANNOTATIONS.add(ReportAsSingleViolation.class.getName());
    }

    public FastValidatorConstraintHelper() {
        Map<Class<? extends Annotation>, List<? extends Class<?>>> tmpConstraints = new HashMap<>();

        putConstraint(tmpConstraints, AssertFalse.class, AssertFalseValidator.class);
        putConstraint(tmpConstraints, AssertTrue.class, AssertTrueValidator.class);
        putConstraint(tmpConstraints, CNPJ.class, CNPJValidator.class);
        putConstraint(tmpConstraints, CPF.class, CPFValidator.class);

        putConstraints(tmpConstraints, DecimalMax.class, DecimalMaxValidatorForNumber.class,
                       DecimalMaxValidatorForCharSequence.class);
        putConstraints(tmpConstraints, DecimalMin.class, DecimalMinValidatorForNumber.class,
                       DecimalMinValidatorForCharSequence.class);
        putConstraints(tmpConstraints, Digits.class, DigitsValidatorForCharSequence.class,
                       DigitsValidatorForNumber.class);

        List<Class<? extends ConstraintValidator<Future, ?>>> futureValidators = new ArrayList<>(11);
        futureValidators.add(FutureValidatorForCalendar.class);
        futureValidators.add(FutureValidatorForDate.class);

        putConstraints(tmpConstraints, Future.class, futureValidators);

        putConstraints(tmpConstraints, Max.class, MaxValidatorForNumber.class, MaxValidatorForCharSequence.class);
        putConstraints(tmpConstraints, Min.class, MinValidatorForNumber.class, MinValidatorForCharSequence.class);
        putConstraint(tmpConstraints, NotNull.class, NotNullValidator.class);
        putConstraint(tmpConstraints, Null.class, NullValidator.class);

        List<Class<? extends ConstraintValidator<Past, ?>>> pastValidators = new ArrayList<>(11);
        pastValidators.add(PastValidatorForCalendar.class);
        pastValidators.add(PastValidatorForDate.class);

        putConstraints(tmpConstraints, Past.class, pastValidators);

        putConstraint(tmpConstraints, Pattern.class, PatternValidator.class);

        List<Class<? extends ConstraintValidator<Size, ?>>> sizeValidators = new ArrayList<>(11);
        sizeValidators.add(SizeValidatorForCharSequence.class);
        sizeValidators.add(SizeValidatorForCollection.class);
        sizeValidators.add(SizeValidatorForArray.class);
        sizeValidators.add(SizeValidatorForMap.class);
        sizeValidators.add(SizeValidatorForArraysOfBoolean.class);
        sizeValidators.add(SizeValidatorForArraysOfByte.class);
        sizeValidators.add(SizeValidatorForArraysOfChar.class);
        sizeValidators.add(SizeValidatorForArraysOfDouble.class);
        sizeValidators.add(SizeValidatorForArraysOfFloat.class);
        sizeValidators.add(SizeValidatorForArraysOfInt.class);
        sizeValidators.add(SizeValidatorForArraysOfLong.class);

        putConstraints(tmpConstraints, Size.class, sizeValidators);

        putConstraint(tmpConstraints, EAN.class, EANValidator.class);
        putConstraint(tmpConstraints, Email.class, EmailValidator.class);
        putConstraint(tmpConstraints, Length.class, LengthValidator.class);
        putConstraint(tmpConstraints, ModCheck.class, ModCheckValidator.class);
        putConstraint(tmpConstraints, LuhnCheck.class, LuhnCheckValidator.class);
        putConstraint(tmpConstraints, Mod10Check.class, Mod10CheckValidator.class);
        putConstraint(tmpConstraints, Mod11Check.class, Mod11CheckValidator.class);
        putConstraint(tmpConstraints, NotBlank.class, NotBlankValidator.class);
        putConstraint(tmpConstraints, ParameterScriptAssert.class, ParameterScriptAssertValidator.class);
        // putConstraint( tmpConstraints, SafeHtml.class, SafeHtmlValidator.class );
        putConstraint(tmpConstraints, ScriptAssert.class, ScriptAssertValidator.class);
        putConstraint(tmpConstraints, URL.class, URLValidator.class);

        // put collection validator
        putConstraint(tmpConstraints, EachAssertFalse.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachAssertTrue.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachCreditCardNumber.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachDecimalMax.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachDecimalMin.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachDigits.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachEAN.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachEmail.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachFuture.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachLength.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachMax.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachMin.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachNotBlank.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachNotEmpty.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachNotNull.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachParameterScriptAssert.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachPast.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachPattern.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachRange.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachScriptAssert.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachSize.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachURL.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachIsEnum.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachIsDate.class, CommonEachValidator.class);
        putConstraint(tmpConstraints, EachIsJSON.class, CommonEachValidator.class);

        putConstraint(tmpConstraints, ValidateBean.class, ValidateBeanValidator.class);
        putConstraint(tmpConstraints, IsEnum.class, IsEnumValidator.class);
        putConstraint(tmpConstraints, IsDate.class, IsDateValidator.class);
        putConstraint(tmpConstraints, IsJSON.class, IsJSONValidator.class);

        //Contains validator add by jipengfei
        List<Class<? extends ConstraintValidator<Contains, ?>>> containsValidators = new ArrayList<>(11);
        containsValidators.add(ContainsValidatorForCharSequence.class);
        containsValidators.add(ContainsValidatorForCollection.class);
        containsValidators.add(ContainsValidatorForMap.class);
        containsValidators.add(ContainsValidatorForArraysOfByte.class);
        containsValidators.add(ContainsValidatorForArraysOfFloat.class);
        containsValidators.add(ContainsValidatorForArraysOfChar.class);
        containsValidators.add(ContainsValidatorForArraysOfLong.class);
        containsValidators.add(ContainsValidatorForArraysOfShort.class);
        containsValidators.add(ContainsValidatorForArraysOfBoolean.class);
        containsValidators.add(ContainsValidatorForArraysOfInt.class);
        containsValidators.add(ContainsValidatorForArraysOfDouble.class);
        containsValidators.add(ContainsValidatorForArrays.class);
        putConstraints(tmpConstraints, Contains.class, containsValidators);

        putConstraint(tmpConstraints, NotEquals.class, NotEqualsValidator.class);

        List<Class<? extends ConstraintValidator<EachValidate, ?>>> eachValidators = new ArrayList<>(2);
        eachValidators.add(EachValidatorForCollection.class);
        eachValidators.add(EachValidatorForString.class);
        putConstraints(tmpConstraints, EachValidate.class, eachValidators);

        this.builtinConstraints = Collections.unmodifiableMap(tmpConstraints);
    }

    public static FastValidatorConstraintHelper getInstance() {
        return INSTANCE;
    }

    public Set<Class<? extends Annotation>> getAllConstraintAnnotation(){
        Set<Class<? extends Annotation>> constrainAnnotations = new HashSet<>();
        constrainAnnotations.addAll(builtinConstraints.keySet());
        constrainAnnotations.addAll(validatorClasses.getConstrainsAnnotations());

        return Collections.unmodifiableSet(constrainAnnotations);
    }

    public List<Annotation> getComposingAnnotation(Annotation annotation, List<Annotation> annotationList, boolean recursive) {
        Annotation[] annotations = annotation.annotationType().getAnnotations();
        for (Annotation parentAnnotation : annotations) {
            if (!isNonCompostingConstraintAnnotation(parentAnnotation.annotationType())
                && isConstraintAnnotation(parentAnnotation.annotationType())) {
                annotationList.add(parentAnnotation);
                if (recursive) {
                    getComposingAnnotation(parentAnnotation, annotationList, recursive);
                }
            }
        }

        return annotationList;
    }

    public List<Annotation> getComposingAnnotation(Annotation annotation) {
        return getComposingAnnotation(annotation, new ArrayList<Annotation>(), false);
    }

    public List<Annotation> getAllComposingAnnotation(Annotation annotation) {
        return getComposingAnnotation(annotation, new ArrayList<Annotation>(), true);
    }


    public static boolean isNonCompostingConstraintAnnotation(Class<? extends Annotation> declaredAnnotationType) {
        return NON_COMPOSING_CONSTRAINT_ANNOTATIONS.contains(declaredAnnotationType.getName());
    }

    protected <A extends Annotation> void putConstraint(Map<Class<? extends Annotation>, List<? extends Class<?>>> validators,
                                                        Class<? extends Annotation> constraintType,
                                                        Class<? extends ConstraintValidator<?, ?>> validatorType) {
        validators.put(constraintType, Collections.singletonList(validatorType));
    }

    protected <A extends Annotation> void putConstraints(Map<Class<? extends Annotation>, List<? extends Class<?>>> validators,
                                                         Class<A> constraintType,
                                                         Class<? extends ConstraintValidator<A, ?>> validatorType1,
                                                         Class<? extends ConstraintValidator<A, ?>> validatorType2) {
        validators.put(constraintType,
                       Collections.unmodifiableList(Arrays.<Class<?>> asList(validatorType1, validatorType2)));
    }

    protected <A extends Annotation> void putConstraints(Map<Class<? extends Annotation>, List<? extends Class<?>>> validators,
                                                         Class<A> constraintType,
                                                         List<Class<? extends ConstraintValidator<A, ?>>> validatorTypes) {
        validators.put(constraintType, Collections.unmodifiableList(validatorTypes));
    }

    /**
     * Returns the constraint validator classes for the given constraint annotation type, as retrieved from
     * <ul>
     * <li>{@link Constraint#validatedBy()},
     * <li>internally registered validators for built-in constraints and</li>
     * <li>XML configuration.</li>
     * </ul>
     * The result is cached internally.
     *
     * @param annotationType The constraint annotation type.
     * @param <A> the type of the annotation
     * @return The validator classes for the given type.
     */
    public <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> getAllValidatorClasses(Class<A> annotationType) {
        Contracts.assertNotNull(annotationType);

        List<Class<? extends ConstraintValidator<A, ?>>> classes = validatorClasses.get(annotationType);

        if (classes == null) {
            classes = getDefaultValidatorClasses(annotationType);

            List<Class<? extends ConstraintValidator<A, ?>>> cachedValidatorClasses = validatorClasses.putIfAbsent(annotationType,
                                                                                                                   classes);

            if (cachedValidatorClasses != null) {
                classes = cachedValidatorClasses;
            }
        }

        return Collections.unmodifiableList(classes);
    }

    /**
     * Returns the constraint validator classes for the given constraint annotation type, as retrieved from
     * <ul>
     * <li>{@link Constraint#validatedBy()},
     * <li>internally registered validators for built-in constraints and</li>
     * <li>XML configuration.</li>
     * </ul>
     * The result is cached internally.
     *
     * @param annotationType The constraint annotation type.
     * @param <A> the type of the annotation
     * @return The validator classes for the given type.
     */
    public <A extends Annotation> Class<? extends ConstraintValidator<A, ?>>[] getAllValidatorClassesArray(Class<A> annotationType) {
        List<Class<? extends ConstraintValidator<A, ?>>> list =  getAllValidatorClasses(annotationType);
        return list.toArray(new Class[list.size()]);
    }

    /**
     * Returns the default validators for the given constraint type.
     *
     * @param annotationType The constraint annotation type.
     * @return A list with the default validators as retrieved from {@link Constraint#validatedBy()} or the list of
     * validators for built-in constraints.
     */
    @SuppressWarnings("unchecked")
    private <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> getDefaultValidatorClasses(Class<A> annotationType) {
        // safe cause all CV for a given annotation A are CV<A, ?>
        final List<Class<? extends ConstraintValidator<A, ?>>> builtInValidators = (List<Class<? extends ConstraintValidator<A, ?>>>) builtinConstraints.get(annotationType);

        if (builtInValidators != null) {
            return builtInValidators;
        }

        Constraint constraintAnnotation = annotationType.getAnnotation(Constraint.class);
        if (constraintAnnotation == null){
            return Collections.emptyList();
        }

        Class<? extends ConstraintValidator<A, ?>>[] validatedBy = (Class<? extends ConstraintValidator<A, ?>>[]) constraintAnnotation.validatedBy();
        return Arrays.asList(validatedBy);
    }

    /**
     * Returns those validator classes for the given constraint annotation matching the given target.
     *
     * @param annotationType The annotation of interest.
     * @param validationTarget The target, either annotated element or parameters.
     * @param <A> the type of the annotation
     * @return A list with matching validator classes.
     */
    public <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> findValidatorClasses(Class<A> annotationType,
                                                                                                        ValidationTarget validationTarget) {
        List<Class<? extends ConstraintValidator<A, ?>>> validatorClasses = getAllValidatorClasses(annotationType);
        List<Class<? extends ConstraintValidator<A, ?>>> matchingValidatorClasses = new ArrayList<>();

        for (Class<? extends ConstraintValidator<A, ?>> validatorClass : validatorClasses) {
            if (supportsValidationTarget(validatorClass, validationTarget)) {
                matchingValidatorClasses.add(validatorClass);
            }
        }

        return matchingValidatorClasses;
    }

    private boolean supportsValidationTarget(Class<? extends ConstraintValidator<?, ?>> validatorClass,
                                             ValidationTarget target) {
        SupportedValidationTarget supportedTargetAnnotation = validatorClass.getAnnotation(SupportedValidationTarget.class);

        // by default constraints target the annotated element
        if (supportedTargetAnnotation == null) {
            return target == ValidationTarget.ANNOTATED_ELEMENT;
        }

        return Arrays.asList(supportedTargetAnnotation.value()).contains(target);
    }

    /**
     * Registers the given validator classes with the given constraint annotation type.
     *
     * @param annotationType The constraint annotation type
     * @param definitionClasses The validators to register
     * @param keepDefaultClasses Whether any default validators should be kept or not
     * @param <A> the type of the annotation
     */
    public <A extends Annotation> void putValidatorClasses(Class<A> annotationType,
                                                           List<Class<? extends ConstraintValidator<A, ?>>> definitionClasses,
                                                           boolean keepDefaultClasses) {
        if (keepDefaultClasses) {
            List<Class<? extends ConstraintValidator<A, ?>>> defaultValidators = getDefaultValidatorClasses(annotationType);
            for (Class<? extends ConstraintValidator<A, ?>> defaultValidator : defaultValidators) {
                definitionClasses.add(0, defaultValidator);
            }
        }

        validatorClasses.put(annotationType, definitionClasses);
    }

    /**
     * Checks whether a given annotation is a multi value constraint or not.
     *
     * @param annotationType the annotation type to check.
     * @return {@code true} if the specified annotation is a multi value constraints, {@code false} otherwise.
     */
    public boolean isMultiValueConstraint(Class<? extends Annotation> annotationType) {
        boolean isMultiValueConstraint = false;
        final Method method = run(annotationType, "value");
        if (method != null) {
            Class<?> returnType = method.getReturnType();
            if (returnType.isArray() && returnType.getComponentType().isAnnotation()) {
                @SuppressWarnings("unchecked")
                Class<? extends Annotation> componentType = (Class<? extends Annotation>) returnType.getComponentType();
                if (isConstraintAnnotation(componentType) || isBuiltinConstraint(componentType)) {
                    isMultiValueConstraint = true;
                } else {
                    isMultiValueConstraint = false;
                }
            }
        }
        return isMultiValueConstraint;
    }

    private boolean isBuiltinConstraint(Class<? extends Annotation> annotationType) {
        return builtinConstraints.containsKey(annotationType);
    }

    /**
     * Returns the constraints which are part of the given multi-value constraint.
     * <p>
     * Invoke {@link #isMultiValueConstraint(Class)} prior to calling this method to check whether a given constraint
     * actually is a multi-value constraint.
     *
     * @param multiValueConstraint the multi-value constraint annotation from which to retrieve the contained
     * constraints
     * @param <A> the type of the annotation
     * @return A list of constraint annotations, may be empty but never {@code null}.
     */
    public <A extends Annotation> List<Annotation> getConstraintsFromMultiValueConstraint(A multiValueConstraint) {
        Annotation[] annotations = run(multiValueConstraint, "value", Annotation[].class);
        return Arrays.asList(annotations);
    }

    public <A extends Object> A run(Annotation annotation, String parameterName, Class<A> type) {
        try {
            Method m = annotation.getClass().getMethod(parameterName);
            m.setAccessible(true);
            Object o = m.invoke(annotation);
            if (type.isAssignableFrom(o.getClass())) {
                return (A) o;
            } else {
                throw MessageFormatter.getWrongParameterTypeException(type.getName(), o.getClass().getName());
            }
        } catch (NoSuchMethodException e) {
            throw MessageFormatter.getUnableToFindAnnotationParameterException(parameterName, e);
        } catch (IllegalAccessException e) {
            throw MessageFormatter.getUnableToGetAnnotationParameterException(parameterName, annotation.getClass().getName(), e);
        } catch (InvocationTargetException e) {
            throw MessageFormatter.getUnableToGetAnnotationParameterException(parameterName, annotation.getClass().getName(), e);
        }
    }

    public boolean isConstraintComposition(Class<? extends Annotation> annotationType) {
        return annotationType == ConstraintComposition.class;
    }

    /**
     * Checks whether the specified annotation is a valid constraint annotation. A constraint annotation has to fulfill
     * the following conditions:
     * <ul>
     * <li>Must be annotated with {@link Constraint}
     * <li>Define a message parameter</li>
     * <li>Define a group parameter</li>
     * <li>Define a payload parameter</li>
     * </ul>
     *
     * @param annotationType The annotation type to test.
     * @return {@code true} if the annotation fulfills the above conditions, {@code false} otherwise.
     */
    public boolean isConstraintAnnotation(Class<? extends Annotation> annotationType) {
        if (annotationType.getAnnotation(Constraint.class) == null) {
            return false;
        }

        assertMessageParameterExists(annotationType);
        assertGroupsParameterExists(annotationType);
        assertPayloadParameterExists(annotationType);
        assertValidationAppliesToParameterSetUpCorrectly(annotationType);
        assertNoParameterStartsWithValid(annotationType);

        return true;
    }

    private Method run(Class<? extends Annotation> clazz, String methodName) {
        try {
            return clazz.getMethod(methodName);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    private void assertMessageParameterExists(Class<? extends Annotation> annotationType) {
        final Method method = run(annotationType, MESSAGE);
        if (method == null) {
            throw MessageFormatter.getConstraintWithoutMandatoryParameterException(MESSAGE, annotationType.getName());
        }
        if (method.getReturnType() != String.class) {
            throw MessageFormatter.getWrongTypeForMessageParameterException(annotationType.getName());
        }
    }

    private void assertGroupsParameterExists(Class<? extends Annotation> annotationType) {
        try {
            final Method method = run(annotationType, GROUPS);
            if (method == null) {
                throw MessageFormatter.getConstraintWithoutMandatoryParameterException(GROUPS, annotationType.getName());
            }
            Class<?>[] defaultGroups = (Class<?>[]) method.getDefaultValue();
            if (defaultGroups.length != 0) {
                throw MessageFormatter.getWrongDefaultValueForGroupsParameterException(annotationType.getName());
            }
        } catch (ClassCastException e) {
            throw MessageFormatter.getWrongTypeForGroupsParameterException(annotationType.getName(), e);
        }
    }

    private void assertPayloadParameterExists(Class<? extends Annotation> annotationType) {
        try {
            final Method method = run(annotationType, PAYLOAD);
            if (method == null) {
                throw MessageFormatter.getConstraintWithoutMandatoryParameterException(PAYLOAD, annotationType.getName());
            }
            Class<?>[] defaultPayload = (Class<?>[]) method.getDefaultValue();
            if (defaultPayload.length != 0) {
                throw MessageFormatter.getWrongDefaultValueForPayloadParameterException(annotationType.getName());
            }
        } catch (ClassCastException e) {
            throw MessageFormatter.getWrongTypeForPayloadParameterException(annotationType.getName(), e);
        }
    }

    private void assertValidationAppliesToParameterSetUpCorrectly(Class<? extends Annotation> annotationType) {
        boolean hasGenericValidators = !findValidatorClasses(annotationType,
                                                             ValidationTarget.ANNOTATED_ELEMENT).isEmpty();
        boolean hasCrossParameterValidator = !findValidatorClasses(annotationType,
                                                                   ValidationTarget.PARAMETERS).isEmpty();
        final Method method = run(annotationType, VALIDATION_APPLIES_TO);

        if (hasGenericValidators && hasCrossParameterValidator) {
            if (method == null) {
                throw MessageFormatter.getGenericAndCrossParameterConstraintDoesNotDefineValidationAppliesToParameterException(annotationType.getName());
            }
            if (method.getReturnType() != ConstraintTarget.class) {
                throw MessageFormatter.getValidationAppliesToParameterMustHaveReturnTypeConstraintTargetException(annotationType.getName());
            }
            ConstraintTarget defaultValue = (ConstraintTarget) method.getDefaultValue();
            if (defaultValue != ConstraintTarget.IMPLICIT) {
                throw MessageFormatter.getValidationAppliesToParameterMustHaveDefaultValueImplicitException(annotationType.getName());
            }
        } else if (method != null) {
            throw MessageFormatter.getValidationAppliesToParameterMustNotBeDefinedForNonGenericAndCrossParameterConstraintException(annotationType.getName());
        }
    }

    private void assertNoParameterStartsWithValid(Class<? extends Annotation> annotationType) {
        final Method[] methods = annotationType.getDeclaredMethods();
        for (Method m : methods) {
            if (m.getName().startsWith("valid") && !m.getName().equals(VALIDATION_APPLIES_TO)) {
                throw MessageFormatter.getConstraintParametersCannotStartWithValidException();
            }
        }
    }

    /**
     * A type-safe wrapper around a concurrent map from constraint types to associated validator classes. The casts are
     * safe as data is added trough the typed API only.
     *
     * @author Gunnar Morling
     */
    @SuppressWarnings("unchecked")
    private static class ValidatorClassMap {

        private final ConcurrentMap<Class<? extends Annotation>, List<? extends Class<?>>> constraintValidatorClasses = new ConcurrentHashMap<>();

        private <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> get(Class<A> annotationType) {
            return (List<Class<? extends ConstraintValidator<A, ?>>>) constraintValidatorClasses.get(annotationType);
        }

        private <A extends Annotation> void put(Class<A> annotationType,
                                                List<Class<? extends ConstraintValidator<A, ?>>> validatorClasses) {
            constraintValidatorClasses.put(annotationType, validatorClasses);
        }

        private <A extends Annotation> List<Class<? extends ConstraintValidator<A, ?>>> putIfAbsent(Class<A> annotationType,
                                                                                                    List<Class<? extends ConstraintValidator<A, ?>>> classes) {
            return (List<Class<? extends ConstraintValidator<A, ?>>>) constraintValidatorClasses.putIfAbsent(annotationType,
                                                                                                             classes);
        }

        public Set<Class<? extends Annotation>> getConstrainsAnnotations(){
            return constraintValidatorClasses.keySet();
        }
    }
}
