package com.alibaba.fastvalidator.constraints.collection;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import com.alibaba.fastvalidator.constraints.IsEnum;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @see IsEnum
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
@Documented
@Retention(RUNTIME)
@Target({ METHOD, FIELD, ANNOTATION_TYPE })
@EachConstraint(validateAs = IsEnum.class)
@Constraint(validatedBy = {CommonEachValidator.class})
public @interface EachIsEnum {

    /***
     * @return enum type.
     */
    Class<? extends Enum<?>> enumType();

    String message() default "should be {enumType} type";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };
}
