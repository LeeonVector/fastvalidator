package com.alibaba.fastvalidator.constraints;


import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Asserts that the annotated string, collection, map or array(string,long,int,char,byte,float,boolean,double) is not {@code empty} or empty
 *
 * @author jipengfei
 * @date 2017.2.20
 */
@Documented
@Constraint(validatedBy = {  })
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@ReportAsSingleViolation
public @interface Contains {
    String value();

    Type type();

    String message() default "should be contains {value}";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    @Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
    @Retention(RUNTIME)
    @Documented
    public @interface List {
        Contains[] value();
    }

    public enum Type{
        STRING,
        DOUBLE,
        INT,
        LONG,
        CHAR,
        FLOAT,
        SHORT,
        BOOLEAN,
        BYTE,
    }

}
