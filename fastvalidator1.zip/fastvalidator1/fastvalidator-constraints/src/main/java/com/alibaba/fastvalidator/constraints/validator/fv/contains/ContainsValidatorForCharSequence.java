package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public class ContainsValidatorForCharSequence implements ConstraintValidator<Contains, CharSequence> {

    private CharSequence constraintValue;

    @Override
    public void initialize(Contains constraintAnnotation) {
        constraintValue = constraintAnnotation.value();
    }

    @Override
    public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
        if (value == null || constraintValue == null) {
            return true;
        }
        return value.toString().contains(constraintValue);
    }
}
