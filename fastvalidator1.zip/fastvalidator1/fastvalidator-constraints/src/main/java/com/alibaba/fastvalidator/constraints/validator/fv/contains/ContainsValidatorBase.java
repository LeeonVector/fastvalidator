package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public abstract class ContainsValidatorBase {

    protected Object containsValue;

    public void initialize(Contains constraintAnnotation) {
        String value = constraintAnnotation.value();
        Contains.Type type = constraintAnnotation.type();
        if(Contains.Type.STRING.equals(type)){
            containsValue =value;
        }else if(Contains.Type.BOOLEAN.equals(type)){
            containsValue = Boolean.parseBoolean(value);
        }else if(Contains.Type.INT.equals(type)){
            containsValue = Integer.parseInt(value);
        }else if(Contains.Type.LONG.equals(type)){
            containsValue = Long.parseLong(value);
        }else if(Contains.Type.FLOAT.equals(type)){
            containsValue = Float.parseFloat(value);
        }else if(Contains.Type.DOUBLE.equals(type)){
            containsValue = Double.parseDouble(value);
        }else if(Contains.Type.SHORT.equals(type)){
            containsValue = Short.parseShort(value);
        }else if(Contains.Type.BYTE.equals(type)){
            containsValue = Byte.parseByte(value);
        }else if(Contains.Type.CHAR.equals(type)){
            containsValue = value.charAt(0);
        }
    }
}

