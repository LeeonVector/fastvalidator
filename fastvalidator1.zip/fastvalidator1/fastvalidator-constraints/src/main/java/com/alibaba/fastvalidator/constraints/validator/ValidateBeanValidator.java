package com.alibaba.fastvalidator.constraints.validator;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.metadata.ConstraintDescriptor;
import com.alibaba.fastvalidator.constraints.ValidateBean;
import com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext;
import com.alibaba.fastvalidator.constraints.validator.metadata.FastValidatorConstraintDescriptorImpl;
import com.alibaba.fastvalidator.constraints.validator.prompt.FastValidatorLogger;
import com.alibaba.fastvalidator.logger.Logger;

/**
 * validator for {@link ValidateBean}
 *
 * @author: jasen.zhangj
 * @date: 16/11/24.
 */
public class ValidateBeanValidator implements ConstraintValidator<ValidateBean, Object> {

    @Override
    public void initialize(ValidateBean constraintAnnotation) {

    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        ValidateBeanInfo validateBeanInfo = getValidateBeanConstraintValidator(value.getClass());
        ConstraintValidator constraintValidator = validateBeanInfo.getConstraintValidator();
        if (constraintValidator == null) {
            return true;
        }

        if (!(context instanceof FastValidatorBeanContext)){
            return true;
        }

        return constraintValidator.isValid(value, context);
    }

    private static final Map<Class, ValidateBeanInfo> validatorBeanValidatorMap = new ConcurrentHashMap<>();

    public static ValidateBeanInfo getValidateBeanConstraintValidator(Class clazz) {
        ValidateBeanInfo validateBeanInfo = validatorBeanValidatorMap.get(clazz);

        if (validateBeanInfo == null) {
            // parent bean may not declare @ValidateBean
            Annotation annotation = clazz.getAnnotation(ValidateBean.class);

            FastValidatorConstraintDescriptorImpl fastConstraintDescriptor;
            if (annotation == null) {
                fastConstraintDescriptor = new FastValidatorConstraintDescriptorImpl(clazz);
            } else {
                fastConstraintDescriptor = new FastValidatorConstraintDescriptorImpl(annotation, clazz);
            }

            validateBeanInfo = new ValidateBeanInfo(fastConstraintDescriptor);
            validatorBeanValidatorMap.put(clazz, validateBeanInfo);
        }

        return validateBeanInfo;
    }

    public static class ValidateBeanInfo {

        private ConstraintDescriptor fastConstraintDescriptor;
        private ConstraintValidator  constraintValidator;

        private static final Logger LOG = FastValidatorLogger.getFastValidatLog();

        ValidateBeanInfo(ConstraintDescriptor fastConstraintDescriptor) {
            this.fastConstraintDescriptor = fastConstraintDescriptor;
            initialConstraintValidator();
        }

        private void initialConstraintValidator() {
            List<Class<? extends ConstraintValidator>> list = fastConstraintDescriptor.getConstraintValidatorClasses();
            if (list != null && !list.isEmpty()) {
                Class<? extends ConstraintValidator> constraintValidatorClass = list.get(0);
                if (constraintValidatorClass != null) {
                    try {
                        constraintValidator = constraintValidatorClass.newInstance();
                    } catch (Exception e) {
                        LOG.error("CAN_NOT_LOAD_VALIDATOR", "can't load validator " + constraintValidatorClass, e);
                    }

                    constraintValidator.initialize(fastConstraintDescriptor.getAnnotation());
                }
            }
        }

        public ConstraintValidator getConstraintValidator() {
            return constraintValidator;
        }

        public ConstraintDescriptor getFastConstraintDescriptor() {
            return fastConstraintDescriptor;
        }
    }
}
