package com.alibaba.fastvalidator.constraints.validator.fv.each;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Map;

import javax.validation.ConstraintValidator;

import com.alibaba.fastvalidator.constraints.EachValidate;
import com.alibaba.fastvalidator.constraints.validator.metadata.FastValidatorConstraintDescriptorImpl;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;

/**
 * Base validator class for {@link com.alibaba.fastvalidator.constraints.EachValidate}
 *
 * @author: jasen.zhangj
 * @date: 2017-08-07
 */
abstract class EachValidatorBase<T> implements ConstraintValidator<EachValidate, T> {

    protected Class                                 constraintType;

    protected EachValidate.ConstraintProperty[]     constraintProperties;

    protected FastValidatorConstraintDescriptorImpl descriptor;

    @Override
    public void initialize(EachValidate constraintAnnotation) {
        constraintType = constraintAnnotation.constraint();
        constraintProperties = constraintAnnotation.constraintProperties();

        Map<String, Object> attributes = new HashMap<>(16);
        for (EachValidate.ConstraintProperty constraintProperty : constraintProperties) {
            attributes.put(constraintProperty.name(), constraintProperty.value());
        }

        Annotation annotation = createConstraintAndCopyAttributes(constraintType, attributes);
        descriptor = createConstraintDescriptor(annotation);
    }

    /**
     * Instantiates constraint of the specified type and copies values of all the common attributes from the given
     * source constraint (of any type) to it.
     * <p>
     * If the source constraint's {@code message} is empty, then it will <b>not</b> copy it (so the default
     * {@code message} of the target constraint will be preserved).
     * </p>
     *
     * @param constraintType Type of the constraint to create.
     * @return An instance of the specified constraint.
     */
    protected <T extends Annotation> T createConstraintAndCopyAttributes(Class<T> constraintType,
                                                                         Map<String, Object> attributes) {
        // merge default method values
        Map<String, Object> newAttributes = AnnotationUtils.readAllAttributesAndOverrideAttribute(constraintType,
                attributes);

        return AnnotationUtils.createAnnotation(constraintType, newAttributes, true);
    }

    protected FastValidatorConstraintDescriptorImpl createConstraintDescriptor(Annotation constraint) {
        return new FastValidatorConstraintDescriptorImpl(constraint);
    }
}
