package com.alibaba.fastvalidator.constraints.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.alibaba.fastvalidator.constraints.IsEnum;

/**
 * validator for {@link com.alibaba.fastvalidator.constraints.IsEnum}
 *
 * @author: jasen.zhangj
 * @date: 17/1/7.
 */
public class IsEnumValidator implements ConstraintValidator<IsEnum, String> {

    private Class<? extends Enum> enumType;

    @Override
    public void initialize(IsEnum constraintAnnotation) {
        enumType = constraintAnnotation.enumType();
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }

        return isValidEnum(enumType, value);
    }

    /**
     * <p>
     * Checks if the specified name is a valid enum for the class.
     * </p>
     * <p>
     * This method differs from {@link Enum#valueOf} in that checks if the name is a valid enum without needing to catch
     * the exception.
     * </p>
     *
     * @param <E> the type of the enumeration
     * @param enumClass the class of the enum to query, not null
     * @param enumName the enum name, null returns false
     * @return true if the enum name is valid, otherwise false
     */
    private static <E extends Enum<E>> boolean isValidEnum(final Class<E> enumClass, final String enumName) {
        try {
            Enum.valueOf(enumClass, enumName);
            return true;
        } catch (final IllegalArgumentException ex) {
            return false;
        }
    }
}
