package com.alibaba.fastvalidator.constraints;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import com.alibaba.fastvalidator.constraints.validator.NotEqualsValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Check whether the string value not equals the specified value.
 *
 * @author: jasen.zhangj
 * @date: 27/4/7.
 */
@Documented
@Constraint(validatedBy = {NotEqualsValidator.class})
@Target({FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@ReportAsSingleViolation
public @interface NotEquals {

    /***
     * @return specified value
     */
    String value();

    /***
     * @return ignore case.
     */
    boolean ignoreCase() default false;

    String message() default "should not equals \"{value}\" when ignoreCase={ignoreCase}";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

}
