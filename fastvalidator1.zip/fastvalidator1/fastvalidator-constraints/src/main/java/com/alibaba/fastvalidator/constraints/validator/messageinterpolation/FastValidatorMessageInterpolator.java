package com.alibaba.fastvalidator.constraints.validator.messageinterpolation;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.MessageInterpolator;

import com.alibaba.fastvalidator.constraints.utils.ArrayUtils;
import com.alibaba.fastvalidator.constraints.utils.StringUtils;
import com.alibaba.fastvalidator.constraints.validator.context.FastValidatorBeanContext;

/**
 * default message interpolator in fastvalidator
 *
 * @author: jasen.zhangj
 * @created: 2016-08-20
 */
public class FastValidatorMessageInterpolator implements MessageInterpolator {

    private static final String               DEFAULT_VALIDATION_MESSAGES = "com.alibaba.fastvalidator.constraints.validator.messageinterpolation.FastValidatorMessages";

    /** Regular expression used to do message interpolation. */
    private static final Pattern              messageParameterPattern     = Pattern.compile("(\\{[\\w\\.]+\\})");

    /** The default locale for the current user. */
    private Locale                            defaultLocale;

    /** Builtin resource bundles hashed against their locale. */
    private final Map<Locale, ResourceBundle> defaultBundlesMap           = new ConcurrentHashMap<Locale, ResourceBundle>();

    /**
     * Create a new DefaultMessageInterpolator instance.
     */
    public FastValidatorMessageInterpolator() {
        defaultLocale = Locale.getDefault();

        // feed the cache with defaults at least
        findDefaultResourceBundle(defaultLocale);
    }

    /** {@inheritDoc} */
    @Override
    public String interpolate(String message, Context context) {
        return interpolate(message, context, ((FastValidatorBeanContext)context).getLocale());
    }

    /** {@inheritDoc} */
    @Override
    public String interpolate(String message, Context context, Locale locale) {
        return interpolateMessage(message, context.getConstraintDescriptor().getAttributes(),
                                  ((FastValidatorBeanContext) context).getMessageArgs(), locale,
                                  context.getValidatedValue());
    }

    /**
     * Runs the message interpolation according to algorithm specified in JSR 303. <br/>
     * Note: <br/>
     * Lookups in user bundles are recursive whereas lookups in default bundle are not!
     *
     * @param message the message to interpolate
     * @param annotationParameters the parameters of the annotation for which to interpolate this message
     * @param locale the <code>Locale</code> to use for the resource bundle.
     * @return the interpolated message.
     */
    private String interpolateMessage(String message, Map<String, Object> annotationParameters, Object[] messageArguments, Locale locale,
                                      Object validatedValue) {
        if (locale == null){
            locale = defaultLocale;
        }

        ResourceBundle defaultResourceBundle = findDefaultResourceBundle(locale);

        String resolvedMessage = message;

        // search the default bundle non recursive (step2)
        resolvedMessage = replaceVariables(resolvedMessage, defaultResourceBundle, locale, true);

        // resolve annotation attributes (step 4)
        resolvedMessage = replaceAnnotationAttributes(resolvedMessage, annotationParameters);

        // EL handling
        // if (evaluator != null) {
        // resolvedMessage = evaluator.interpolate(resolvedMessage, annotationParameters, validatedValue);
        // }

        // curly braces need to be scaped in the original msg, so unescape them now
        resolvedMessage = resolvedMessage.replace("\\{", "{").replace("\\}", "}").replace("\\\\", "\\").replace("\\$",
                                                                                                                "$");
        if (messageArguments != null && messageArguments.length > 0 && StringUtils.isNotBlank(resolvedMessage)){
            resolvedMessage = new MessageFormat(resolvedMessage, locale).format(messageArguments);
        }

        return resolvedMessage;
    }

    private boolean hasReplacementTakenPlace(String origMessage, String newMessage) {
        return !origMessage.equals(newMessage);
    }

    /**
     * Get a usable {@link ClassLoader}: that of {@code clazz} if {@link Thread#getContextClassLoader()} returns
     * {@code null}.
     * 
     * @param clazz
     * @return {@link ClassLoader}
     */
    private static ClassLoader getClassLoader(final Class<?> clazz) {
        final ClassLoader cl = Thread.currentThread().getContextClassLoader();
        return cl == null ? clazz.getClassLoader() : cl;
    }

    private String replaceVariables(String message, ResourceBundle bundle, Locale locale, boolean recurse) {
        final Matcher matcher = messageParameterPattern.matcher(message);
        final StringBuffer sb = new StringBuffer(64);
        String resolvedParameterValue;
        while (matcher.find()) {
            final String parameter = matcher.group(1);
            resolvedParameterValue = resolveParameter(parameter, bundle, locale, recurse);

            matcher.appendReplacement(sb, sanitizeForAppendReplacement(resolvedParameterValue));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private String replaceAnnotationAttributes(final String message, final Map<String, Object> annotationParameters) {
        Matcher matcher = messageParameterPattern.matcher(message);
        StringBuffer sb = new StringBuffer(64);
        while (matcher.find()) {
            String resolvedParameterValue;
            String parameter = matcher.group(1);
            Object variable = annotationParameters.get(removeCurlyBrace(parameter));
            if (variable != null) {
                if (variable.getClass().isArray()) {
                    resolvedParameterValue = ArrayUtils.toString(variable);
                } else {
                    resolvedParameterValue = variable.toString();
                }
            } else {
                resolvedParameterValue = parameter;
            }
            matcher.appendReplacement(sb, sanitizeForAppendReplacement(resolvedParameterValue));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private String resolveParameter(String parameterName, ResourceBundle bundle, Locale locale, boolean recurse) {
        String parameterValue;
        try {
            if (bundle != null) {
                parameterValue = bundle.getString(removeCurlyBrace(parameterName));
                if (recurse) {
                    parameterValue = replaceVariables(parameterValue, bundle, locale, recurse);
                }
            } else {
                parameterValue = parameterName;
            }
        } catch (final MissingResourceException e) {
            // return parameter itself
            parameterValue = parameterName;
        }

        return parameterValue;
    }

    private String removeCurlyBrace(String parameter) {
        return parameter.substring(1, parameter.length() - 1);
    }

    private ResourceBundle findDefaultResourceBundle(Locale locale) {
        ResourceBundle bundle = defaultBundlesMap.get(locale);
        if (bundle == null) {
            bundle = ResourceBundle.getBundle(DEFAULT_VALIDATION_MESSAGES, locale);
            defaultBundlesMap.put(locale, bundle);
        }
        return bundle;
    }

    /**
     * Set the default locale used by this
     * 
     * @param locale
     */
    public void setLocale(Locale locale) {
        defaultLocale = locale;
    }

    /**
     * Escapes the string to comply with {@link Matcher#appendReplacement(StringBuffer, String)} requirements.
     *
     * @param src The original string.
     * @return The sanitized string.
     */
    private String sanitizeForAppendReplacement(String src) {
        return src.replace("\\", "\\\\").replace("$", "\\$");
    }
}
