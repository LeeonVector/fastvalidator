package com.alibaba.fastvalidator.constraints.validator.utils.builder;

import com.alibaba.fastjson.JSON;

/**
 * JSON builder
 *
 * @author: jasen.zhangj
 * @date: 27/04/2017.
 */
public class JSONStringBuilder implements Builder<String> {

    /**
     * The object being output, may be null.
     */
    private final Object object;

    private JSONStringBuilder(Object object){
        this.object = object;
    }

    public static String toString(Object object){
        return new JSONStringBuilder(object).build();
    }

    @Override
    public String build() {
        return JSON.toJSONString(this.object);
    }
}
