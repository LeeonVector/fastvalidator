package com.alibaba.fastvalidator.constraints.collection;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import org.hibernate.validator.constraints.ParameterScriptAssert;
import com.alibaba.fastvalidator.constraints.validator.collection.CommonEachValidator;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @see org.hibernate.validator.constraints.ParameterScriptAssert
 * @author: jasen.zhangj
 * @date: 17/1/3.
 */
@Documented
@Retention(RUNTIME)
@Target({ METHOD, FIELD, ANNOTATION_TYPE })
@EachConstraint(validateAs = ParameterScriptAssert.class)
@Constraint(validatedBy = {CommonEachValidator.class})
public @interface EachParameterScriptAssert {

    String message() default "";

    Class<?>[] groups() default { };

    Class<? extends Payload>[] payload() default { };

    /**
     * @return The name of the script language used by this constraint as
     *         expected by the JSR 223 {@link javax.script.ScriptEngineManager}. A
     *         {@link javax.validation.ConstraintDeclarationException} will be thrown upon script
     *         evaluation, if no engine for the given language could be found.
     */
    String lang();

    /**
     * @return The script to be executed. The script must return
     *         <code>Boolean.TRUE</code>, if the executable parameters could
     *         successfully be validated, otherwise <code>Boolean.FALSE</code>.
     *         Returning null or any type other than Boolean will cause a
     *         {@link javax.validation.ConstraintDeclarationException} upon validation. Any
     *         exception occurring during script evaluation will be wrapped into
     *         a ConstraintDeclarationException, too. Within the script, the
     *         validated parameters can be accessed using their names as retrieved from the
     *         active {@link javax.validation.ParameterNameProvider}.
     */
    String script();
}
