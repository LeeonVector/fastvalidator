package com.alibaba.fastvalidator.constraints.validator.metadata;

import java.lang.annotation.Annotation;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintTarget;
import javax.validation.Payload;
import javax.validation.metadata.ConstraintDescriptor;

import com.alibaba.fastvalidator.constraints.validator.helper.ConstraintDescriptorHelper;
import com.alibaba.fastvalidator.constraints.validator.helper.FastValidatorConstraintHelper;
import com.alibaba.fastvalidator.constraints.validator.utils.AnnotationUtils;

/**
 * Simple constraint descriptor
 *
 * @author: jasen.zhangj
 * @date: 2017-10-11
 */
public class SimpleConstraintDescriptor<T extends Annotation> implements ConstraintDescriptor {

    private final T             annotation;
    private Map<String, Object> attributes;
    private boolean             initialAttributes;

    /**
     * Create a new ConstraintDescriptorImpl instance.
     *
     * @param annotation annotation
     */
    public SimpleConstraintDescriptor(T annotation) {
        this.annotation = annotation;
    }

    private void initAttributes() {
        attributes = AnnotationUtils.getAnnotationParameterValues(annotation);
        initialAttributes = true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T getAnnotation() {
        return annotation;
    }

    @Override
    public String getMessageTemplate() {
        if (!initialAttributes) {
            initAttributes();
        }
        return ConstraintDescriptorHelper.getMessageTemplate(attributes);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<Class<?>> getGroups() {
        if (!initialAttributes) {
            initAttributes();
        }
        return ConstraintDescriptorHelper.getGroups(attributes);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<Class<? extends Payload>> getPayload() {
        if (!initialAttributes) {
            initAttributes();
        }
        return ConstraintDescriptorHelper.getPayload(attributes);
    }

    @Override
    public ConstraintTarget getValidationAppliesTo() {
        if (!initialAttributes) {
            initAttributes();
        }
        return ConstraintDescriptorHelper.getValidationAppliesTo(attributes);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public List<Class<? extends javax.validation.ConstraintValidator<T, ?>>> getConstraintValidatorClasses() {
        return FastValidatorConstraintHelper.getInstance().getAllValidatorClasses((Class) annotation.annotationType());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, Object> getAttributes() {
        if (!initialAttributes) {
            initAttributes();
        }
        return attributes;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<ConstraintDescriptor<?>> getComposingConstraints() {
        // TODO: it should be implement this function
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isReportAsSingleViolation() {
        // TODO: it should be implement this function
        return true;
    }
}
