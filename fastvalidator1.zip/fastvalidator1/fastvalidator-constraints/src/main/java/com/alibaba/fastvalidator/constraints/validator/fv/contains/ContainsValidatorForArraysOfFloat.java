package com.alibaba.fastvalidator.constraints.validator.fv.contains;

import com.alibaba.fastvalidator.constraints.Contains;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author jipengfei
 * @date 2017/2/20
 */
public class ContainsValidatorForArraysOfFloat implements ConstraintValidator<Contains, float[]> {

    private float containsValue;

    @Override
    public void initialize(Contains constraintAnnotation) {
        containsValue = Float.parseFloat(constraintAnnotation.value());
    }

    @Override
    public boolean isValid(float[] value, ConstraintValidatorContext context) {
        if (value == null) {
            return true;
        }
        boolean result = false;
        for (int i = 0; i < value.length; i++) {
            if (containsValue == value[i]) {
                result = true;
                break;
            }
        }
        return result;
    }
}
