package com.alibaba.fastvalidator.constraints.validator;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * composted constraint validator.
 *
 * @author: jasen.zhangj
 * @date: 15/11/9.
 */
public class CompostedValidator implements ConstraintValidator {

    private List<ConstraintValidator> composingConstraintValidators = new ArrayList<ConstraintValidator>();
    private List<Annotation>          composingConstraints          = new ArrayList<Annotation>();

    @Override
    public void initialize(Annotation constraintAnnotations) {
        if (composingConstraints.size() != composingConstraintValidators.size()) {
            throw new RuntimeException("constraint annotations num is not equal constraint validators");
        }

        int i = 0;
        for (Annotation constraintAnnotation : composingConstraints) {
            ConstraintValidator constraintValidator = composingConstraintValidators.get(i);
            constraintValidator.initialize(constraintAnnotation);
            i++;
        }
    }

    public void addComposingConstraintValidator(Annotation annotation, ConstraintValidator constraintValidator) {
        composingConstraintValidators.add(constraintValidator);
        composingConstraints.add(annotation);
    }

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext context) {
        boolean result = true;

        for (ConstraintValidator dependency : composingConstraintValidators) {
            result = dependency.isValid(value, context);
            if (!result) {
                break;
            }
        }

        return result;
    }
}
