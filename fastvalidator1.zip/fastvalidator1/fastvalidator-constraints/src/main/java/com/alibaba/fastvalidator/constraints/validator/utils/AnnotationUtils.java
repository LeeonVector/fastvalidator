package com.alibaba.fastvalidator.constraints.validator.utils;

import static java.lang.reflect.Proxy.getInvocationHandler;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.lang.model.element.TypeElement;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.MirroredTypeException;
import javax.lang.model.type.MirroredTypesException;
import javax.lang.model.type.TypeMirror;
import javax.validation.OverridesAttribute;

import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationDescriptor;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationFactory;
import com.alibaba.fastvalidator.constraints.validator.annotation.AnnotationProxy;

/**
 * annotation utils
 *
 * @author: jasen.zhangj
 * @date: 17/1/2.
 */
public class AnnotationUtils {

    public static final String  OVERRIDE_ATTRIBUTES = "OVERRIDE_ATTRIBUTES";

    private static final Logger LOGGER              = Logger.getLogger(AnnotationUtils.class.getName());

    public static <T> T readAttribute(Annotation annotation, String name,
                                      Class<T> requiredType) throws IllegalArgumentException, IllegalStateException {

        Object result = AnnotationUtils.invokeNonArgMethod(annotation, name);

        if (requiredType.isInstance(result) == false) {
            throw new IllegalArgumentException(String.format("Method %s should return instance of %s", name,
                                                             requiredType.getSimpleName()));
        }

        return (T) result;
    }

    public static <T> T readAttribute(Annotation annotation, String name) {

        Object result = AnnotationUtils.invokeNonArgMethod(annotation, name);

        return (T) result;
    }

    /**
     * Whether the annotation type contains attribute of the specified name.
     */
    public static boolean hasAttribute(Class<? extends Annotation> annotationType, String attributeName) {

        for (Method m : annotationType.getDeclaredMethods()) {
            if (m.getName().equals(attributeName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns type of the specified attribute in the annotation type.
     */
    public static Class<?> getAttributeType(Class<? extends Annotation> annotationType, String attributeName) {
        try {
            return annotationType.getDeclaredMethod(attributeName).getReturnType();

        } catch (NoSuchMethodException ex) {
            throw new IllegalArgumentException(String.format("No such attribute %s in %s", attributeName,
                                                             annotationType.getName()));
        }
    }

    /**
     * Creates instance (proxy) of the specified annotation with the given attributes.
     *
     * @param annotationType The annotation's class.
     * @param attributes A map with attribute values for the annotation to be created.
     * @param <T> The type of the annotation.
     * @return An instance of the annotation.
     * @throws IllegalArgumentException if some attribute has wrong type or a required attribute is missing.
     */
    public static <T extends Annotation> T createAnnotation(Class<T> annotationType, Map<String, Object> attributes) {
        AnnotationDescriptor<T> descriptor = AnnotationDescriptor.getInstance(annotationType, attributes);
        return AnnotationFactory.create(descriptor);
    }

    /**
     * Creates instance (proxy) of the specified annotation with the given attributes.
     *
     * @param annotationType The annotation's class.
     * @param attributes A map with attribute values for the annotation to be created.
     * @param <T> The type of the annotation.
     * @return An instance of the annotation.
     * @throws IllegalArgumentException if some attribute has wrong type or a required attribute is missing.
     */
    public static <T extends Annotation> T createAnnotation(Class<T> annotationType, Map<String, Object> attributes,
                                                            boolean autoConvertValueType) {
        AnnotationDescriptor<T> descriptor = AnnotationDescriptor.getInstance(annotationType, attributes);
        return AnnotationFactory.create(descriptor, autoConvertValueType);
    }

    private static Object invokeNonArgMethod(Object object, String methodName) {
        Class<?> clazz = object.getClass();

        try {
            return clazz.getMethod(methodName).invoke(object);

        } catch (NoSuchMethodException ex) {
            throw new IllegalArgumentException(String.format("Class should declare method %s()", methodName));

        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }
    }

    /***
     * Create annotation by exist annotation and override attributes
     * 
     * @param annotation
     * @param attributes
     * @return
     */
    public static Annotation createAnnotation(Annotation annotation, Map<String, Object> attributes) {
        if (Proxy.isProxyClass(annotation.getClass())) {
            InvocationHandler invocationHandler = getInvocationHandler(annotation);
            if (invocationHandler instanceof AnnotationProxy) {
                ((AnnotationProxy) invocationHandler).put(attributes);
                return annotation;
            }
        }

        AnnotationDescriptor descriptor = AnnotationDescriptor.getInstance(annotation.annotationType(),
                                                                           getAnnotationParameterValues(annotation));
        if (attributes != null) {
            for (Map.Entry<String, Object> objectEntry : attributes.entrySet()) {
                descriptor.setValue(objectEntry.getKey(), objectEntry.getValue());
            }
        }

        return AnnotationFactory.create(descriptor, true);
    }

    public static Map<String, Object> getAnnotationParameterValues(Annotation annotation) {
        if (Proxy.isProxyClass(annotation.getClass())) {
            InvocationHandler invocationHandler = getInvocationHandler(annotation);
            if (invocationHandler instanceof AnnotationProxy) {
                return ((AnnotationProxy) invocationHandler).getValues();
            }
        }

        Map<String, Object> parameters = new HashMap<>();
        List<AnnotationUtils.OverrideAttribute> overrideAttributeList = new ArrayList<>();

        if (Proxy.isProxyClass(annotation.getClass())) {
            InvocationHandler invocationHandler = getInvocationHandler(annotation);
            Method[] methods = annotation.annotationType().getDeclaredMethods();
            for (Method method : methods) {
                Object value = null;
                try {
                    value = invocationHandler.invoke(annotation, method, new Object[] {});
                } catch (MirroredTypeException ex) {
                    DeclaredType classTypeMirror = (DeclaredType) ex.getTypeMirror();
                    TypeElement classTypeElement = (TypeElement) classTypeMirror.asElement();
                    value = classTypeElement.getQualifiedName().toString();
                } catch (MirroredTypesException ex) {
                    List<? extends TypeMirror> typeMirrors = ex.getTypeMirrors();
                    List<String> listValue = new ArrayList<String>();
                    for (TypeMirror typeMirror : typeMirrors) {
                        TypeElement classTypeElement = (TypeElement) ((DeclaredType) typeMirror).asElement();
                        listValue.add(classTypeElement.getQualifiedName().toString());
                    }
                    value = listValue;
                } catch (Throwable throwable) {
                    LOGGER.log(Level.SEVERE, throwable.getMessage());
                }
                parameters.put(method.getName(), value);
                putOverrideAttribute(overrideAttributeList, method, value);
            }
            if (!overrideAttributeList.isEmpty()) {
                parameters.put(OVERRIDE_ATTRIBUTES, overrideAttributeList);
            }
        } else {
            parameters = readAllAttributesAndOverrideAttribute(annotation);
        }

        return parameters;
    }

    /**
     * Returns annotation's attributes (name and value) as map.
     */
    public static Map<String, Object> readAllAttributes(Annotation annotation) {
        Map<String, Object> attributes = new HashMap<String, Object>();

        for (Method method : annotation.annotationType().getDeclaredMethods()) {
            try {
                Object value = method.invoke(annotation);
                attributes.put(method.getName(), value);
            } catch (Exception ex) {
                throw new IllegalStateException(ex);
            }
        }

        return attributes;
    }

    /**
     * Returns annotation's attributes (name and type) as map.
     */
    public static Map<String, Type> readAllAttributes(Class<? extends Annotation> annotation) {
        Map<String, Type> attributes = new HashMap<>();

        for (Method method : annotation.getDeclaredMethods()) {
            try {
                attributes.put(method.getName(), method.getReturnType());
            } catch (Exception ex) {
                throw new IllegalStateException(ex);
            }
        }

        return attributes;
    }

    /**
     * Returns annotation's attributes (name and default value) as map.
     */
    public static Map<String, Object> readAllAttributesDefaultValue(Class<? extends Annotation> annotation) {
        Map<String, Object> attributes = new HashMap<>();

        for (Method method : annotation.getDeclaredMethods()) {
            try {
                attributes.put(method.getName(), method.getDefaultValue());
            } catch (Exception ex) {
                throw new IllegalStateException(ex);
            }
        }

        return attributes;
    }

    /**
     * Returns annotation's attributes (name and value) as map.
     */
    public static Map<String, Object> readAllAttributesAndOverrideAttribute(Annotation annotation) {
        Map<String, Object> attributes = new HashMap<String, Object>();

        List<OverrideAttribute> overrideAttributeList = new ArrayList<>();
        for (Method method : annotation.annotationType().getDeclaredMethods()) {
            try {
                Object value = method.invoke(annotation);
                attributes.put(method.getName(), value);

                putOverrideAttribute(overrideAttributeList, method, value);
            } catch (Exception ex) {
                throw new IllegalStateException(ex);
            }
        }

        if (!overrideAttributeList.isEmpty()) {
            attributes.put(OVERRIDE_ATTRIBUTES, overrideAttributeList);
        }

        return attributes;
    }

    /**
     * Returns annotation's attributes (name and value) as map.
     */
    public static Map<String, Object> readAllAttributesAndOverrideAttribute(Class<? extends Annotation> annotationType, Map<String, Object> attributeValue) {
        Map<String, Object> attributes = new HashMap<String, Object>();

        List<OverrideAttribute> overrideAttributeList = new ArrayList<>();
        for (Method method : annotationType.getDeclaredMethods()) {
            try {
                //Object value = method.invoke(annotation);
                Object value = attributeValue.get(method.getName());
                value = value == null ? method.getDefaultValue(): value;

                if (value == null){
                    throw new IllegalArgumentException("the attribute " + method.getName() + " of "+ annotationType.getName()+ " may not be null");
                }

                attributes.put(method.getName(), value);
                putOverrideAttribute(overrideAttributeList, method, value);
            } catch (Exception ex) {
                throw new IllegalStateException(ex);
            }
        }

        if (!overrideAttributeList.isEmpty()) {
            attributes.put(OVERRIDE_ATTRIBUTES, overrideAttributeList);
        }

        return attributes;
    }

    private static void putOverrideAttribute(List<OverrideAttribute> overrideAttributes, Method method, Object value) {
        OverridesAttribute overridesAttribute = method.getAnnotation(OverridesAttribute.class);
        if (overridesAttribute != null) {
            Class<? extends Annotation> overrideConstraint = overridesAttribute.constraint();
            String overrideAttributeName = overridesAttribute.name();
            int index = overridesAttribute.constraintIndex();

            OverrideAttribute overrideAttribute = new OverrideAttribute();
            overrideAttribute.index = index;
            overrideAttribute.overrideAttributeName = overrideAttributeName;
            overrideAttribute.overrideConstraint = overrideConstraint;
            overrideAttribute.value = value;
            overrideAttribute.methodName = method.getName();

            overrideAttributes.add(overrideAttribute);
        }
    }

    public static class OverrideAttribute {

        Class<? extends Annotation> overrideConstraint;
        String                      overrideAttributeName;
        int                         index = -1;
        Object                      value;
        String                      methodName;

        public Object getValue() {
            return value;
        }

        public void setValue(Object value) {
            this.value = value;
        }

        public Class<? extends Annotation> getOverrideConstraint() {
            return overrideConstraint;
        }

        public void setOverrideConstraint(Class<? extends Annotation> overrideConstraint) {
            this.overrideConstraint = overrideConstraint;
        }

        public String getOverrideAttributeName() {
            return overrideAttributeName;
        }

        public void setOverrideAttributeName(String overrideAttributeName) {
            this.overrideAttributeName = overrideAttributeName;
        }

        public int getIndex() {
            return index;
        }

        public void setIndex(int index) {
            this.index = index;
        }

        public String getMethodName() {
            return methodName;
        }

        public void setMethodName(String methodName) {
            this.methodName = methodName;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            OverrideAttribute that = (OverrideAttribute) o;

            if (index != that.index) return false;
            if (overrideConstraint != null ? !overrideConstraint.equals(that.overrideConstraint) : that.overrideConstraint != null)
                return false;
            if (overrideAttributeName != null ? !overrideAttributeName.equals(that.overrideAttributeName) : that.overrideAttributeName != null)
                return false;
            if (value != null ? !value.equals(that.value) : that.value != null) return false;
            return methodName != null ? methodName.equals(that.methodName) : that.methodName == null;

        }

        @Override
        public int hashCode() {
            int result = overrideConstraint != null ? overrideConstraint.hashCode() : 0;
            result = 31 * result + (overrideAttributeName != null ? overrideAttributeName.hashCode() : 0);
            result = 31 * result + index;
            result = 31 * result + (value != null ? value.hashCode() : 0);
            result = 31 * result + (methodName != null ? methodName.hashCode() : 0);
            return result;
        }
    }
}
