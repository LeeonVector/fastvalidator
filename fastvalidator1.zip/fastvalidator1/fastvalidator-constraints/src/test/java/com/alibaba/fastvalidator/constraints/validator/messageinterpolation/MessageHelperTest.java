package com.alibaba.fastvalidator.constraints.validator.messageinterpolation;

import junit.framework.TestCase;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;

/**
 * Test for {@link MessageHelper}
 *
 * @author: jasen.zhangj
 * @date: 2017-05-12
 */
public class MessageHelperTest extends TestCase {

    @Test
    public void testGetConstraintMessage() throws Exception {
        String message = "|code";
        ConstraintMessage constraintMessage = MessageHelper.getConstraintMessage(message);
        assertTrue(constraintMessage.getCode().equals("code"));
        assertTrue(constraintMessage.getMessage().equals(""));


        message = "hello|code";
        constraintMessage = MessageHelper.getConstraintMessage(message);
        assertTrue(constraintMessage.getCode().equals("code"));
        assertTrue(constraintMessage.getMessage().equals("hello"));

        message = "helllo {0}{1}?{fastvalidator}{!}|code";
        constraintMessage = MessageHelper.getConstraintMessage(message);
        assertTrue(constraintMessage.getCode().equals("code"));
        assertTrue(constraintMessage.getMessage().equals("helllo {0}{1}"));

        List<String> parameters = new ArrayList<>();
        parameters.add("fastvalidator");
        parameters.add("!");
        assertTrue(constraintMessage.getMessageArgs().equals(parameters));

        message = "helllo {0}{1}?{}|code";
        constraintMessage = MessageHelper.getConstraintMessage(message);
        assertTrue(constraintMessage.getCode().equals("code"));
        assertTrue(constraintMessage.getMessage().equals("helllo {0}{1}"));
        assertTrue(constraintMessage.getMessageArgs().isEmpty());

        message = "helllo {0}{1}?{{0}|code";
        constraintMessage = MessageHelper.getConstraintMessage(message);
        assertTrue(constraintMessage.getCode().equals("code"));
        assertTrue(constraintMessage.getMessage().equals("helllo {0}{1}"));
        assertTrue(constraintMessage.getMessageArgs().contains("{0"));
    }

}